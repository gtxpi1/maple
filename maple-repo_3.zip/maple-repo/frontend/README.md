# Maple Frontend

React + TypeScript + Vite, talking to `backend/` — replaces the static
mockups in `mockups/` with a real, data-driven app.

## Setup

```bash
npm install
cp .env.example .env
npm run dev
```

Before running: start `backend/` (see `backend/README.md`), then run its
seed script and copy the printed marketplace id into `VITE_MARKETPLACE_ID`
in your `.env`.

## What's implemented

- **Home** (`/`) — fetches and renders real listings from `GET /listings`,
  using the design system from `mockups/homepage.html` (same CSS tokens,
  same corner-ribbon treatment for recently-posted listings). Supports
  `?category=<slug>` filtering, driven by the category strip below.
- **Category strip** — fetched live from `GET /categories`, fully backend-
  driven. Clicking a category filters the homepage via a URL param; nothing
  is hardcoded.
- **`/admin/categories`** — CRUD + reorder (↑/↓) + show/hide + soft-delete
  for categories, gated by the `admin` role on the logged-in user (enforced
  server-side by `requireAdmin`, not just hidden in the UI). Linked from the
  header as "Manage categories" when an admin is logged in. Log in as
  `admin@maple.demo` (see `backend/README.md`) to use it.
- **Listing detail** (`/listings/:id`) — real data from `GET /listings/:id`.
- **Login / Signup** (`/login`, `/signup`) — hits the real auth endpoints,
  stores the JWT (now including role claims) in `localStorage`. Login
  handles the MFA two-step: if the account has MFA enabled, the API
  returns `{ mfaRequired: true }` instead of a token, and the form swaps
  in a 6-digit code field rather than treating it as a failed attempt.
- **`/security`** — enable/disable TOTP-based MFA. Setup shows a QR code
  (scan with any authenticator app) plus the raw secret as a fallback,
  and requires one valid code before actually enabling it — so a
  half-finished setup (closed the tab before scanning) can't leave the
  account in a broken enabled-but-unconfirmed state. Disabling requires
  re-entering your password, not just being logged in.
- **Post an ad** (`/post-ad`) — the real end-to-end flow: upload photos via
  `POST /media/upload`, then create the listing with `imageIds` attached.

- **`/admin/geography`** — manage Countries, States/Provinces, Regions,
  Cities, and Neighborhoods as a five-column drill-down (each column
  appears once its parent is selected; Regions are optional and assignable
  when creating a city). Same admin gating as categories.
- **Neighborhood on post-ad** — once a city with neighborhoods is picked,
  an optional "Neighborhood" dropdown appears on the post-ad form. Shown on
  the listing detail page alongside city when set.
- **Location filter on Home and Search** — a `CityPicker` + neighborhood
  dropdown above the listing grid on both pages. URL-persisted (`?city=`,
  `?neighborhood=`), same as the category filter — refreshing, sharing, or
  bookmarking a filtered URL now preserves it, resolved back into a
  displayable city via `GET /geography/cities/:id`.
- The post-ad form's City field is a real type-ahead picker (`CityPicker`)
  hitting `GET /geography/cities?search=`, not a raw UUID input.
- **Search** — the header search box is functional. Submitting navigates to
  `/search?q=...`, which hits `GET /search` and renders results with the
  same `ListingCard` component as the homepage.
- **Messaging** — `/messages` (inbox) and `/messages/:id` (thread with a
  send box, auto-scrolls to the latest message, supports image attachments
  via a 📎 button reusing the same upload endpoint as post-ad photos).
  "Message seller" on a listing detail page now actually starts a
  conversation and navigates there, instead of being a dead button. A
  logged-in user viewing their own listing sees "This is your own listing"
  instead of a message button.
- **Notification bell** — in the header for logged-in users, unread count
  badge, dropdown of recent notifications, polls every 15s (no websockets).
  Clicking a message notification marks it read and navigates to that
  conversation.
- **Promotions** — a listing owner sees a "Promote this listing" panel
  (`PromotePanel`) on their own listing's detail page, listing the real
  catalog from `GET /promotions/catalog` with live prices. Purchasing hits
  the real ledger flow on the backend (simulated payment, clearly labeled
  as such in the UI) and immediately shows a FEATURED ribbon on the
  listing card and detail page — replacing the old always-fake "NEW if
  posted in the last 24h" heuristic with something actually paid for.
- **`/admin/promotions`** — edit price/duration/label/description for each
  promotion type, add new types, remove types, reset to the built-in
  defaults. Changes are live immediately on the Promote panel and only
  affect future purchases — already-purchased promotions keep whatever
  they were actually charged (the ledger is immutable).
- **`/admin/finance`** — total revenue, transaction count, average per
  transaction, a simple bar chart of the last 30 days, revenue broken down
  by promotion type, and a paginated raw transaction ledger (buyer, amount,
  status, what was purchased). Everything computed live from the
  Transaction table on page load, not a cached/scheduled rollup. Each
  succeeded transaction has a Refund button — refunding also expires any
  promotion that transaction bought.
- **`/admin/analytics`** — user count, listing count/breakdown by status,
  category count, and a signup-trend bar chart. Covers Site + User Metrics
  only; Category and Geographic Metrics have no page — see docs/19.
- **`/admin`** — dashboard home: quick stats (revenue, users, listings)
  pulled from the finance/analytics endpoints, and cards linking to all
  six admin sections. Not a unified dashboard with shared filters or a
  combined activity feed — each section still loads its own data
  independently, this page just ties them together with one entry point.
  Header now shows a single "Admin" link instead of separate ones per
  section; each section is still directly reachable by URL.
- **`/admin/users`** — list users, grant/revoke the `admin` role. Closes
  the "only way to become admin is editing the database" gap for the
  *second* admin onward — the very first admin still has to come from the
  seed script (or direct DB access), since granting requires already being
  an admin.
- **Save/favorite a listing** — a "♡ Save" / "♥ Saved" toggle on the
  listing detail page (non-owners only), and a `/saved` page listing
  everything saved, reusing `ListingCard`. The `SavedListing` table existed
  since the first schema commit and was in the very first static mockup's
  UI ("Save listing" button) — this is the first time it's had any code
  behind it at all.
- **`/admin/moderation`** — approve or reject listings waiting for review.
  **This isn't optional polish — it's a bug fix.** Every listing is
  created `PENDING_REVIEW`; the homepage and search only show `ACTIVE`
  listings. Before this page existed, nothing anywhere ever moved a
  listing from one state to the other, so every listing ever posted
  through the app was invisible everywhere except its own direct-link
  detail page. `ListingDetail` and `Home` now both reflect this — the
  detail page shows a "waiting for review" banner on a pending listing,
  and the homepage's empty state explains why a freshly-posted ad isn't
  showing up yet.
- **Owner listing controls on `ListingDetail`** — another real gap, not
  just a feature: there was no way to edit a listing, mark it sold, or
  delete it at all, by anyone, ever, once posted (see backend/README.md).
  The owner now sees "Edit details" (inline form for title/description/
  price, replacing the title/description display in place rather than
  navigating away), "Mark as sold" / "Mark as available again", and
  "Delete listing" buttons.

## Known rough edges (by design, not oversight)

- **No image gallery/thumbnails on listing detail** yet — shows one image,
  even though a listing can have multiple.
- **Users/Roles UI only covers granting/revoking `admin`.** There's no
  general role management, no listing of all `Role`/`Permission` rows in
  the schema, no way to create a new role from the UI.
