import { Route, Routes } from 'react-router-dom';
import { Header } from './components/Header';
import { CategoryStrip } from './components/CategoryStrip';
import { Home } from './pages/Home';
import { ListingDetail } from './pages/ListingDetail';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { PostAd } from './pages/PostAd';
import { AdminCategories } from './pages/AdminCategories';
import { AdminGeography } from './pages/AdminGeography';
import { SearchResults } from './pages/SearchResults';
import { Messages } from './pages/Messages';
import { Conversation } from './pages/Conversation';
import { AdminPromotions } from './pages/AdminPromotions';
import { AdminFinance } from './pages/AdminFinance';
import { AdminAnalytics } from './pages/AdminAnalytics';
import { AdminDashboard } from './pages/AdminDashboard';
import { AdminUsers } from './pages/AdminUsers';
import { AdminModeration } from './pages/AdminModeration';
import { SavedListings } from './pages/SavedListings';
import { Security } from './pages/Security';

export function App() {
  return (
    <>
      <Header />
      <CategoryStrip />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/listings/:id" element={<ListingDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/post-ad" element={<PostAd />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/messages" element={<Messages />} />
        <Route path="/messages/:id" element={<Conversation />} />
        <Route path="/saved" element={<SavedListings />} />
        <Route path="/security" element={<Security />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/categories" element={<AdminCategories />} />
        <Route path="/admin/geography" element={<AdminGeography />} />
        <Route path="/admin/promotions" element={<AdminPromotions />} />
        <Route path="/admin/finance" element={<AdminFinance />} />
        <Route path="/admin/analytics" element={<AdminAnalytics />} />
        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/admin/moderation" element={<AdminModeration />} />
      </Routes>
    </>
  );
}
