const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1';

export class ApiClientError extends Error {
  status: number;
  code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function getToken(): string | null {
  return localStorage.getItem('maple_token');
}

export function setToken(token: string | null): void {
  if (token) localStorage.setItem('maple_token', token);
  else localStorage.removeItem('maple_token');
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(options.headers);
  if (token) headers.set('Authorization', `Bearer ${token}`);
  if (!(options.body instanceof FormData) && options.body) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(`${API_URL}${path}`, { ...options, headers });
  const body = await res.json().catch(() => null);

  if (!res.ok) {
    const err = body?.error ?? { code: 'unknown_error', message: 'Request failed.' };
    throw new ApiClientError(res.status, err.code, err.message);
  }

  return body as T;
}

// ---------- Types (mirroring backend/prisma/schema.prisma) ----------

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: string | null;
  currency: string;
  status: string;
  createdAt: string;
  cityId: string;
  categoryId: string;
  images: Array<{
    id: string;
    position: number;
    uploadedFile: {
      originalUrl: string;
      variants: Array<{ size: string; url: string; width: number; height: number }>;
    };
  }>;
  promotions: Array<{ id: string; promotionType: string; startAt: string; endAt: string }>;
  user?: { id: string; displayName: string; trustScore: number };
  category?: { id: string; name: string };
  city?: { id: string; name: string };
  neighborhood?: { id: string; name: string } | null;
}

export interface PromotionType {
  id: string;
  label: string;
  priceCents: number;
  currency: string;
  durationDays: number;
  description: string;
}

export interface ConversationSummary {
  id: string;
  listing: { id: string; title: string } | null;
  otherParticipant: { id: string; displayName: string } | null;
  lastMessage: { body: string; createdAt: string; senderId: string } | null;
  updatedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  body: string;
  createdAt: string;
  readAt: string | null;
  sender: { id: string; displayName: string };
  attachments: Array<{ id: string; url: string; mimeType: string }>;
}

export interface Notification {
  id: string;
  type: string;
  payload: Record<string, unknown>;
  readAt: string | null;
  createdAt: string;
}

export interface ModerationListing {
  id: string;
  title: string;
  description: string;
  price: string | null;
  createdAt: string;
  user: { id: string; displayName: string; email: string; trustScore: number };
  category?: { id: string; name: string };
  city?: { id: string; name: string };
  images: Array<{
    id: string;
    uploadedFile: {
      originalUrl: string;
      variants: Array<{ size: string; url: string }>;
      moderationResults: Array<{ flagged: boolean; categories: string[] }>;
    };
  }>;
}

export interface Role {
  id: string;
  name: string;
  description: string | null;
}

export interface AdminUser {
  id: string;
  email: string;
  displayName: string;
  createdAt: string;
  trustScore: number;
  roles: string[];
}

export interface AnalyticsOverview {
  userCount: number;
  totalListings: number;
  listingsByStatus: Record<string, number>;
  categoryCount: number;
  dailySignups: Array<{ date: string; count: number }>;
}

export interface FinanceSummary {
  totalRevenue: number;
  transactionCount: number;
  currency: string;
  revenueByPromotionType: Record<string, { count: number; revenue: number }>;
  dailyRevenue: Array<{ date: string; revenue: number }>;
}

export interface AdminTransaction {
  id: string;
  amount: string;
  currency: string;
  status: string;
  createdAt: string;
  externalRef: string | null;
  invoice: { user: { id: string; displayName: string; email: string } };
  promotionPurchases: Array<{ promotionType: string; listingId: string }>;
  refunds: Array<{ id: string; status: string; amount: string; createdAt: string }>;
}

export interface AuthResponse {
  token: string;
  user: { id: string; email: string; displayName: string; roles: string[]; mfaEnabled: boolean };
}

export interface Category {
  id: string;
  parentId: string | null;
  name: string;
  slug: string;
  icon: string | null;
  displayOrder: number;
  showInNav: boolean;
  deletedAt: string | null;
  subcategories?: Category[];
}

export interface Country {
  id: string;
  name: string;
  code: string;
}

export interface StateProvince {
  id: string;
  countryId: string;
  name: string;
  code: string | null;
}

export interface Region {
  id: string;
  stateProvinceId: string;
  name: string;
}

export interface City {
  id: string;
  stateProvinceId: string;
  name: string;
  latitude: number | null;
  longitude: number | null;
  stateProvince?: { name: string; country: { name: string } };
}

export interface Neighborhood {
  id: string;
  cityId: string;
  name: string;
}

export interface UploadedImage {
  id: string;
  url: string;
  variants: Array<{ size: string; url: string; width: number; height: number }>;
}

// ---------- API surface ----------

export const api = {
  auth: {
    signup: (data: {
      marketplaceId: string;
      email: string;
      password: string;
      displayName: string;
    }) => request<AuthResponse>('/auth/signup', { method: 'POST', body: JSON.stringify(data) }),

    login: (data: { marketplaceId: string; email: string; password: string; mfaToken?: string }) =>
      request<AuthResponse | { mfaRequired: true }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    mfaSetup: () =>
      request<{ data: { secret: string; otpAuthUrl: string; qrCodeDataUrl: string } }>(
        '/auth/mfa/setup',
        { method: 'POST' },
      ),

    mfaVerify: (token: string) =>
      request<{ data: { mfaEnabled: boolean } }>('/auth/mfa/verify', {
        method: 'POST',
        body: JSON.stringify({ token }),
      }),

    mfaDisable: (password: string) =>
      request<{ data: { mfaEnabled: boolean } }>('/auth/mfa/disable', {
        method: 'POST',
        body: JSON.stringify({ password }),
      }),
  },

  listings: {
    list: (params: {
      marketplaceId: string;
      categoryId?: string;
      categorySlug?: string;
      cityId?: string;
      neighborhoodId?: string;
    }) => {
      const query = new URLSearchParams(
        Object.fromEntries(Object.entries(params).filter(([, v]) => v)),
      );
      return request<{ data: Listing[]; nextCursor: string | null }>(`/listings?${query}`);
    },

    get: (id: string) => request<{ data: Listing }>(`/listings/${id}`),

    create: (data: {
      marketplaceId: string;
      categoryId: string;
      cityId: string;
      neighborhoodId?: string;
      title: string;
      description: string;
      price?: number;
      currency?: string;
      imageIds?: string[];
    }) => request<{ data: Listing }>('/listings', { method: 'POST', body: JSON.stringify(data) }),

    update: (
      id: string,
      data: Partial<{ title: string; description: string; price: number; status: 'ACTIVE' | 'SOLD' }>,
    ) => request<{ data: Listing }>(`/listings/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),

    remove: (id: string) => request<void>(`/listings/${id}`, { method: 'DELETE' }),

    save: (id: string) => request<{ data: { listingId: string; saved: boolean } }>(
      `/listings/${id}/save`,
      { method: 'POST' },
    ),

    unsave: (id: string) => request<void>(`/listings/${id}/save`, { method: 'DELETE' }),

    listSaved: (marketplaceId: string) =>
      request<{ data: Listing[] }>(`/listings/saved/list?marketplaceId=${marketplaceId}`),
  },

  search: {
    listings: (params: {
      marketplaceId: string;
      q: string;
      categoryId?: string;
      cityId?: string;
      minPrice?: number;
      maxPrice?: number;
    }) => {
      const query = new URLSearchParams(
        Object.fromEntries(
          Object.entries(params)
            .filter(([, v]) => v !== undefined && v !== '')
            .map(([k, v]) => [k, String(v)]),
        ),
      );
      return request<{ data: Listing[]; query: string }>(`/search?${query}`);
    },
  },

  conversations: {
    start: (listingId: string) =>
      request<{ data: { id: string } }>('/conversations', {
        method: 'POST',
        body: JSON.stringify({ listingId }),
      }),

    list: () => request<{ data: ConversationSummary[] }>('/conversations'),

    messages: (conversationId: string) =>
      request<{ data: Message[] }>(`/conversations/${conversationId}/messages`),

    send: (
      conversationId: string,
      body: string,
      attachments: Array<{ url: string; mimeType: string }> = [],
    ) =>
      request<{ data: Message }>(`/conversations/${conversationId}/messages`, {
        method: 'POST',
        body: JSON.stringify({ body, attachments }),
      }),
  },

  notifications: {
    list: () => request<{ data: Notification[]; unreadCount: number }>('/notifications'),

    markRead: (id: string) =>
      request<{ data: Notification }>(`/notifications/${id}/read`, { method: 'POST' }),

    markAllRead: () =>
      request<{ data: { updated: number } }>('/notifications/read-all', { method: 'POST' }),
  },

  promotions: {
    catalog: (marketplaceId: string) =>
      request<{ data: PromotionType[] }>(`/promotions/catalog?marketplaceId=${marketplaceId}`),

    updateCatalog: (marketplaceId: string, promotions: PromotionType[]) =>
      request<{ data: PromotionType[] }>('/promotions/catalog', {
        method: 'PATCH',
        body: JSON.stringify({ marketplaceId, promotions }),
      }),

    purchase: (listingId: string, promotionType: string) =>
      request<{
        data: {
          promotion: { id: string; promotionType: string; endAt: string };
          receipt: { amount: number; currency: string; description: string };
        };
      }>('/promotions/purchase', {
        method: 'POST',
        body: JSON.stringify({ listingId, promotionType }),
      }),
  },

  finance: {
    summary: (marketplaceId: string) =>
      request<{ data: FinanceSummary }>(`/admin/finance/summary?marketplaceId=${marketplaceId}`),

    transactions: (marketplaceId: string, cursor?: string) => {
      const query = new URLSearchParams({ marketplaceId, ...(cursor && { cursor }) });
      return request<{ data: AdminTransaction[]; nextCursor: string | null }>(
        `/admin/finance/transactions?${query}`,
      );
    },

    refund: (transactionId: string, reason?: string) =>
      request<{ data: { id: string; status: string } }>(
        `/admin/finance/transactions/${transactionId}/refund`,
        { method: 'POST', body: JSON.stringify({ reason }) },
      ),
  },

  analytics: {
    overview: (marketplaceId: string) =>
      request<{ data: AnalyticsOverview }>(`/admin/analytics/overview?marketplaceId=${marketplaceId}`),
  },

  adminUsers: {
    roles: () => request<{ data: Role[] }>('/admin/users/roles'),

    list: (marketplaceId: string) =>
      request<{ data: AdminUser[]; nextCursor: string | null }>(
        `/admin/users?marketplaceId=${marketplaceId}`,
      ),

    grantRole: (userId: string, roleId: string) =>
      request<{ data: { userId: string; roleId: string } }>(`/admin/users/${userId}/roles`, {
        method: 'POST',
        body: JSON.stringify({ roleId }),
      }),

    revokeRole: (userId: string, roleId: string) =>
      request<void>(`/admin/users/${userId}/roles/${roleId}`, { method: 'DELETE' }),
  },

  moderation: {
    queue: (marketplaceId: string) =>
      request<{ data: ModerationListing[]; nextCursor: string | null }>(
        `/admin/moderation/queue?marketplaceId=${marketplaceId}`,
      ),

    approve: (listingId: string) =>
      request<{ data: { id: string; status: string } }>(
        `/admin/moderation/listings/${listingId}/approve`,
        { method: 'POST' },
      ),

    reject: (listingId: string, note?: string) =>
      request<{ data: { id: string; status: string } }>(
        `/admin/moderation/listings/${listingId}/reject`,
        { method: 'POST', body: JSON.stringify({ note }) },
      ),
  },

  media: {
    upload: (file: File) => {
      const form = new FormData();
      form.append('file', file);
      return request<{ data: UploadedImage }>('/media/upload', { method: 'POST', body: form });
    },
  },

  categories: {
    // Public — powers the storefront category strip.
    list: (marketplaceId: string) =>
      request<{ data: Category[] }>(`/categories?marketplaceId=${marketplaceId}`),

    // Admin-only — flat list including hidden/deleted, for the management UI.
    listAdmin: (marketplaceId: string) =>
      request<{ data: Category[] }>(`/categories/admin?marketplaceId=${marketplaceId}`),

    create: (data: {
      marketplaceId: string;
      name: string;
      slug?: string;
      parentId?: string;
      icon?: string;
    }) => request<{ data: Category }>('/categories', { method: 'POST', body: JSON.stringify(data) }),

    update: (
      id: string,
      data: Partial<{
        name: string;
        slug: string;
        icon: string | null;
        showInNav: boolean;
        displayOrder: number;
        parentId: string | null;
      }>,
    ) =>
      request<{ data: Category }>(`/categories/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(data),
      }),

    reorder: (items: Array<{ id: string; displayOrder: number }>) =>
      request<{ data: { updated: number } }>('/categories/reorder', {
        method: 'POST',
        body: JSON.stringify({ items }),
      }),

    remove: (id: string) => request<void>(`/categories/${id}`, { method: 'DELETE' }),
  },

  geography: {
    listCountries: () => request<{ data: Country[] }>('/geography/countries'),

    listStates: (countryId: string) =>
      request<{ data: StateProvince[] }>(`/geography/states?countryId=${countryId}`),

    listCities: (params: { stateProvinceId?: string; search?: string }) => {
      const query = new URLSearchParams(
        Object.fromEntries(Object.entries(params).filter(([, v]) => v)),
      );
      return request<{ data: City[] }>(`/geography/cities?${query}`);
    },

    getCity: (id: string) => request<{ data: City }>(`/geography/cities/${id}`),

    createCountry: (data: { name: string; code: string }) =>
      request<{ data: Country }>('/geography/countries', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    createState: (data: { countryId: string; name: string; code?: string }) =>
      request<{ data: StateProvince }>('/geography/states', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    createCity: (data: {
      stateProvinceId: string;
      regionId?: string;
      name: string;
      latitude?: number;
      longitude?: number;
    }) =>
      request<{ data: City }>('/geography/cities', { method: 'POST', body: JSON.stringify(data) }),

    removeCountry: (id: string) => request<void>(`/geography/countries/${id}`, { method: 'DELETE' }),
    removeState: (id: string) => request<void>(`/geography/states/${id}`, { method: 'DELETE' }),
    removeCity: (id: string) => request<void>(`/geography/cities/${id}`, { method: 'DELETE' }),

    listRegions: (stateProvinceId: string) =>
      request<{ data: Region[] }>(`/geography/regions?stateProvinceId=${stateProvinceId}`),

    createRegion: (data: { stateProvinceId: string; name: string }) =>
      request<{ data: Region }>('/geography/regions', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    removeRegion: (id: string) => request<void>(`/geography/regions/${id}`, { method: 'DELETE' }),

    listNeighborhoods: (cityId: string) =>
      request<{ data: Neighborhood[] }>(`/geography/neighborhoods?cityId=${cityId}`),

    createNeighborhood: (data: { cityId: string; name: string }) =>
      request<{ data: Neighborhood }>('/geography/neighborhoods', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    removeNeighborhood: (id: string) =>
      request<void>(`/geography/neighborhoods/${id}`, { method: 'DELETE' }),
  },
};
