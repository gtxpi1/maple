import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, Category } from '../api/client';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

// Fetched from GET /api/v1/categories — editable from the backend (via
// prisma/seed.ts today, an admin UI at /admin/categories once it's linked
// up). Nothing here is hardcoded anymore.
export function CategoryStrip() {
  const [categories, setCategories] = useState<Category[] | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();
  const activeSlug = searchParams.get('category');

  useEffect(() => {
    if (!MARKETPLACE_ID) return;
    api.categories
      .list(MARKETPLACE_ID)
      .then((res) => setCategories(res.data))
      .catch(() => setCategories([]));
  }, []);

  const selectCategory = (slug: string | null) => {
    const next = new URLSearchParams(searchParams);
    if (slug) next.set('category', slug);
    else next.delete('category');
    setSearchParams(next);
  };

  if (!categories) return null;

  return (
    <nav className="cat-strip">
      <button className={!activeSlug ? 'active' : ''} onClick={() => selectCategory(null)}>
        All
      </button>
      {categories.map((cat) => (
        <button
          key={cat.id}
          className={activeSlug === cat.slug ? 'active' : ''}
          onClick={() => selectCategory(cat.slug)}
        >
          {cat.icon ? `${cat.icon} ` : ''}
          {cat.name}
        </button>
      ))}
    </nav>
  );
}
