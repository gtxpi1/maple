import { useEffect, useState } from 'react';
import { api, City } from '../api/client';

interface Props {
  value: City | null;
  onChange: (city: City | null) => void;
}

// Type-ahead search against GET /geography/cities?search=... — replaces the
// raw city-id text input. Debounced by hand (no extra dependency) since the
// backend has no rate limiting yet (see docs/07 gaps) and a picker firing a
// request per keystroke would be an easy way to find that out the hard way.
export function CityPicker({ value, onChange }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<City[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (query.length < 2) {
      setResults([]);
      return;
    }
    const timeout = setTimeout(() => {
      api.geography
        .listCities({ search: query })
        .then((res) => setResults(res.data))
        .catch(() => setResults([]));
    }, 250);
    return () => clearTimeout(timeout);
  }, [query]);

  if (value) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input
          value={`${value.name}, ${value.stateProvince?.name ?? ''}`}
          readOnly
          style={{ flex: 1 }}
        />
        <button
          type="button"
          className="btn-secondary"
          style={{ padding: '10px 14px' }}
          onClick={() => onChange(null)}
        >
          Change
        </button>
      </div>
    );
  }

  return (
    <div style={{ position: 'relative' }}>
      <input
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        placeholder="Start typing a city…"
      />
      {open && results.length > 0 && (
        <div
          style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            background: 'white',
            border: '1.5px solid var(--line)',
            borderRadius: 8,
            marginTop: 4,
            boxShadow: '0 8px 20px rgba(22,24,29,0.12)',
            zIndex: 10,
            maxHeight: 200,
            overflowY: 'auto',
          }}
        >
          {results.map((city) => (
            <div
              key={city.id}
              onClick={() => {
                onChange(city);
                setOpen(false);
                setQuery('');
              }}
              style={{ padding: '10px 12px', cursor: 'pointer', fontSize: 13.5 }}
              onMouseDown={(e) => e.preventDefault()}
            >
              {city.name}
              {city.stateProvince && (
                <span style={{ color: 'var(--gray)' }}>
                  , {city.stateProvince.name}, {city.stateProvince.country.name}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
