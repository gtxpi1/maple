export function RibbonBadge({ type }: { type: 'new' | 'featured' | 'verified' }) {
  const label = { new: 'NEW', featured: 'FEATURED', verified: 'VERIFIED' }[type];
  return (
    <div className="ribbon-wrap">
      <div className={`ribbon ${type}`}>{label}</div>
    </div>
  );
}
