import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { NotificationBell } from './NotificationBell';

export function Header() {
  const { user, logout } = useAuth();
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  return (
    <header className="header">
      <Link to="/" className="logo">
        <div className="logo-mark">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path
              d="M12 2L14.5 8L21 9L16 13.5L17.5 20L12 16.5L6.5 20L8 13.5L3 9L9.5 8L12 2Z"
              fill="white"
            />
          </svg>
        </div>
        <span className="logo-text">maple</span>
      </Link>

      <form className="search-bar" onSubmit={onSearch}>
        <input
          type="text"
          placeholder="Search bikes, apartments, guitars, jobs…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button type="submit">SEARCH</button>
      </form>

      <div className="header-right">
        {user ? (
          <>
            {user.roles.includes('admin') && (
              <Link to="/admin" className="header-link">
                Admin
              </Link>
            )}
            <span className="header-link">Hi, {user.displayName}</span>
            <NotificationBell />
            <Link to="/saved" className="header-link">
              Saved
            </Link>
            <Link to="/security" className="header-link">
              Security
            </Link>
            <Link to="/messages" className="header-link">
              Messages
            </Link>
            <button className="header-link" onClick={logout} style={{ background: 'none' }}>
              Log out
            </button>
          </>
        ) : (
          <Link to="/login" className="header-link">
            Log in
          </Link>
        )}
        <Link to="/post-ad" className="btn-post">
          + Post an ad
        </Link>
      </div>
    </header>
  );
}
