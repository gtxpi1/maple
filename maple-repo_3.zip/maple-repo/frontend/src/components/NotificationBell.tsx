import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, Notification } from '../api/client';
import { useAuth } from '../context/AuthContext';

const POLL_INTERVAL_MS = 15_000;

function describe(n: Notification): string {
  if (n.type === 'message') {
    const preview = typeof n.payload.preview === 'string' ? n.payload.preview : '';
    return preview ? `New message: "${preview}"` : 'New message';
  }
  return `Notification: ${n.type}`;
}

export function NotificationBell() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const load = () => {
    api.notifications
      .list()
      .then((res) => {
        setNotifications(res.data);
        setUnreadCount(res.unreadCount);
      })
      .catch(() => {
        /* silent — a failed notification poll shouldn't surface an error banner */
      });
  };

  useEffect(() => {
    if (!user) return;
    load();
    const interval = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  if (!user) return null;

  const onOpenNotification = async (n: Notification) => {
    if (!n.readAt) {
      await api.notifications.markRead(n.id);
      load();
    }
    setOpen(false);
    if (n.type === 'message' && typeof n.payload.conversationId === 'string') {
      navigate(`/messages/${n.payload.conversationId}`);
    }
  };

  return (
    <div ref={containerRef} style={{ position: 'relative' }}>
      <button
        className="header-link"
        style={{ background: 'none', position: 'relative' }}
        onClick={() => setOpen((v) => !v)}
      >
        🔔
        {unreadCount > 0 && (
          <span
            className="mono"
            style={{
              position: 'absolute',
              top: -4,
              right: -8,
              background: 'var(--maple-red)',
              color: 'white',
              fontSize: 9,
              fontWeight: 700,
              borderRadius: 10,
              padding: '1px 5px',
              minWidth: 14,
              textAlign: 'center',
            }}
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div
          style={{
            position: 'absolute',
            top: '100%',
            right: 0,
            marginTop: 8,
            width: 320,
            maxHeight: 400,
            overflowY: 'auto',
            background: 'white',
            borderRadius: 10,
            boxShadow: '0 12px 28px rgba(22,24,29,0.2)',
            zIndex: 100,
          }}
        >
          {notifications.length === 0 && (
            <div className="state-message" style={{ padding: 24 }}>
              No notifications yet.
            </div>
          )}
          {notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => onOpenNotification(n)}
              style={{
                padding: '12px 14px',
                borderBottom: '1px solid var(--line)',
                cursor: 'pointer',
                background: n.readAt ? 'white' : 'var(--paper-dim)',
                fontSize: 12.5,
                color: 'var(--ink)',
              }}
            >
              <div>{describe(n)}</div>
              <div style={{ fontSize: 10.5, color: 'var(--gray)', marginTop: 3 }}>
                {new Date(n.createdAt).toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
