import { useEffect, useState } from 'react';
import { api, Listing, PromotionType } from '../api/client';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

interface Props {
  listing: Listing;
  onPromoted: () => void;
}

export function PromotePanel({ listing, onPromoted }: Props) {
  const [catalog, setCatalog] = useState<PromotionType[] | null>(null);
  const [purchasing, setPurchasing] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<string | null>(null);

  useEffect(() => {
    api.promotions
      .catalog(MARKETPLACE_ID)
      .then((res) => setCatalog(res.data))
      .catch(() => setCatalog([]));
  }, []);

  const activeTypes = new Set(listing.promotions.map((p) => p.promotionType));

  const purchase = async (promotionType: string) => {
    setPurchasing(promotionType);
    setError(null);
    setReceipt(null);
    try {
      const res = await api.promotions.purchase(listing.id, promotionType);
      setReceipt(
        `Charged $${res.data.receipt.amount.toFixed(2)} ${res.data.receipt.currency} — ${res.data.receipt.description}`,
      );
      onPromoted();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not purchase promotion.');
    } finally {
      setPurchasing(null);
    }
  };

  return (
    <div className="sidebar-card" style={{ marginTop: 14 }}>
      <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 10 }}>Promote this listing</div>

      {error && <div className="form-error">{error}</div>}
      {receipt && (
        <div
          style={{
            background: '#e8f5ee',
            color: 'var(--leaf)',
            padding: '8px 12px',
            borderRadius: 8,
            fontSize: 12,
            marginBottom: 10,
          }}
        >
          {receipt} (demo payment — no real charge)
        </div>
      )}

      {catalog === null && <div className="state-message">Loading…</div>}

      {catalog?.map((promo) => {
        const isActive = activeTypes.has(promo.id);
        return (
          <div
            key={promo.id}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '10px 0',
              borderBottom: '1px solid var(--line)',
            }}
          >
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700 }}>{promo.label}</div>
              <div style={{ fontSize: 11, color: 'var(--gray)' }}>{promo.description}</div>
            </div>
            <button
              className="btn-secondary"
              style={{ padding: '6px 12px', fontSize: 11, whiteSpace: 'nowrap' }}
              disabled={isActive || purchasing !== null}
              onClick={() => purchase(promo.id)}
            >
              {isActive
                ? 'Active'
                : purchasing === promo.id
                  ? '…'
                  : `$${(promo.priceCents / 100).toFixed(2)}`}
            </button>
          </div>
        );
      })}

      <p style={{ fontSize: 10.5, color: 'var(--gray)', marginTop: 10 }}>
        Payments are simulated in this environment — see backend/README.md.
      </p>
    </div>
  );
}
