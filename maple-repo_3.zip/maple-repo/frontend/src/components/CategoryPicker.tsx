import { useEffect, useState } from 'react';
import { api, Category } from '../api/client';

interface Props {
  value: string;
  onChange: (categoryId: string) => void;
  marketplaceId: string;
}

interface FlatOption {
  id: string;
  label: string;
}

function flatten(categories: Category[], depth = 0): FlatOption[] {
  return categories.flatMap((cat) => [
    { id: cat.id, label: `${'— '.repeat(depth)}${cat.icon ? cat.icon + ' ' : ''}${cat.name}` },
    ...(cat.subcategories ? flatten(cat.subcategories, depth + 1) : []),
  ]);
}

export function CategoryPicker({ value, onChange, marketplaceId }: Props) {
  const [options, setOptions] = useState<FlatOption[] | null>(null);

  useEffect(() => {
    if (!marketplaceId) return;
    api.categories
      .list(marketplaceId)
      .then((res) => setOptions(flatten(res.data)))
      .catch(() => setOptions([]));
  }, [marketplaceId]);

  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} required>
      <option value="" disabled>
        {options === null ? 'Loading categories…' : 'Select a category'}
      </option>
      {options?.map((opt) => (
        <option key={opt.id} value={opt.id}>
          {opt.label}
        </option>
      ))}
    </select>
  );
}
