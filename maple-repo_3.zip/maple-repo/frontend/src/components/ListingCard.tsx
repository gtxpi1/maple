import { Link } from 'react-router-dom';
import { Listing } from '../api/client';

// NEW is still a display heuristic (posted in the last 24h) since there's
// no "featured" equivalent for organic freshness. FEATURED, in contrast,
// now reflects a real purchased ListingPromotion row (see
// docs/16-promotion-engine-design.md and backend/src/routes/promotions.routes.ts)
// — it takes priority over NEW since it's something the seller paid for.
function isRecent(createdAt: string): boolean {
  return Date.now() - new Date(createdAt).getTime() < 24 * 60 * 60 * 1000;
}

const API_ORIGIN = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1').replace(
  '/api/v1',
  '',
);

export function ListingCard({ listing }: { listing: Listing }) {
  const firstImage = listing.images[0];
  const mediumVariant = firstImage?.uploadedFile.variants.find((v) => v.size === 'medium');
  const imageUrl = mediumVariant
    ? `${API_ORIGIN}${mediumVariant.url}`
    : firstImage
      ? `${API_ORIGIN}${firstImage.uploadedFile.originalUrl}`
      : null;

  const isFeatured = listing.promotions.some((p) => p.promotionType === 'featured');

  return (
    <Link to={`/listings/${listing.id}`} className="listing-card">
      <div
        className="listing-img"
        style={imageUrl ? { backgroundImage: `url(${imageUrl})` } : undefined}
      >
        {isFeatured ? (
          <div className="ribbon-wrap">
            <div className="ribbon featured">FEATURED</div>
          </div>
        ) : (
          isRecent(listing.createdAt) && (
            <div className="ribbon-wrap">
              <div className="ribbon new">NEW</div>
            </div>
          )
        )}
      </div>
      <div className="listing-body">
        <div className="listing-price">{listing.price ? `$${listing.price}` : 'Free'}</div>
        <div className="listing-title">{listing.title}</div>
        <div className="listing-meta">
          <span>{listing.city?.name ?? ''}</span>
          <span>{new Date(listing.createdAt).toLocaleDateString()}</span>
        </div>
      </div>
    </Link>
  );
}
