import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, City, Listing, Neighborhood } from '../api/client';
import { ListingCard } from '../components/ListingCard';
import { CityPicker } from '../components/CityPicker';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function Home() {
  const [listings, setListings] = useState<Listing[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [searchParams, setSearchParams] = useSearchParams();
  const categorySlug = searchParams.get('category') || undefined;

  const [filterCity, setFilterCity] = useState<City | null>(null);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [filterNeighborhoodId, setFilterNeighborhoodIdRaw] = useState('');
  const [restoringCity, setRestoringCity] = useState(false);

  // Restore filterCity from ?city= on first load (page refresh, shared
  // link, back/forward) — this is what GET /geography/cities/:id exists
  // for. Only runs once; user-driven changes after that go through
  // selectCity/selectNeighborhood below, which write to the URL directly
  // instead of relying on this effect re-reading it.
  useEffect(() => {
    const cityId = searchParams.get('city');
    if (!cityId) return;
    setRestoringCity(true);
    api.geography
      .getCity(cityId)
      .then((res) => setFilterCity(res.data))
      .catch(() => {
        // Stale/invalid city id in the URL — drop it rather than leave the
        // UI stuck loading a filter that can never resolve.
        const next = new URLSearchParams(searchParams);
        next.delete('city');
        next.delete('neighborhood');
        setSearchParams(next, { replace: true });
      })
      .finally(() => setRestoringCity(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!filterCity) {
      setNeighborhoods([]);
      return;
    }
    api.geography
      .listNeighborhoods(filterCity.id)
      .then((res) => {
        setNeighborhoods(res.data);
        // Restore ?neighborhood= too, but only if it's actually a
        // neighborhood of the city we just loaded — a stale/mismatched
        // param is silently dropped rather than applied to the wrong city.
        const neighborhoodId = searchParams.get('neighborhood');
        if (neighborhoodId && res.data.some((n) => n.id === neighborhoodId)) {
          setFilterNeighborhoodIdRaw(neighborhoodId);
        }
      })
      .catch(() => setNeighborhoods([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterCity]);

  const selectCity = (city: City | null) => {
    setFilterCity(city);
    setFilterNeighborhoodIdRaw('');
    const next = new URLSearchParams(searchParams);
    if (city) next.set('city', city.id);
    else next.delete('city');
    next.delete('neighborhood');
    setSearchParams(next);
  };

  const selectNeighborhood = (neighborhoodId: string) => {
    setFilterNeighborhoodIdRaw(neighborhoodId);
    const next = new URLSearchParams(searchParams);
    if (neighborhoodId) next.set('neighborhood', neighborhoodId);
    else next.delete('neighborhood');
    setSearchParams(next);
  };

  useEffect(() => {
    if (!MARKETPLACE_ID) {
      setError(
        'VITE_MARKETPLACE_ID is not set. Run the backend seed script and copy the marketplace id into frontend/.env.',
      );
      return;
    }
    if (restoringCity) return; // avoid a flash of unfiltered results while ?city= resolves

    setListings(null);
    api.listings
      .list({
        marketplaceId: MARKETPLACE_ID,
        categorySlug,
        cityId: filterCity?.id,
        neighborhoodId: filterNeighborhoodId || undefined,
      })
      .then((res) => setListings(res.data))
      .catch((err) => setError(err.message));
  }, [categorySlug, filterCity, filterNeighborhoodId, restoringCity]);

  return (
    <div className="page">
      <div className="section-head">
        <h2 className="display">{categorySlug ? categorySlug.replace(/-/g, ' ') : 'Fresh nearby'}</h2>
      </div>

      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 18, maxWidth: 480 }}>
        <div style={{ flex: 1 }}>
          <CityPicker value={filterCity} onChange={selectCity} />
        </div>
        {filterCity && neighborhoods.length > 0 && (
          <select
            value={filterNeighborhoodId}
            onChange={(e) => selectNeighborhood(e.target.value)}
            style={{ padding: '10px 12px', border: '1.5px solid var(--line)', borderRadius: 8, fontSize: 13.5 }}
          >
            <option value="">All neighborhoods</option>
            {neighborhoods.map((n) => (
              <option key={n.id} value={n.id}>
                {n.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {error && <div className="form-error">{error}</div>}

      {!error && listings === null && <div className="state-message">Loading listings…</div>}

      {listings?.length === 0 && (
        <div className="state-message">
          No listings here yet.{' '}
          {categorySlug || filterCity ? 'Try different filters or ' : ''}
          Be the first — post an ad to get started. New listings need admin
          approval (see /admin/moderation) before they appear here.
        </div>
      )}

      <div className="listing-grid">
        {listings?.map((listing) => (
          <ListingCard key={listing.id} listing={listing} />
        ))}
      </div>
    </div>
  );
}
