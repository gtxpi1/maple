import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ConversationSummary } from '../api/client';
import { useAuth } from '../context/AuthContext';

export function Messages() {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<ConversationSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    api.conversations
      .list()
      .then((res) => setConversations(res.data))
      .catch((err) => setError(err.message));
  }, [user]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in to see your messages. <a href="/login">Log in</a>
      </div>
    );
  }

  return (
    <div className="page" style={{ maxWidth: 700 }}>
      <div className="section-head">
        <h2 className="display">Messages</h2>
      </div>

      {error && <div className="form-error">{error}</div>}
      {conversations === null && <div className="state-message">Loading…</div>}
      {conversations?.length === 0 && (
        <div className="state-message">
          No conversations yet. Message a seller from a listing to start one.
        </div>
      )}

      <div
        style={{
          background: 'white',
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
        }}
      >
        {conversations?.map((c) => (
          <Link
            key={c.id}
            to={`/messages/${c.id}`}
            style={{
              display: 'block',
              padding: '14px 18px',
              borderBottom: '1px solid var(--line)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontWeight: 700, fontSize: 13.5 }}>
                {c.otherParticipant?.displayName ?? 'Unknown user'}
              </span>
              <span style={{ fontSize: 11, color: 'var(--gray)' }}>
                {new Date(c.updatedAt).toLocaleDateString()}
              </span>
            </div>
            {c.listing && (
              <div className="mono" style={{ fontSize: 11, color: 'var(--maple-red-dark)', marginBottom: 4 }}>
                re: {c.listing.title}
              </div>
            )}
            <div style={{ fontSize: 12.5, color: 'var(--gray)' }}>
              {c.lastMessage?.body ?? 'No messages yet'}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
