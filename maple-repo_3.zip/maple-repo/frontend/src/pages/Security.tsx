import { FormEvent, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';

export function Security() {
  const { user } = useAuth();

  const [setupData, setSetupData] = useState<{ secret: string; qrCodeDataUrl: string } | null>(
    null,
  );
  const [verifyToken, setVerifyToken] = useState('');
  const [disablePassword, setDisablePassword] = useState('');
  const [mfaEnabled, setMfaEnabled] = useState(user?.mfaEnabled ?? false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!user) {
    return (
      <div className="page state-message">
        Log in to manage your security settings. <a href="/login">Log in</a>
      </div>
    );
  }

  const startSetup = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await api.auth.mfaSetup();
      setSetupData(res.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start MFA setup.');
    } finally {
      setBusy(false);
    }
  };

  const submitVerify = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.auth.mfaVerify(verifyToken);
      setMfaEnabled(true);
      setSetupData(null);
      setVerifyToken('');
      setMessage('MFA is now enabled on your account.');
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Invalid code — check your authenticator app and try again.',
      );
    } finally {
      setBusy(false);
    }
  };

  const submitDisable = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.auth.mfaDisable(disablePassword);
      setMfaEnabled(false);
      setDisablePassword('');
      setMessage('MFA has been disabled.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not disable MFA — check your password.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="form-card" style={{ maxWidth: 480 }}>
      <h1>Two-factor authentication</h1>
      {error && <div className="form-error">{error}</div>}
      {message && (
        <div
          style={{
            background: '#e8f5ee',
            color: 'var(--leaf)',
            padding: '10px 14px',
            borderRadius: 8,
            fontSize: 13,
            marginBottom: 16,
          }}
        >
          {message}
        </div>
      )}

      {mfaEnabled ? (
        <>
          <p style={{ fontSize: 13, color: 'var(--gray)', marginBottom: 16 }}>
            MFA is currently <strong style={{ color: 'var(--leaf)' }}>enabled</strong> on your
            account. Disabling it requires your password.
          </p>
          <form onSubmit={submitDisable}>
            <div className="form-field">
              <label>Password</label>
              <input
                type="password"
                value={disablePassword}
                onChange={(e) => setDisablePassword(e.target.value)}
                required
              />
            </div>
            <button className="btn-secondary" style={{ width: '100%' }} disabled={busy}>
              {busy ? '…' : 'Disable MFA'}
            </button>
          </form>
        </>
      ) : setupData ? (
        <>
          <p style={{ fontSize: 13, color: 'var(--gray)', marginBottom: 12 }}>
            Scan this with an authenticator app (Google Authenticator, 1Password, Authy), then
            enter the 6-digit code it shows to confirm.
          </p>
          <img
            src={setupData.qrCodeDataUrl}
            alt="MFA QR code"
            style={{ display: 'block', margin: '0 auto 12px', width: 200, height: 200 }}
          />
          <p
            className="mono"
            style={{ fontSize: 11, color: 'var(--gray)', textAlign: 'center', marginBottom: 16 }}
          >
            {setupData.secret}
          </p>
          <form onSubmit={submitVerify}>
            <div className="form-field">
              <label>6-digit code</label>
              <input
                value={verifyToken}
                onChange={(e) => setVerifyToken(e.target.value)}
                maxLength={6}
                inputMode="numeric"
                required
              />
            </div>
            <button className="btn-primary" style={{ width: '100%' }} disabled={busy}>
              {busy ? '…' : 'Confirm and enable'}
            </button>
          </form>
        </>
      ) : (
        <>
          <p style={{ fontSize: 13, color: 'var(--gray)', marginBottom: 16 }}>
            MFA is currently <strong>not enabled</strong>. Adding it means logging in will require
            both your password and a code from an authenticator app.
          </p>
          <button
            className="btn-primary"
            style={{ width: '100%' }}
            onClick={startSetup}
            disabled={busy}
          >
            {busy ? '…' : 'Set up MFA'}
          </button>
        </>
      )}
    </div>
  );
}
