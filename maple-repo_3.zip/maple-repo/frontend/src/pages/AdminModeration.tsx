import { FormEvent, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ModerationListing } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';
const API_ORIGIN = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1').replace(
  '/api/v1',
  '',
);

export function AdminModeration() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [queue, setQueue] = useState<ModerationListing[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectNote, setRejectNote] = useState('');

  const load = () =>
    api.moderation
      .queue(MARKETPLACE_ID)
      .then((res) => setQueue(res.data))
      .catch((err) => setError(err.message));

  useEffect(() => {
    if (isAdmin) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to review listings. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }

  const approve = async (id: string) => {
    setBusyId(id);
    setError(null);
    try {
      await api.moderation.approve(id);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not approve listing.');
    } finally {
      setBusyId(null);
    }
  };

  const submitReject = async (e: FormEvent, id: string) => {
    e.preventDefault();
    setBusyId(id);
    setError(null);
    try {
      await api.moderation.reject(id, rejectNote || undefined);
      setRejectingId(null);
      setRejectNote('');
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not reject listing.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="section-head">
        <h2 className="display">Moderation queue</h2>
      </div>

      {error && <div className="form-error">{error}</div>}
      {queue === null && <div className="state-message">Loading…</div>}
      {queue?.length === 0 && (
        <div className="state-message">Nothing waiting for review.</div>
      )}

      {queue?.map((listing) => {
        const firstImage = listing.images[0];
        const thumbUrl = firstImage
          ? `${API_ORIGIN}${firstImage.uploadedFile.variants.find((v) => v.size === 'medium')?.url ?? firstImage.uploadedFile.originalUrl}`
          : null;
        const anyFlagged = listing.images.some((img) =>
          img.uploadedFile.moderationResults.some((m) => m.flagged),
        );

        return (
          <div
            key={listing.id}
            className="sidebar-card"
            style={{ display: 'flex', gap: 16, marginBottom: 14 }}
          >
            <div
              style={{
                width: 120,
                height: 90,
                borderRadius: 8,
                backgroundColor: 'var(--paper-dim)',
                backgroundImage: thumbUrl ? `url(${thumbUrl})` : undefined,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                flexShrink: 0,
              }}
            />

            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <Link to={`/listings/${listing.id}`} style={{ fontWeight: 700, fontSize: 14 }}>
                  {listing.title}
                </Link>
                <span className="mono" style={{ fontWeight: 700, color: 'var(--maple-red-dark)' }}>
                  {listing.price ? `$${listing.price}` : 'Free'}
                </span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--gray)', marginTop: 2 }}>
                {listing.user.displayName} ({listing.user.email}) · {listing.category?.name} ·{' '}
                {listing.city?.name} · {new Date(listing.createdAt).toLocaleString()}
              </div>
              {anyFlagged && (
                <div style={{ fontSize: 11, color: 'var(--maple-red-dark)', marginTop: 4, fontWeight: 700 }}>
                  ⚠ AI moderation flagged at least one photo
                </div>
              )}
              <p style={{ fontSize: 12.5, color: 'var(--ink)', marginTop: 8 }}>
                {listing.description.length > 200
                  ? listing.description.slice(0, 200) + '…'
                  : listing.description}
              </p>

              {rejectingId === listing.id ? (
                <form onSubmit={(e) => submitReject(e, listing.id)} style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                  <input
                    value={rejectNote}
                    onChange={(e) => setRejectNote(e.target.value)}
                    placeholder="Reason (optional)"
                    style={{ flex: 1, padding: '6px 10px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12 }}
                  />
                  <button className="btn-secondary" style={{ padding: '6px 12px', fontSize: 12 }} disabled={busyId === listing.id}>
                    Confirm reject
                  </button>
                  <button
                    type="button"
                    className="btn-secondary"
                    style={{ padding: '6px 12px', fontSize: 12 }}
                    onClick={() => setRejectingId(null)}
                  >
                    Cancel
                  </button>
                </form>
              ) : (
                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  <button
                    className="btn-primary"
                    style={{ padding: '6px 14px', fontSize: 12 }}
                    disabled={busyId === listing.id}
                    onClick={() => approve(listing.id)}
                  >
                    {busyId === listing.id ? '…' : 'Approve'}
                  </button>
                  <button
                    className="btn-secondary"
                    style={{ padding: '6px 14px', fontSize: 12, color: 'var(--maple-red-dark)' }}
                    disabled={busyId === listing.id}
                    onClick={() => setRejectingId(listing.id)}
                  >
                    Reject
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      })}

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 8 }}>
        Every listing starts as PENDING_REVIEW and only appears on the
        homepage/search once approved here. Approving/rejecting appends a
        row to that listing's status history rather than just flipping a
        field silently.
      </p>
    </div>
  );
}
