import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, City, Listing, Neighborhood } from '../api/client';
import { ListingCard } from '../components/ListingCard';
import { CityPicker } from '../components/CityPicker';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function SearchResults() {
  const [searchParams, setSearchParams] = useSearchParams();
  const q = searchParams.get('q') || '';
  const [listings, setListings] = useState<Listing[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [filterCity, setFilterCity] = useState<City | null>(null);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [filterNeighborhoodId, setFilterNeighborhoodIdRaw] = useState('');
  const [restoringCity, setRestoringCity] = useState(false);

  // Same URL-persistence pattern as Home.tsx — see the comments there for
  // why this needs GET /geography/cities/:id and why restoration only
  // runs once on mount.
  useEffect(() => {
    const cityId = searchParams.get('city');
    if (!cityId) return;
    setRestoringCity(true);
    api.geography
      .getCity(cityId)
      .then((res) => setFilterCity(res.data))
      .catch(() => {
        const next = new URLSearchParams(searchParams);
        next.delete('city');
        next.delete('neighborhood');
        setSearchParams(next, { replace: true });
      })
      .finally(() => setRestoringCity(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!filterCity) {
      setNeighborhoods([]);
      return;
    }
    api.geography
      .listNeighborhoods(filterCity.id)
      .then((res) => {
        setNeighborhoods(res.data);
        const neighborhoodId = searchParams.get('neighborhood');
        if (neighborhoodId && res.data.some((n) => n.id === neighborhoodId)) {
          setFilterNeighborhoodIdRaw(neighborhoodId);
        }
      })
      .catch(() => setNeighborhoods([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterCity]);

  const selectCity = (city: City | null) => {
    setFilterCity(city);
    setFilterNeighborhoodIdRaw('');
    const next = new URLSearchParams(searchParams);
    if (city) next.set('city', city.id);
    else next.delete('city');
    next.delete('neighborhood');
    setSearchParams(next);
  };

  const selectNeighborhood = (neighborhoodId: string) => {
    setFilterNeighborhoodIdRaw(neighborhoodId);
    const next = new URLSearchParams(searchParams);
    if (neighborhoodId) next.set('neighborhood', neighborhoodId);
    else next.delete('neighborhood');
    setSearchParams(next);
  };

  useEffect(() => {
    if (!q) {
      setListings([]);
      return;
    }
    if (restoringCity) return;
    setListings(null);
    api.search
      .listings({
        marketplaceId: MARKETPLACE_ID,
        q,
        cityId: filterCity?.id,
        neighborhoodId: filterNeighborhoodId || undefined,
      })
      .then((res) => setListings(res.data))
      .catch((err) => setError(err.message));
  }, [q, filterCity, filterNeighborhoodId, restoringCity]);

  return (
    <div className="page">
      <div className="section-head">
        <h2 className="display">{q ? `Results for "${q}"` : 'Search'}</h2>
      </div>

      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 18, maxWidth: 480 }}>
        <div style={{ flex: 1 }}>
          <CityPicker value={filterCity} onChange={selectCity} />
        </div>
        {filterCity && neighborhoods.length > 0 && (
          <select
            value={filterNeighborhoodId}
            onChange={(e) => selectNeighborhood(e.target.value)}
            style={{ padding: '10px 12px', border: '1.5px solid var(--line)', borderRadius: 8, fontSize: 13.5 }}
          >
            <option value="">All neighborhoods</option>
            {neighborhoods.map((n) => (
              <option key={n.id} value={n.id}>
                {n.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {error && <div className="form-error">{error}</div>}
      {!error && listings === null && <div className="state-message">Searching…</div>}
      {listings?.length === 0 && q && (
        <div className="state-message">No listings match "{q}". Try different words or filters.</div>
      )}

      <div className="listing-grid">
        {listings?.map((listing) => (
          <ListingCard key={listing.id} listing={listing} />
        ))}
      </div>
    </div>
  );
}
