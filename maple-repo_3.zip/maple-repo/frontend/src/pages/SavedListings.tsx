import { useEffect, useState } from 'react';
import { api, Listing } from '../api/client';
import { ListingCard } from '../components/ListingCard';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function SavedListings() {
  const { user } = useAuth();
  const [listings, setListings] = useState<Listing[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    api.listings
      .listSaved(MARKETPLACE_ID)
      .then((res) => setListings(res.data))
      .catch((err) => setError(err.message));
  }, [user]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in to see your saved listings. <a href="/login">Log in</a>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="section-head">
        <h2 className="display">Saved</h2>
      </div>

      {error && <div className="form-error">{error}</div>}
      {listings === null && <div className="state-message">Loading…</div>}
      {listings?.length === 0 && (
        <div className="state-message">
          Nothing saved yet — tap "Save" on a listing to keep it here.
        </div>
      )}

      <div className="listing-grid">
        {listings?.map((listing) => (
          <ListingCard key={listing.id} listing={listing} />
        ))}
      </div>
    </div>
  );
}
