import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, AnalyticsOverview, FinanceSummary } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

interface Section {
  title: string;
  description: string;
  href: string;
  icon: string;
}

const SECTIONS: Section[] = [
  {
    title: 'Categories',
    description: 'Add, reorder, show/hide, and delete listing categories.',
    href: '/admin/categories',
    icon: '🗂️',
  },
  {
    title: 'Geography',
    description: 'Manage countries, states, regions, cities, and neighborhoods.',
    href: '/admin/geography',
    icon: '🌍',
  },
  {
    title: 'Promotions',
    description: 'Edit pricing, duration, and description for each promotion type.',
    href: '/admin/promotions',
    icon: '⭐',
  },
  {
    title: 'Finance',
    description: 'Revenue, transaction ledger, and refunds.',
    href: '/admin/finance',
    icon: '💰',
  },
  {
    title: 'Analytics',
    description: 'User count, listing breakdown, and signup trend.',
    href: '/admin/analytics',
    icon: '📊',
  },
  {
    title: 'Users',
    description: 'Grant or revoke the admin role for any user.',
    href: '/admin/users',
    icon: '👤',
  },
  {
    title: 'Moderation',
    description: 'Approve or reject listings waiting for review.',
    href: '/admin/moderation',
    icon: '🛡️',
  },
];

export function AdminDashboard() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [finance, setFinance] = useState<FinanceSummary | null>(null);
  const [overview, setOverview] = useState<AnalyticsOverview | null>(null);

  useEffect(() => {
    if (!isAdmin) return;
    api.finance.summary(MARKETPLACE_ID).then((res) => setFinance(res.data)).catch(() => {});
    api.analytics.overview(MARKETPLACE_ID).then((res) => setOverview(res.data)).catch(() => {});
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to access the dashboard. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }

  return (
    <div className="page" style={{ maxWidth: 1000 }}>
      <div className="section-head">
        <h2 className="display">Admin</h2>
      </div>

      <div style={{ display: 'flex', gap: 16, marginBottom: 28 }}>
        <div className="sidebar-card" style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>REVENUE</div>
          <div className="mono" style={{ fontSize: 22, fontWeight: 700, color: 'var(--leaf)' }}>
            {finance ? `$${finance.totalRevenue.toFixed(2)}` : '—'}
          </div>
        </div>
        <div className="sidebar-card" style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>USERS</div>
          <div className="mono" style={{ fontSize: 22, fontWeight: 700 }}>
            {overview ? overview.userCount : '—'}
          </div>
        </div>
        <div className="sidebar-card" style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>LISTINGS</div>
          <div className="mono" style={{ fontSize: 22, fontWeight: 700 }}>
            {overview ? overview.totalListings : '—'}
          </div>
        </div>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
          gap: 16,
        }}
      >
        {SECTIONS.map((s) => (
          <Link
            key={s.href}
            to={s.href}
            className="sidebar-card"
            style={{ display: 'block' }}
          >
            <div style={{ fontSize: 22, marginBottom: 8 }}>{s.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{s.title}</div>
            <div style={{ fontSize: 12, color: 'var(--gray)', lineHeight: 1.4 }}>
              {s.description}
            </div>
          </Link>
        ))}
      </div>

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 24 }}>
        This is a landing page linking to the five admin sections that
        exist — not a unified dashboard with shared filters or a combined
        activity feed. Each section still loads its own data independently.
      </p>
    </div>
  );
}
