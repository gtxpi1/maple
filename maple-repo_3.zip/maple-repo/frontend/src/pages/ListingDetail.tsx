import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, Listing } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { PromotePanel } from '../components/PromotePanel';

const API_ORIGIN = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1').replace(
  '/api/v1',
  '',
);
const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function ListingDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [listing, setListing] = useState<Listing | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [messaging, setMessaging] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [saved, setSaved] = useState(false);
  const [savingToggle, setSavingToggle] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editPrice, setEditPrice] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  const load = () => {
    if (!id) return;
    api.listings
      .get(id)
      .then((res) => setListing(res.data))
      .catch((err) => setError(err.message));
  };

  useEffect(load, [id]);

  // Whether this listing is saved isn't part of GET /listings/:id's
  // response (no per-request auth context baked into that endpoint), so
  // this checks membership in the user's full saved list instead of a
  // dedicated is-saved check — simplest option without adding another
  // endpoint, at the cost of fetching the whole list just to check one id.
  useEffect(() => {
    if (!user || !id) {
      setSaved(false);
      return;
    }
    api.listings
      .listSaved(MARKETPLACE_ID)
      .then((res) => setSaved(res.data.some((l) => l.id === id)))
      .catch(() => setSaved(false));
  }, [user, id]);

  const toggleSave = async () => {
    if (!id) return;
    if (!user) {
      navigate('/login');
      return;
    }
    setSavingToggle(true);
    setError(null);
    try {
      if (saved) {
        await api.listings.unsave(id);
        setSaved(false);
      } else {
        await api.listings.save(id);
        setSaved(true);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update saved status.');
    } finally {
      setSavingToggle(false);
    }
  };

  const onMessageSeller = async () => {
    if (!id) return;
    if (!user) {
      navigate('/login');
      return;
    }
    setMessaging(true);
    setError(null);
    try {
      const res = await api.conversations.start(id);
      navigate(`/messages/${res.data.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not start conversation.');
    } finally {
      setMessaging(false);
    }
  };

  const toggleSold = async () => {
    if (!id || !listing) return;
    setUpdating(true);
    setError(null);
    try {
      await api.listings.update(id, { status: listing.status === 'SOLD' ? 'ACTIVE' : 'SOLD' });
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update listing.');
    } finally {
      setUpdating(false);
    }
  };

  const deleteListing = async () => {
    if (!id) return;
    if (!confirm('Delete this listing? This can\'t be undone.')) return;
    setUpdating(true);
    setError(null);
    try {
      await api.listings.remove(id);
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete listing.');
      setUpdating(false);
    }
  };

  const startEdit = () => {
    if (!listing) return;
    setEditTitle(listing.title);
    setEditDescription(listing.description);
    setEditPrice(listing.price ?? '');
    setEditing(true);
  };

  const submitEdit = async () => {
    if (!id) return;
    setSavingEdit(true);
    setError(null);
    try {
      await api.listings.update(id, {
        title: editTitle,
        description: editDescription,
        price: editPrice === '' ? undefined : Number(editPrice),
      });
      setEditing(false);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save changes.');
    } finally {
      setSavingEdit(false);
    }
  };

  if (error && !listing) return <div className="page state-message">{error}</div>;
  if (!listing) return <div className="page state-message">Loading…</div>;

  const mainImage = listing.images[0];
  const mainImageUrl = mainImage
    ? `${API_ORIGIN}${mainImage.uploadedFile.variants.find((v) => v.size === 'medium')?.url ?? mainImage.uploadedFile.originalUrl}`
    : null;

  const isOwnListing = user?.id === listing.user?.id;
  const isFeatured = listing.promotions.some((p) => p.promotionType === 'featured');

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div
        className="listing-img"
        style={{
          height: 420,
          borderRadius: 14,
          boxShadow: '0 12px 24px rgba(22,24,29,0.1)',
          backgroundImage: mainImageUrl ? `url(${mainImageUrl})` : undefined,
        }}
      >
        {isFeatured && (
          <div className="ribbon-wrap">
            <div className="ribbon featured">FEATURED</div>
          </div>
        )}
      </div>

      {listing.status === 'PENDING_REVIEW' && (
        <div
          style={{
            background: 'var(--amber)',
            color: 'var(--ink)',
            padding: '10px 16px',
            borderRadius: 8,
            fontSize: 13,
            fontWeight: 600,
            marginTop: 16,
          }}
        >
          ⏳ This listing is waiting for admin review and won't show up on
          the homepage or in search until approved.
        </div>
      )}
      {listing.status === 'REMOVED' && (
        <div
          style={{
            background: '#fdecea',
            color: 'var(--maple-red-dark)',
            padding: '10px 16px',
            borderRadius: 8,
            fontSize: 13,
            fontWeight: 600,
            marginTop: 16,
          }}
        >
          This listing was removed and isn't visible to other users.
        </div>
      )}
      {listing.status === 'SOLD' && (
        <div
          style={{
            background: 'var(--paper-dim)',
            color: 'var(--gray)',
            padding: '10px 16px',
            borderRadius: 8,
            fontSize: 13,
            fontWeight: 600,
            marginTop: 16,
          }}
        >
          This item has been marked as sold.
        </div>
      )}

      <div style={{ marginTop: 24, display: 'flex', justifyContent: 'space-between', gap: 32 }}>
        <div style={{ flex: 1 }}>
          {editing ? (
            <div className="sidebar-card">
              <div className="form-field">
                <label>Title</label>
                <input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} minLength={3} required />
              </div>
              <div className="form-field">
                <label>Description</label>
                <textarea
                  rows={5}
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  required
                />
              </div>
              <div className="form-field">
                <label>Price (USD, leave blank for Free)</label>
                <input type="number" min="0" value={editPrice} onChange={(e) => setEditPrice(e.target.value)} />
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn-primary" onClick={submitEdit} disabled={savingEdit}>
                  {savingEdit ? 'Saving…' : 'Save changes'}
                </button>
                <button className="btn-secondary" onClick={() => setEditing(false)} disabled={savingEdit}>
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <>
              <h1 className="display" style={{ fontSize: 20, marginBottom: 8 }}>
                {listing.title}
              </h1>
              <p style={{ color: 'var(--gray)', lineHeight: 1.6 }}>{listing.description}</p>
            </>
          )}
        </div>

        <div style={{ width: 260 }}>
          <div className="sidebar-card">
            <div className="listing-price" style={{ fontSize: 28 }}>
              {listing.price ? `$${listing.price}` : 'Free'}
            </div>
            <div className="listing-meta" style={{ marginTop: 8, marginBottom: 16 }}>
              <span>
                {listing.neighborhood ? `${listing.neighborhood.name}, ` : ''}
                {listing.city?.name}
              </span>
            </div>

            {error && <div className="form-error">{error}</div>}

            {isOwnListing ? (
              <div>
                {!editing && (
                  <button
                    className="btn-secondary"
                    style={{ width: '100%', marginBottom: 8 }}
                    onClick={startEdit}
                  >
                    Edit details
                  </button>
                )}
                {listing.status === 'ACTIVE' || listing.status === 'SOLD' ? (
                  <button
                    className="btn-primary"
                    style={{ width: '100%', marginBottom: 8 }}
                    onClick={toggleSold}
                    disabled={updating || editing}
                  >
                    {updating
                      ? '…'
                      : listing.status === 'SOLD'
                        ? 'Mark as available again'
                        : 'Mark as sold'}
                  </button>
                ) : (
                  <div className="state-message" style={{ padding: '12px 0', fontSize: 12 }}>
                    Can't mark sold while {listing.status.toLowerCase().replace('_', ' ')}.
                  </div>
                )}
                <button
                  className="btn-secondary"
                  style={{ width: '100%', color: 'var(--maple-red-dark)' }}
                  onClick={deleteListing}
                  disabled={updating || editing}
                >
                  Delete listing
                </button>
              </div>
            ) : (
              <>
                <button
                  className="btn-primary"
                  style={{ width: '100%', marginBottom: 8 }}
                  onClick={onMessageSeller}
                  disabled={messaging}
                >
                  {messaging ? 'Starting…' : 'Message seller'}
                </button>
                <button
                  className="btn-secondary"
                  style={{ width: '100%' }}
                  onClick={toggleSave}
                  disabled={savingToggle}
                >
                  {savingToggle ? '…' : saved ? '♥ Saved' : '♡ Save'}
                </button>
              </>
            )}
          </div>

          {isOwnListing && <PromotePanel listing={listing} onPromoted={load} />}
        </div>
      </div>
    </div>
  );
}
