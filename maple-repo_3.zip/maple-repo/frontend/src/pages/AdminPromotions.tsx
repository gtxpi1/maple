import { FormEvent, useEffect, useState } from 'react';
import { api, PromotionType } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function AdminPromotions() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [catalog, setCatalog] = useState<PromotionType[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [newId, setNewId] = useState('');
  const [newLabel, setNewLabel] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newDuration, setNewDuration] = useState('');
  const [newDescription, setNewDescription] = useState('');

  const load = () =>
    api.promotions
      .catalog(MARKETPLACE_ID)
      .then((res) => setCatalog(res.data))
      .catch((err) => setError(err.message));

  useEffect(() => {
    if (isAdmin) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to manage promotions. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }
  if (!catalog) return <div className="page state-message">Loading…</div>;

  const save = async (next: PromotionType[]) => {
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      const res = await api.promotions.updateCatalog(MARKETPLACE_ID, next);
      setCatalog(res.data);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save catalog.');
    } finally {
      setSaving(false);
    }
  };

  const updateField = (id: string, field: keyof PromotionType, value: string) => {
    setCatalog((prev) =>
      prev!.map((p) =>
        p.id === id
          ? {
              ...p,
              [field]:
                field === 'priceCents' || field === 'durationDays' ? Number(value) || 0 : value,
            }
          : p,
      ),
    );
  };

  const removeType = (id: string) => {
    if (!confirm(`Remove "${id}" from the catalog?`)) return;
    save(catalog.filter((p) => p.id !== id));
  };

  const resetToDefaults = () => {
    if (!confirm('Reset to the built-in default catalog? This discards your custom pricing.')) return;
    save([]);
  };

  const onAdd = (e: FormEvent) => {
    e.preventDefault();
    if (catalog.some((p) => p.id === newId)) {
      setError(`A promotion type with id "${newId}" already exists.`);
      return;
    }
    const next = [
      ...catalog,
      {
        id: newId,
        label: newLabel,
        priceCents: Math.round(Number(newPrice) * 100) || 0,
        currency: 'USD',
        durationDays: Number(newDuration) || 1,
        description: newDescription,
      },
    ];
    save(next);
    setNewId('');
    setNewLabel('');
    setNewPrice('');
    setNewDuration('');
    setNewDescription('');
  };

  return (
    <div className="page" style={{ maxWidth: 800 }}>
      <div className="section-head">
        <h2 className="display">Manage promotions</h2>
      </div>

      {error && <div className="form-error">{error}</div>}
      {saved && (
        <div
          style={{
            background: '#e8f5ee',
            color: 'var(--leaf)',
            padding: '10px 14px',
            borderRadius: 8,
            fontSize: 13,
            marginBottom: 16,
          }}
        >
          Saved — changes are live immediately on the Promote panel.
        </div>
      )}

      <div
        style={{
          background: 'white',
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
          marginBottom: 20,
        }}
      >
        {catalog.map((p) => (
          <div
            key={p.id}
            style={{
              display: 'grid',
              gridTemplateColumns: '90px 1fr 90px 90px 1fr 70px',
              gap: 8,
              alignItems: 'center',
              padding: '10px 14px',
              borderBottom: '1px solid var(--line)',
            }}
          >
            <span className="mono" style={{ fontSize: 11, color: 'var(--gray)' }}>
              {p.id}
            </span>
            <input
              value={p.label}
              onChange={(e) => updateField(p.id, 'label', e.target.value)}
              style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
            />
            <input
              type="number"
              step="0.01"
              value={(p.priceCents / 100).toFixed(2)}
              onChange={(e) => updateField(p.id, 'priceCents', String(Math.round(Number(e.target.value) * 100)))}
              style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
              title="Price (USD)"
            />
            <input
              type="number"
              value={p.durationDays}
              onChange={(e) => updateField(p.id, 'durationDays', e.target.value)}
              style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
              title="Duration (days)"
            />
            <input
              value={p.description}
              onChange={(e) => updateField(p.id, 'description', e.target.value)}
              style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
            />
            <button
              className="btn-secondary"
              style={{ padding: '5px 8px', fontSize: 11, color: 'var(--maple-red-dark)' }}
              onClick={() => removeType(p.id)}
            >
              Remove
            </button>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
        <button className="btn-primary" disabled={saving} onClick={() => save(catalog)}>
          {saving ? 'Saving…' : 'Save changes'}
        </button>
        <button className="btn-secondary" onClick={resetToDefaults}>
          Reset to defaults
        </button>
      </div>

      <div className="section-head">
        <h2 className="display" style={{ fontSize: 18 }}>
          Add a promotion type
        </h2>
      </div>

      <form
        onSubmit={onAdd}
        style={{
          display: 'grid',
          gridTemplateColumns: '90px 1fr 90px 90px 1fr 70px',
          gap: 8,
          alignItems: 'center',
        }}
      >
        <input
          value={newId}
          onChange={(e) => setNewId(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
          placeholder="id"
          required
          style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
        />
        <input
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
          placeholder="Label"
          required
          style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
        />
        <input
          type="number"
          step="0.01"
          value={newPrice}
          onChange={(e) => setNewPrice(e.target.value)}
          placeholder="$"
          required
          style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
        />
        <input
          type="number"
          value={newDuration}
          onChange={(e) => setNewDuration(e.target.value)}
          placeholder="days"
          required
          style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
        />
        <input
          value={newDescription}
          onChange={(e) => setNewDescription(e.target.value)}
          placeholder="Description"
          required
          style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
        />
        <button className="btn-secondary" style={{ padding: '6px 10px' }}>
          Add
        </button>
      </form>

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 20 }}>
        Editing a promotion's price only affects future purchases — it does
        not change the price of promotions already bought. Removing a type
        here doesn't remove or refund already-active promotions of that
        type on listings; it just stops it from being purchasable again.
      </p>
    </div>
  );
}
