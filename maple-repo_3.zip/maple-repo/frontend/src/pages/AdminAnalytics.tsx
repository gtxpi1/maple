import { useEffect, useState } from 'react';
import { api, AnalyticsOverview } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function AdminAnalytics() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [overview, setOverview] = useState<AnalyticsOverview | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isAdmin) return;
    api.analytics
      .overview(MARKETPLACE_ID)
      .then((res) => setOverview(res.data))
      .catch((err) => setError(err.message));
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to view analytics. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }
  if (!overview) return <div className="page state-message">{error ?? 'Loading…'}</div>;

  const maxSignups = Math.max(1, ...overview.dailySignups.map((d) => d.count));

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="section-head">
        <h2 className="display">Analytics</h2>
      </div>

      {error && <div className="form-error">{error}</div>}

      <div style={{ display: 'flex', gap: 16, marginBottom: 24 }}>
        <div className="sidebar-card" style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>USERS</div>
          <div className="mono" style={{ fontSize: 26, fontWeight: 700 }}>
            {overview.userCount}
          </div>
        </div>
        <div className="sidebar-card" style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>LISTINGS</div>
          <div className="mono" style={{ fontSize: 26, fontWeight: 700 }}>
            {overview.totalListings}
          </div>
        </div>
        <div className="sidebar-card" style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>CATEGORIES</div>
          <div className="mono" style={{ fontSize: 26, fontWeight: 700 }}>
            {overview.categoryCount}
          </div>
        </div>
      </div>

      <div className="section-head">
        <h2 className="display" style={{ fontSize: 16 }}>
          Listings by status
        </h2>
      </div>
      <div
        style={{
          background: 'white',
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
          marginBottom: 24,
        }}
      >
        {Object.entries(overview.listingsByStatus).length === 0 && (
          <div className="state-message" style={{ padding: 20 }}>
            No listings yet.
          </div>
        )}
        {Object.entries(overview.listingsByStatus).map(([status, count]) => (
          <div
            key={status}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              padding: '10px 16px',
              borderBottom: '1px solid var(--line)',
              fontSize: 13,
            }}
          >
            <span style={{ fontWeight: 600 }}>{status}</span>
            <span className="mono" style={{ color: 'var(--gray)' }}>
              {count}
            </span>
          </div>
        ))}
      </div>

      <div className="section-head">
        <h2 className="display" style={{ fontSize: 16 }}>
          Signups, last 30 days
        </h2>
      </div>
      <div
        className="sidebar-card"
        style={{
          display: 'flex',
          alignItems: 'flex-end',
          gap: 3,
          height: 120,
          overflowX: 'auto',
        }}
      >
        {overview.dailySignups.length === 0 && (
          <div className="state-message" style={{ padding: 0 }}>
            No signups in the last 30 days.
          </div>
        )}
        {overview.dailySignups.map((d) => (
          <div
            key={d.date}
            title={`${d.date}: ${d.count} signup${d.count === 1 ? '' : 's'}`}
            style={{
              width: 10,
              height: `${Math.max(4, (d.count / maxSignups) * 100)}%`,
              background: 'var(--leaf)',
              borderRadius: 2,
              flexShrink: 0,
            }}
          />
        ))}
      </div>

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 16 }}>
        This is a slice of two metric domains (Site, User) — Category and
        Geographic Metrics aren't implemented yet. See docs/19.
      </p>
    </div>
  );
}
