import { useEffect, useState } from 'react';
import { api, AdminTransaction, FinanceSummary } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function AdminFinance() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [summary, setSummary] = useState<FinanceSummary | null>(null);
  const [transactions, setTransactions] = useState<AdminTransaction[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refunding, setRefunding] = useState<string | null>(null);

  const loadTransactions = () =>
    api.finance
      .transactions(MARKETPLACE_ID)
      .then((res) => setTransactions(res.data))
      .catch((err) => setError(err.message));

  useEffect(() => {
    if (!isAdmin) return;
    api.finance
      .summary(MARKETPLACE_ID)
      .then((res) => setSummary(res.data))
      .catch((err) => setError(err.message));
    loadTransactions();
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to view financial reports. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }

  const onRefund = async (transactionId: string) => {
    if (!confirm('Refund this transaction? This also expires any promotion it purchased.')) return;
    setRefunding(transactionId);
    setError(null);
    try {
      await api.finance.refund(transactionId);
      loadTransactions();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not refund transaction.');
    } finally {
      setRefunding(null);
    }
  };

  const maxDaily = summary ? Math.max(1, ...summary.dailyRevenue.map((d) => d.revenue)) : 1;

  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="section-head">
        <h2 className="display">Finance</h2>
      </div>

      {error && <div className="form-error">{error}</div>}
      {!summary && <div className="state-message">Loading…</div>}

      {summary && (
        <>
          <div style={{ display: 'flex', gap: 16, marginBottom: 24 }}>
            <div className="sidebar-card" style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>TOTAL REVENUE</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 700, color: 'var(--leaf)' }}>
                ${summary.totalRevenue.toFixed(2)}
              </div>
            </div>
            <div className="sidebar-card" style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>TRANSACTIONS</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 700 }}>
                {summary.transactionCount}
              </div>
            </div>
            <div className="sidebar-card" style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 4 }}>AVG. PER TRANSACTION</div>
              <div className="mono" style={{ fontSize: 26, fontWeight: 700 }}>
                $
                {summary.transactionCount > 0
                  ? (summary.totalRevenue / summary.transactionCount).toFixed(2)
                  : '0.00'}
              </div>
            </div>
          </div>

          <div className="section-head">
            <h2 className="display" style={{ fontSize: 16 }}>
              Last 30 days
            </h2>
          </div>
          <div
            className="sidebar-card"
            style={{
              marginBottom: 24,
              display: 'flex',
              alignItems: 'flex-end',
              gap: 3,
              height: 120,
              overflowX: 'auto',
            }}
          >
            {summary.dailyRevenue.length === 0 && (
              <div className="state-message" style={{ padding: 0 }}>
                No revenue in the last 30 days.
              </div>
            )}
            {summary.dailyRevenue.map((d) => (
              <div
                key={d.date}
                title={`${d.date}: $${d.revenue.toFixed(2)}`}
                style={{
                  width: 10,
                  height: `${Math.max(4, (d.revenue / maxDaily) * 100)}%`,
                  background: 'var(--maple-red)',
                  borderRadius: 2,
                  flexShrink: 0,
                }}
              />
            ))}
          </div>

          <div className="section-head">
            <h2 className="display" style={{ fontSize: 16 }}>
              Revenue by promotion type
            </h2>
          </div>
          <div
            style={{
              background: 'white',
              borderRadius: 12,
              overflow: 'hidden',
              boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
              marginBottom: 24,
            }}
          >
            {Object.entries(summary.revenueByPromotionType).length === 0 && (
              <div className="state-message" style={{ padding: 20 }}>
                No promotion purchases yet.
              </div>
            )}
            {Object.entries(summary.revenueByPromotionType).map(([type, stats]) => (
              <div
                key={type}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '10px 16px',
                  borderBottom: '1px solid var(--line)',
                  fontSize: 13,
                }}
              >
                <span style={{ fontWeight: 600 }}>{type}</span>
                <span className="mono" style={{ color: 'var(--gray)' }}>
                  {stats.count} purchase{stats.count === 1 ? '' : 's'} · ${stats.revenue.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="section-head">
        <h2 className="display" style={{ fontSize: 16 }}>
          Transaction ledger
        </h2>
      </div>
      <div
        style={{
          background: 'white',
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
        }}
      >
        {transactions === null && <div className="state-message">Loading…</div>}
        {transactions?.length === 0 && (
          <div className="state-message">No transactions yet.</div>
        )}
        {transactions?.map((t) => (
          <div
            key={t.id}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '10px 16px',
              borderBottom: '1px solid var(--line)',
              fontSize: 12.5,
            }}
          >
            <div>
              <div style={{ fontWeight: 600 }}>{t.invoice.user.displayName}</div>
              <div style={{ color: 'var(--gray)', fontSize: 11 }}>
                {t.promotionPurchases.map((p) => p.promotionType).join(', ') || 'purchase'} ·{' '}
                {new Date(t.createdAt).toLocaleString()}
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div className="mono" style={{ fontWeight: 700 }}>
                ${Number(t.amount).toFixed(2)} {t.currency}
              </div>
              <div
                style={{
                  fontSize: 10,
                  color: t.status === 'succeeded' ? 'var(--leaf)' : 'var(--maple-red-dark)',
                  textTransform: 'uppercase',
                }}
              >
                {t.status}
              </div>
              {t.status === 'succeeded' &&
                (t.refunds.some((r) => r.status === 'completed') ? (
                  <div style={{ fontSize: 10, color: 'var(--maple-red-dark)', marginTop: 4 }}>
                    REFUNDED
                  </div>
                ) : (
                  <button
                    className="btn-secondary"
                    style={{ padding: '3px 8px', fontSize: 10, marginTop: 4 }}
                    disabled={refunding === t.id}
                    onClick={() => onRefund(t.id)}
                  >
                    {refunding === t.id ? '…' : 'Refund'}
                  </button>
                ))}
            </div>
          </div>
        ))}
      </div>

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 16 }}>
        Figures are computed from the live Transaction ledger, not a cached
        rollup — accurate as of page load, not real-time. Only `succeeded`
        transactions count toward revenue; failed/pending ones still show
        in the ledger below for visibility.
      </p>
    </div>
  );
}
