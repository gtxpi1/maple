import { ChangeEvent, FormEvent, useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api, Message, UploadedImage } from '../api/client';
import { useAuth } from '../context/AuthContext';

const API_ORIGIN = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1').replace(
  '/api/v1',
  '',
);

export function Conversation() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [draft, setDraft] = useState('');
  const [pendingAttachment, setPendingAttachment] = useState<UploadedImage | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const load = () => {
    if (!id) return;
    api.conversations
      .messages(id)
      .then((res) => setMessages(res.data))
      .catch((err) => setError(err.message));
  };

  useEffect(load, [id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const onAttach = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const res = await api.media.upload(file);
      setPendingAttachment(res.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const onSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!id || (!draft.trim() && !pendingAttachment)) return;
    setSending(true);
    setError(null);
    try {
      const chosenUrl =
        pendingAttachment?.variants.find((v) => v.size === 'medium')?.url ?? pendingAttachment?.url;
      const attachments = chosenUrl
        ? [{ url: chosenUrl.replace(API_ORIGIN, ''), mimeType: 'image/jpeg' }]
        : [];
      await api.conversations.send(id, draft.trim(), attachments);
      setDraft('');
      setPendingAttachment(null);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not send message.');
    } finally {
      setSending(false);
    }
  };

  if (!user) {
    return (
      <div className="page state-message">
        Log in to view this conversation. <a href="/login">Log in</a>
      </div>
    );
  }

  return (
    <div className="page" style={{ maxWidth: 700 }}>
      <div className="section-head">
        <h2 className="display">Conversation</h2>
      </div>

      {error && <div className="form-error">{error}</div>}

      <div
        style={{
          background: 'white',
          borderRadius: 12,
          padding: 18,
          minHeight: 300,
          maxHeight: 480,
          overflowY: 'auto',
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
          marginBottom: 14,
        }}
      >
        {messages === null && <div className="state-message">Loading…</div>}
        {messages?.length === 0 && <div className="state-message">Say hello.</div>}

        {messages?.map((m) => {
          const isMine = m.senderId === user.id;
          return (
            <div
              key={m.id}
              style={{
                display: 'flex',
                justifyContent: isMine ? 'flex-end' : 'flex-start',
                marginBottom: 10,
              }}
            >
              <div
                style={{
                  maxWidth: '70%',
                  background: isMine ? 'var(--maple-red)' : 'var(--paper-dim)',
                  color: isMine ? 'white' : 'var(--ink)',
                  padding: '8px 12px',
                  borderRadius: 12,
                  fontSize: 13.5,
                }}
              >
                {m.attachments.map((a) => (
                  <img
                    key={a.id}
                    src={`${API_ORIGIN}${a.url}`}
                    alt="attachment"
                    style={{
                      display: 'block',
                      maxWidth: '100%',
                      borderRadius: 8,
                      marginBottom: m.body ? 6 : 0,
                    }}
                  />
                ))}
                {m.body}
                <div
                  style={{
                    fontSize: 10,
                    opacity: 0.7,
                    marginTop: 4,
                    textAlign: isMine ? 'right' : 'left',
                  }}
                >
                  {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {pendingAttachment && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <img
            src={pendingAttachment.variants.find((v) => v.size === 'thumbnail')?.url ?? pendingAttachment.url}
            alt="pending attachment"
            style={{ width: 48, height: 48, borderRadius: 8, objectFit: 'cover' }}
          />
          <button
            type="button"
            className="btn-secondary"
            style={{ padding: '4px 10px', fontSize: 11 }}
            onClick={() => setPendingAttachment(null)}
          >
            Remove
          </button>
        </div>
      )}

      <form onSubmit={onSend} style={{ display: 'flex', gap: 8 }}>
        <label
          className="btn-secondary"
          style={{ padding: '11px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center' }}
        >
          {uploading ? '…' : '📎'}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={onAttach}
            disabled={uploading}
            style={{ display: 'none' }}
          />
        </label>
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Type a message…"
          style={{
            flex: 1,
            padding: '11px 14px',
            border: '1.5px solid var(--line)',
            borderRadius: 8,
          }}
        />
        <button className="btn-primary" disabled={sending || (!draft.trim() && !pendingAttachment)}>
          Send
        </button>
      </form>
    </div>
  );
}
