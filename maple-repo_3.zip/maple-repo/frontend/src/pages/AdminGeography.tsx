import { FormEvent, ReactNode, useEffect, useState } from 'react';
import { api, City, Country, Neighborhood, Region, StateProvince } from '../api/client';
import { useAuth } from '../context/AuthContext';

export function AdminGeography() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [countries, setCountries] = useState<Country[]>([]);
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const [states, setStates] = useState<StateProvince[]>([]);
  const [selectedState, setSelectedState] = useState<string>('');
  const [regions, setRegions] = useState<Region[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>('');
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [countryName, setCountryName] = useState('');
  const [countryCode, setCountryCode] = useState('');
  const [stateName, setStateName] = useState('');
  const [regionName, setRegionName] = useState('');
  const [cityName, setCityName] = useState('');
  const [cityRegionId, setCityRegionId] = useState('');
  const [neighborhoodName, setNeighborhoodName] = useState('');

  const loadCountries = () =>
    api.geography
      .listCountries()
      .then((res) => setCountries(res.data))
      .catch((err) => setError(err.message));

  const loadStates = (countryId: string) =>
    api.geography
      .listStates(countryId)
      .then((res) => setStates(res.data))
      .catch((err) => setError(err.message));

  const loadRegions = (stateProvinceId: string) =>
    api.geography
      .listRegions(stateProvinceId)
      .then((res) => setRegions(res.data))
      .catch((err) => setError(err.message));

  const loadCities = (stateProvinceId: string) =>
    api.geography
      .listCities({ stateProvinceId })
      .then((res) => setCities(res.data))
      .catch((err) => setError(err.message));

  const loadNeighborhoods = (cityId: string) =>
    api.geography
      .listNeighborhoods(cityId)
      .then((res) => setNeighborhoods(res.data))
      .catch((err) => setError(err.message));

  useEffect(() => {
    if (isAdmin) loadCountries();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  useEffect(() => {
    if (selectedCountry) loadStates(selectedCountry);
    else setStates([]);
    setSelectedState('');
    setRegions([]);
    setCities([]);
  }, [selectedCountry]);

  useEffect(() => {
    if (selectedState) {
      loadRegions(selectedState);
      loadCities(selectedState);
    } else {
      setRegions([]);
      setCities([]);
    }
    setSelectedCity('');
    setNeighborhoods([]);
    setCityRegionId('');
  }, [selectedState]);

  useEffect(() => {
    if (selectedCity) loadNeighborhoods(selectedCity);
    else setNeighborhoods([]);
  }, [selectedCity]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to manage geography. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }

  const onAddCountry = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.geography.createCountry({ name: countryName, code: countryCode });
      setCountryName('');
      setCountryCode('');
      loadCountries();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add country.');
    }
  };

  const onAddState = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.geography.createState({ countryId: selectedCountry, name: stateName });
      setStateName('');
      loadStates(selectedCountry);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add state/province.');
    }
  };

  const onAddRegion = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.geography.createRegion({ stateProvinceId: selectedState, name: regionName });
      setRegionName('');
      loadRegions(selectedState);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add region.');
    }
  };

  const removeRegion = async (id: string) => {
    if (!confirm('Delete this region?')) return;
    try {
      await api.geography.removeRegion(id);
      loadRegions(selectedState);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete region.');
    }
  };

  const onAddCity = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.geography.createCity({
        stateProvinceId: selectedState,
        name: cityName,
        regionId: cityRegionId || undefined,
      });
      setCityName('');
      setCityRegionId('');
      loadCities(selectedState);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add city.');
    }
  };

  const removeCountry = async (id: string) => {
    if (!confirm('Delete this country?')) return;
    try {
      await api.geography.removeCountry(id);
      loadCountries();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete country.');
    }
  };

  const removeState = async (id: string) => {
    if (!confirm('Delete this state/province?')) return;
    try {
      await api.geography.removeState(id);
      loadStates(selectedCountry);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete state/province.');
    }
  };

  const removeCity = async (id: string) => {
    if (!confirm('Delete this city?')) return;
    try {
      await api.geography.removeCity(id);
      loadCities(selectedState);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete city.');
    }
  };

  const onAddNeighborhood = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.geography.createNeighborhood({ cityId: selectedCity, name: neighborhoodName });
      setNeighborhoodName('');
      loadNeighborhoods(selectedCity);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add neighborhood.');
    }
  };

  const removeNeighborhood = async (id: string) => {
    if (!confirm('Delete this neighborhood?')) return;
    try {
      await api.geography.removeNeighborhood(id);
      loadNeighborhoods(selectedCity);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete neighborhood.');
    }
  };

  const column = (title: string, children: ReactNode) => (
    <div style={{ flex: '0 0 220px', minWidth: 220 }}>
      <h3 style={{ fontSize: 13, fontWeight: 700, marginBottom: 10, textTransform: 'uppercase', color: 'var(--gray)' }}>
        {title}
      </h3>
      <div
        style={{
          background: 'white',
          borderRadius: 12,
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
          minHeight: 60,
        }}
      >
        {children}
      </div>
    </div>
  );

  const row = (label: string, active: boolean, onClick: () => void, onDelete: () => void) => (
    <div
      key={label}
      onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '10px 12px',
        borderBottom: '1px solid var(--line)',
        cursor: 'pointer',
        background: active ? 'var(--paper-dim)' : 'transparent',
        fontSize: 13.5,
        fontWeight: active ? 700 : 500,
      }}
    >
      <span style={{ flex: 1 }}>{label}</span>
      <button
        className="btn-secondary"
        style={{ padding: '3px 8px', fontSize: 11 }}
        onClick={(e) => {
          e.stopPropagation();
          onDelete();
        }}
      >
        Delete
      </button>
    </div>
  );

  return (
    <div className="page" style={{ maxWidth: 1300 }}>
      <div className="section-head">
        <h2 className="display">Manage geography</h2>
      </div>

      {error && <div className="form-error">{error}</div>}

      <div style={{ display: 'flex', gap: 16, marginBottom: 20, overflowX: 'auto' }}>
        {column(
          'Countries',
          <>
            {countries.map((c) =>
              row(`${c.name} (${c.code})`, selectedCountry === c.id, () => setSelectedCountry(c.id), () =>
                removeCountry(c.id),
              ),
            )}
            <form onSubmit={onAddCountry} style={{ display: 'flex', gap: 6, padding: 10 }}>
              <input
                value={countryName}
                onChange={(e) => setCountryName(e.target.value)}
                placeholder="Name"
                required
                style={{ flex: 1, padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6 }}
              />
              <input
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                placeholder="CA"
                maxLength={2}
                required
                style={{ width: 44, padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6 }}
              />
              <button className="btn-secondary" style={{ padding: '6px 10px' }}>
                +
              </button>
            </form>
          </>,
        )}

        {column(
          'States / Provinces',
          selectedCountry ? (
            <>
              {states.map((s) =>
                row(s.name, selectedState === s.id, () => setSelectedState(s.id), () => removeState(s.id)),
              )}
              <form onSubmit={onAddState} style={{ display: 'flex', gap: 6, padding: 10 }}>
                <input
                  value={stateName}
                  onChange={(e) => setStateName(e.target.value)}
                  placeholder="Name"
                  required
                  style={{ flex: 1, padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6 }}
                />
                <button className="btn-secondary" style={{ padding: '6px 10px' }}>
                  +
                </button>
              </form>
            </>
          ) : (
            <div className="state-message" style={{ padding: 20 }}>
              Select a country
            </div>
          ),
        )}

        {column(
          'Regions (optional)',
          selectedState ? (
            <>
              {regions.map((r) => row(r.name, false, () => {}, () => removeRegion(r.id)))}
              <form onSubmit={onAddRegion} style={{ display: 'flex', gap: 6, padding: 10 }}>
                <input
                  value={regionName}
                  onChange={(e) => setRegionName(e.target.value)}
                  placeholder="Name"
                  required
                  style={{ flex: 1, padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6 }}
                />
                <button className="btn-secondary" style={{ padding: '6px 10px' }}>
                  +
                </button>
              </form>
            </>
          ) : (
            <div className="state-message" style={{ padding: 20 }}>
              Select a state/province
            </div>
          ),
        )}

        {column(
          'Cities',
          selectedState ? (
            <>
              {cities.map((c) =>
                row(c.name, selectedCity === c.id, () => setSelectedCity(c.id), () => removeCity(c.id)),
              )}
              <form onSubmit={onAddCity} style={{ display: 'flex', flexDirection: 'column', gap: 6, padding: 10 }}>
                <input
                  value={cityName}
                  onChange={(e) => setCityName(e.target.value)}
                  placeholder="Name"
                  required
                  style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6 }}
                />
                {regions.length > 0 && (
                  <select
                    value={cityRegionId}
                    onChange={(e) => setCityRegionId(e.target.value)}
                    style={{ padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6, fontSize: 12.5 }}
                  >
                    <option value="">— no region —</option>
                    {regions.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name}
                      </option>
                    ))}
                  </select>
                )}
                <button className="btn-secondary" style={{ padding: '6px 10px' }}>
                  + Add city
                </button>
              </form>
            </>
          ) : (
            <div className="state-message" style={{ padding: 20 }}>
              Select a state/province
            </div>
          ),
        )}

        {column(
          'Neighborhoods',
          selectedCity ? (
            <>
              {neighborhoods.map((n) =>
                row(n.name, false, () => {}, () => removeNeighborhood(n.id)),
              )}
              <form onSubmit={onAddNeighborhood} style={{ display: 'flex', gap: 6, padding: 10 }}>
                <input
                  value={neighborhoodName}
                  onChange={(e) => setNeighborhoodName(e.target.value)}
                  placeholder="Name"
                  required
                  style={{ flex: 1, padding: '6px 8px', border: '1.5px solid var(--line)', borderRadius: 6 }}
                />
                <button className="btn-secondary" style={{ padding: '6px 10px' }}>
                  +
                </button>
              </form>
            </>
          ) : (
            <div className="state-message" style={{ padding: 20 }}>
              Select a city
            </div>
          ),
        )}
      </div>

      <p style={{ fontSize: 12, color: 'var(--gray)' }}>
        Cities and Neighborhoods show up in the post-ad form immediately —
        Neighborhood as an optional dropdown once a city with any is
        selected. Regions are optional groupings assignable when creating a
        city; nothing outside this admin page reads a city's region yet.
        Deleting a country/state/region/city is blocked while it still has
        children under it; deleting a neighborhood is blocked while any
        listing points to it.
      </p>
    </div>
  );
}
