import { useEffect, useState } from 'react';
import { api, AdminUser, Role } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function AdminUsers() {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes('admin');

  const [users, setUsers] = useState<AdminUser[] | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busyUserId, setBusyUserId] = useState<string | null>(null);

  const load = () => {
    api.adminUsers
      .list(MARKETPLACE_ID)
      .then((res) => setUsers(res.data))
      .catch((err) => setError(err.message));
  };

  useEffect(() => {
    if (!isAdmin) return;
    load();
    api.adminUsers
      .roles()
      .then((res) => setRoles(res.data))
      .catch((err) => setError(err.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to manage users. <a href="/login">Log in</a>
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }

  const toggleAdmin = async (target: AdminUser) => {
    const adminRole = roles.find((r) => r.name === 'admin');
    if (!adminRole) {
      setError('No "admin" role found — check the seed script ran.');
      return;
    }

    setBusyUserId(target.id);
    setError(null);
    try {
      if (target.roles.includes('admin')) {
        await api.adminUsers.revokeRole(target.id, adminRole.id);
      } else {
        await api.adminUsers.grantRole(target.id, adminRole.id);
      }
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update role.');
    } finally {
      setBusyUserId(null);
    }
  };

  return (
    <div className="page" style={{ maxWidth: 800 }}>
      <div className="section-head">
        <h2 className="display">Users</h2>
      </div>

      {error && <div className="form-error">{error}</div>}

      <div
        style={{
          background: 'white',
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)',
        }}
      >
        {users === null && <div className="state-message">Loading…</div>}
        {users?.length === 0 && <div className="state-message">No users yet.</div>}
        {users?.map((u) => {
          const isSelf = u.id === user.id;
          const isTargetAdmin = u.roles.includes('admin');
          return (
            <div
              key={u.id}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '10px 16px',
                borderBottom: '1px solid var(--line)',
                fontSize: 13,
              }}
            >
              <div>
                <div style={{ fontWeight: 600 }}>
                  {u.displayName} {isSelf && <span style={{ color: 'var(--gray)' }}>(you)</span>}
                </div>
                <div style={{ fontSize: 11, color: 'var(--gray)' }}>
                  {u.email} · joined {new Date(u.createdAt).toLocaleDateString()}
                  {u.roles.length > 0 && ` · ${u.roles.join(', ')}`}
                </div>
              </div>
              <button
                className="btn-secondary"
                style={{
                  padding: '5px 12px',
                  fontSize: 11,
                  color: isTargetAdmin ? 'var(--maple-red-dark)' : undefined,
                }}
                disabled={busyUserId === u.id || (isSelf && isTargetAdmin)}
                title={isSelf && isTargetAdmin ? "You can't remove your own admin role" : undefined}
                onClick={() => toggleAdmin(u)}
              >
                {busyUserId === u.id
                  ? '…'
                  : isTargetAdmin
                    ? 'Revoke admin'
                    : 'Make admin'}
              </button>
            </div>
          );
        })}
      </div>

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 16 }}>
        You can't revoke your own admin role — have another admin do it, or
        edit the database directly if you're the only one. Role changes
        apply on the affected user's next login (roles are baked into their
        JWT at sign-in, not checked against the database on every request).
      </p>
    </div>
  );
}
