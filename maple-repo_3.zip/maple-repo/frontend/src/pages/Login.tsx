import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mfaToken, setMfaToken] = useState('');
  const [mfaRequired, setMfaRequired] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.auth.login({
        marketplaceId: MARKETPLACE_ID,
        email,
        password,
        mfaToken: mfaRequired ? mfaToken : undefined,
      });
      if ('mfaRequired' in res) {
        // Password was correct, but the account has MFA enabled — show the
        // code field instead of treating this as a failed login.
        setMfaRequired(true);
        return;
      }
      login(res);
      navigate('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="form-card">
      <h1>Log in to Maple</h1>
      {error && <div className="form-error">{error}</div>}
      <form onSubmit={onSubmit}>
        <div className="form-field">
          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            disabled={mfaRequired}
          />
        </div>
        <div className="form-field">
          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            disabled={mfaRequired}
          />
        </div>
        {mfaRequired && (
          <div className="form-field">
            <label>6-digit authentication code</label>
            <input
              value={mfaToken}
              onChange={(e) => setMfaToken(e.target.value)}
              maxLength={6}
              inputMode="numeric"
              autoFocus
              required
            />
          </div>
        )}
        <button className="btn-primary" style={{ width: '100%' }} disabled={loading}>
          {loading ? 'Logging in…' : mfaRequired ? 'Verify' : 'Log in'}
        </button>
      </form>
    </div>
  );
}
