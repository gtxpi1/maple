import { ChangeEvent, FormEvent, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, City, Neighborhood, UploadedImage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { CityPicker } from '../components/CityPicker';
import { CategoryPicker } from '../components/CategoryPicker';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function PostAd() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [city, setCity] = useState<City | null>(null);
  const [neighborhoods, setNeighborhoods] = useState<Neighborhood[]>([]);
  const [neighborhoodId, setNeighborhoodId] = useState('');
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setNeighborhoodId('');
    if (!city) {
      setNeighborhoods([]);
      return;
    }
    api.geography
      .listNeighborhoods(city.id)
      .then((res) => setNeighborhoods(res.data))
      .catch(() => setNeighborhoods([]));
  }, [city]);

  if (!user) {
    return (
      <div className="page state-message">
        You need to be logged in to post an ad. <a href="/login">Log in</a>
      </div>
    );
  }

  const onFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const res = await api.media.upload(file);
      setImages((prev) => [...prev, res.data]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!city) {
      setError('Please select a city.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.listings.create({
        marketplaceId: MARKETPLACE_ID,
        categoryId,
        cityId: city.id,
        neighborhoodId: neighborhoodId || undefined,
        title,
        description,
        price: price ? Number(price) : undefined,
        imageIds: images.map((img) => img.id),
      });
      navigate(`/listings/${res.data.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create listing.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="form-card" style={{ maxWidth: 600 }}>
      <h1>Post an ad</h1>
      {error && <div className="form-error">{error}</div>}

      <form onSubmit={onSubmit}>
        <div className="form-field">
          <label>Photos</label>
          <div className="image-upload-grid">
            {images.map((img) => (
              <div
                key={img.id}
                className="image-upload-thumb"
                style={{
                  backgroundImage: `url(${img.variants.find((v) => v.size === 'thumbnail')?.url ?? img.url})`,
                }}
              />
            ))}
            {images.length < 8 && (
              <label className="image-upload-add" style={{ cursor: 'pointer' }}>
                {uploading ? '…' : '+'}
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={onFileChange}
                  disabled={uploading}
                  style={{ display: 'none' }}
                />
              </label>
            )}
          </div>
        </div>

        <div className="form-field">
          <label>Title</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} required minLength={3} />
        </div>

        <div className="form-field">
          <label>Description</label>
          <textarea
            rows={5}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>

        <div className="form-field">
          <label>Price (USD, leave blank for Free)</label>
          <input type="number" min="0" value={price} onChange={(e) => setPrice(e.target.value)} />
        </div>

        <div className="form-field">
          <label>Category</label>
          <CategoryPicker value={categoryId} onChange={setCategoryId} marketplaceId={MARKETPLACE_ID} />
        </div>

        <div className="form-field">
          <label>City</label>
          <CityPicker value={city} onChange={setCity} />
        </div>

        {city && neighborhoods.length > 0 && (
          <div className="form-field">
            <label>Neighborhood (optional)</label>
            <select value={neighborhoodId} onChange={(e) => setNeighborhoodId(e.target.value)}>
              <option value="">— not specified —</option>
              {neighborhoods.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.name}
                </option>
              ))}
            </select>
          </div>
        )}

        <button className="btn-primary" style={{ width: '100%' }} disabled={submitting}>
          {submitting ? 'Posting…' : 'Post ad'}
        </button>
      </form>
    </div>
  );
}
