import { FormEvent, useEffect, useState } from 'react';
import { api, Category } from '../api/client';
import { useAuth } from '../context/AuthContext';

const MARKETPLACE_ID = import.meta.env.VITE_MARKETPLACE_ID || '';

export function AdminCategories() {
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('');
  const [parentId, setParentId] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const isAdmin = user?.roles.includes('admin');

  const load = () => {
    api.categories
      .listAdmin(MARKETPLACE_ID)
      .then((res) => setCategories(res.data))
      .catch((err) => setError(err.message));
  };

  useEffect(() => {
    if (isAdmin) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  if (!user) {
    return (
      <div className="page state-message">
        Log in as an admin to manage categories. <a href="/login">Log in</a>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="page state-message">
        Your account doesn't have the admin role. The seeded admin account is
        admin@maple.demo — see backend/README.md.
      </div>
    );
  }

  const topLevel = categories?.filter((c) => !c.parentId) ?? [];
  const childrenOf = (id: string) => categories?.filter((c) => c.parentId === id) ?? [];

  const onCreate = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await api.categories.create({
        marketplaceId: MARKETPLACE_ID,
        name,
        icon: icon || undefined,
        parentId: parentId || undefined,
      });
      setName('');
      setIcon('');
      setParentId('');
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create category.');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleVisible = async (cat: Category) => {
    await api.categories.update(cat.id, { showInNav: !cat.showInNav });
    load();
  };

  const move = async (cat: Category, direction: -1 | 1) => {
    const siblings = (cat.parentId ? childrenOf(cat.parentId) : topLevel)
      .slice()
      .sort((a, b) => a.displayOrder - b.displayOrder);
    const index = siblings.findIndex((s) => s.id === cat.id);
    const swapWith = siblings[index + direction];
    if (!swapWith) return;

    await api.categories.reorder([
      { id: cat.id, displayOrder: swapWith.displayOrder },
      { id: swapWith.id, displayOrder: cat.displayOrder },
    ]);
    load();
  };

  const remove = async (cat: Category) => {
    if (!confirm(`Delete "${cat.name}"? This can't be undone.`)) return;
    try {
      await api.categories.remove(cat.id);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete category.');
    }
  };

  const renderRow = (cat: Category, depth: number) => (
    <div key={cat.id}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          padding: '10px 14px',
          paddingLeft: 14 + depth * 24,
          borderBottom: '1px solid var(--line)',
          opacity: cat.deletedAt ? 0.4 : 1,
        }}
      >
        <span style={{ width: 20 }}>{cat.icon}</span>
        <span style={{ flex: 1, fontWeight: 600, fontSize: 13.5 }}>{cat.name}</span>
        <span className="mono" style={{ fontSize: 11, color: 'var(--gray)' }}>
          /{cat.slug}
        </span>

        <button onClick={() => move(cat, -1)} className="btn-secondary" style={{ padding: '4px 8px' }}>
          ↑
        </button>
        <button onClick={() => move(cat, 1)} className="btn-secondary" style={{ padding: '4px 8px' }}>
          ↓
        </button>
        <button
          onClick={() => toggleVisible(cat)}
          className="btn-secondary"
          style={{ padding: '4px 8px', fontSize: 11 }}
        >
          {cat.showInNav ? 'Visible' : 'Hidden'}
        </button>
        <button
          onClick={() => remove(cat)}
          className="btn-secondary"
          style={{ padding: '4px 8px', color: 'var(--maple-red-dark)' }}
        >
          Delete
        </button>
      </div>
      {childrenOf(cat.id).map((child) => renderRow(child, depth + 1))}
    </div>
  );

  return (
    <div className="page" style={{ maxWidth: 800 }}>
      <div className="section-head">
        <h2 className="display">Manage categories</h2>
      </div>

      {error && <div className="form-error">{error}</div>}

      <form
        onSubmit={onCreate}
        style={{ display: 'flex', gap: 10, marginBottom: 24, alignItems: 'flex-end' }}
      >
        <div className="form-field" style={{ marginBottom: 0, flex: 1 }}>
          <label>Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div className="form-field" style={{ marginBottom: 0, width: 80 }}>
          <label>Icon</label>
          <input value={icon} onChange={(e) => setIcon(e.target.value)} placeholder="🛍️" />
        </div>
        <div className="form-field" style={{ marginBottom: 0, width: 180 }}>
          <label>Parent (optional)</label>
          <select value={parentId} onChange={(e) => setParentId(e.target.value)}>
            <option value="">— top level —</option>
            {topLevel
              .filter((c) => !c.deletedAt)
              .map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
          </select>
        </div>
        <button className="btn-primary" disabled={submitting}>
          {submitting ? 'Adding…' : 'Add category'}
        </button>
      </form>

      <div style={{ background: 'white', borderRadius: 12, overflow: 'hidden', boxShadow: '0 1px 2px rgba(22,24,29,0.04), 0 6px 16px rgba(22,24,29,0.06)' }}>
        {categories === null && <div className="state-message">Loading…</div>}
        {topLevel.sort((a, b) => a.displayOrder - b.displayOrder).map((cat) => renderRow(cat, 0))}
      </div>

      <p style={{ fontSize: 12, color: 'var(--gray)', marginTop: 16 }}>
        Changes here show up immediately on the homepage category strip — no
        deploy needed. "Delete" is blocked while a category still has
        subcategories.
      </p>
    </div>
  );
}
