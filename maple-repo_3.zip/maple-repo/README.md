# Maple

**The world's most configurable marketplace platform.**

A single codebase capable of running one marketplace or thousands, each with
its own branding, categories, themes, pricing, languages, moderation rules,
payment methods, and features.

> Familiar to use. Original by design.

## Status

Real security modules now exist, not just the docs describing them:
TOTP-based MFA (`/security` — fully offline, no external provider needed,
unlike everything else this build has stubbed), rate limiting on
auth/upload/general traffic, and a CAPTCHA provider abstraction (stub
only, same honest pattern as payments/notifications/moderation). Adding
rate limiting also closed the last dormant schema table found across
three earlier audit rounds — `SecurityEvent` finally gets written to.
OAuth, DDoS monitoring, and threat feeds remain unimplemented and
genuinely blocked or out of scope for backend code — see docs/07 for the
full control-by-control breakdown of what's real, what's stubbed, and why.

This build has also gone through three rounds of auditing for dormant
schema features — tables or states the schema defines that nothing ever
actually reads or writes. Two were real functional bugs: every listing
was created `PENDING_REVIEW` with no way to ever reach `ACTIVE` (fixed via
an actual moderation queue at `/admin/moderation`), and there was no way
to edit, mark sold, or delete a listing at all, by anyone, once posted
(fixed with owner-facing edit/delete and a relaxed admin removal path). A
third round found three more: `SavedListing` (favoriting — existed since
the first schema commit, referenced in the original mockup, never had any
code), `LoginHistory`, and `AuditLog` — all three now have real code
behind them, though the latter two are data-collection only so far, with
no dedicated admin viewer page yet.

Full loop is wired end-to-end locally, including watermarking, search,
messaging with attachments, notifications, promotions, financial
reporting, refunds, a first analytics slice, and now a working
approve/reject flow that listings actually need to go live: sign up →
post an ad with photos (auto-watermarked) and real category/city/
neighborhood pickers → wait for admin approval → find it via header
search, category filter, or location filter → another user messages the
seller (with photos) through a real inbox/thread → seller promotes the
listing for a real (simulated) charge → admin manages everything from one
`/admin` dashboard home. Payments, notification delivery, and AI
moderation each have a clean provider abstraction — none has a real
external implementation, since this build environment has no network
access or provider credentials, but swapping one in is a one-file change,
not a rewrite. Categories, Geography (all five levels), Promotions, and
Users/Roles are all admin-manageable with no raw UUID inputs left
anywhere. CI runs on
every push. See `backend/README.md` and `frontend/README.md` to run things
locally, and [`docs/00-INDEX.md`](docs/00-INDEX.md) → *Build Readiness*
for what's next.

## Repo Structure

```
docs/       20-document design library — architecture, database, API,
            security, and every subsystem spec. Start at 00-INDEX.md.
mockups/    Standalone HTML mockups of the frontend design system
            (superseded by frontend/ for anything data-driven).
backend/    Node.js + TypeScript API server. Prisma schema + Express
            routes for auth, listings, and media upload.
frontend/   React + TypeScript + Vite app, talking to backend/.
.vscode/    Debug configs, tasks, and workspace settings for VS Code —
            see "Running this in VS Code" below.
```

## Running this in VS Code

1. Open this folder (the repo root, not `backend/` or `frontend/`) in VS Code.
2. Install the recommended extensions when prompted (ESLint, Prettier, Prisma) —
   or `Ctrl+Shift+X` → filter "Recommended".
3. `Terminal → Run Task… → "Backend: Install"`, then `"Frontend: Install"`
   (or just `npm install` in each folder manually).
4. Follow `backend/README.md`'s setup steps (database, `.env`,
   `prisma:generate`, `prisma:migrate`, seed script) — this part isn't
   automated by a VS Code task since it needs a real Postgres instance
   and a `.env` you fill in yourself.
5. `Terminal → Run Task… → "Run Full Stack (backend + frontend)"` starts
   both dev servers in separate panels. Or use the `F5` debug configs in
   `.vscode/launch.json` instead if you want breakpoints — "Backend: dev
   (ts-node-dev, hot reload)" and "Frontend: Launch Chrome" (after
   starting the frontend dev server separately).

`.vscode/settings.json` points the ESLint extension at both subprojects
(this repo has no root `package.json`, so it doesn't find them
automatically) and sets Prettier as the default formatter for both —
`frontend/.prettierrc.json` didn't exist until this setup; it's now a
copy of `backend/.prettierrc.json` so both format the same way.

## Tech Stack (planned)

| Layer | Choice |
|---|---|
| Frontend | TypeScript, React, PWA |
| Backend | Node.js, TypeScript, REST + WebSocket |
| Database | PostgreSQL, Prisma ORM, Redis |
| Deployment | Docker, Ubuntu Server |

Full detail in [`docs/02-master-blueprint.md`](docs/02-master-blueprint.md)
and [`docs/03-system-architecture.md`](docs/03-system-architecture.md).

## Design Library

Start here: [`docs/00-INDEX.md`](docs/00-INDEX.md) — reading order, what's
complete, and five documents (Plugin Architecture, Promotion Engine,
Geographic Manager, Configuration Manager, Analytics & Reporting, Product
Roadmap) that are still stubs and block feature-complete work.

## Mockups

- [`mockups/homepage.html`](mockups/homepage.html) — marketplace homepage
- [`mockups/listing-detail.html`](mockups/listing-detail.html) — single listing view

Visual system: bold maple-red / amber palette, Archivo Black display type,
Space Mono for prices and data, corner-ribbon banners for listing status.

## Contributing

See [`docs/09-development-standards.md`](docs/09-development-standards.md).

## License

TBD.
