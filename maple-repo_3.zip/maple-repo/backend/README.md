# Maple Backend

Node.js + TypeScript API server. Implements the core loop first: auth →
categories/geography lookup → post a listing → view listings.

## Setup

```bash
npm install
cp .env.example .env        # fill in DATABASE_URL at minimum
npm run prisma:generate
npm run prisma:migrate      # creates the schema in Postgres
npx ts-node prisma/seed.ts  # demo marketplace, category tree, admin user
npm run dev
```

The seed script prints an admin login (`admin@maple.demo` / `AdminPass123!`)
— that's the way to reach any `/admin/*` page for the first time. From
there, use `/admin/users` to grant the admin role to other accounts; there's
still no fully self-serve "sign up and become admin" flow, by design.

Requires a running PostgreSQL instance (see `docs/10-deployment-guide.md`
for the Docker-based setup this is meant to run against). Redis is wired
into `.env.example` but not yet used by any route.

## What's implemented

- `POST /api/v1/auth/signup`, `POST /api/v1/auth/login` — email/password,
  now with optional MFA (see below). `signup` also accepts an optional
  `captchaToken` verified through a stub provider (see below). OAuth
  providers (Google/Apple/Microsoft) are modeled in the schema
  (`OAuthAccount`) but not wired up yet.
- `POST /api/v1/auth/mfa/setup`, `/verify`, `/disable` (all require an
  existing session) — TOTP-based MFA. `login` returns `{ mfaRequired: true }`
  instead of a token when the account has MFA enabled and no code was
  provided, so the frontend knows to prompt rather than treat it as a
  failed login.
- **Security modules (docs/07):** rate limiting (`middleware/rateLimit.ts`
  — strict on `/auth`, moderate on `/media`, loose globally; writes a
  `SecurityEvent` row when triggered, closing the last dormant schema
  table found across three audit rounds), MFA via TOTP (`lib/mfa.ts`,
  fully offline — no external service needed, unlike every other provider
  abstraction in this codebase), a CAPTCHA provider abstraction
  (`lib/captcha/provider.ts`, stub only), and a tightened `helmet` CSP for
  this being an API-only process. See docs/07 for a control-by-control
  status table — several controls it lists (OAuth, DDoS monitoring,
  threat feeds, backups) are genuinely blocked or infrastructure-level,
  not oversights, and CSRF protection is explicitly not applicable given
  Bearer-token auth (explained in `src/index.ts`).
- `POST /api/v1/media/upload` — multipart image upload. Pipeline per
  `docs/13-media-engine-design.md`: validates type/size, strips EXIF,
  optimizes, generates thumbnail + medium variants, hashes for exact-duplicate
  detection, stubs an AI moderation result. Watermarking is not implemented —
  the `WatermarkJob` table is ready but nothing writes to it yet. Files are
  stored on local disk under `backend/uploads/` in dev
  (see `src/lib/storage.ts` to swap in S3/object storage).
- `GET /api/v1/listings`, `GET /api/v1/listings/:id`, `POST /api/v1/listings`
  — cursor-paginated list, single-listing fetch, authenticated create.
  Create now accepts `imageIds` (from `/media/upload` responses) and attaches
  them as `ListingImage` rows.
- `PATCH /api/v1/listings/:id` (owner-only), `DELETE /api/v1/listings/:id`
  (owner or admin) — fixes a second real gap alongside the moderation-queue
  bug fix below: before these existed, a seller could post a listing but
  never edit it, mark it sold, or delete it, and an admin could only ever
  reject a listing while it was still `PENDING_REVIEW` — an already-`ACTIVE`
  listing could never be removed by anyone. `PATCH` lets the owner edit
  title/description/price and toggle `ACTIVE`↔`SOLD` only (not into
  admin/system-controlled states). `DELETE` soft-deletes (sets `deletedAt`
  and `status: REMOVED`), which every read path already filters on. Admin's
  `moderation.routes.ts` reject endpoint was relaxed at the same time to
  work on any non-deleted listing, not just `PENDING_REVIEW`.
- `GET /api/v1/health` — DB connectivity check.

- `GET /api/v1/categories` (public), `GET /api/v1/categories/admin`,
  `POST /api/v1/categories`, `PATCH /api/v1/categories/:id`,
  `POST /api/v1/categories/reorder`, `DELETE /api/v1/categories/:id`
  (all admin-only via `requireAdmin`) — full CRUD + reorder + soft delete,
  with parent/child nesting. This is what the frontend's category strip and
  `/admin/categories` page are built on; nothing about categories is
  hardcoded anymore.
- Roles are baked into the JWT at login (`requireAdmin` middleware checks
  `roles.includes('admin')`). A role granted after login doesn't apply until
  the next login — accepted tradeoff to avoid a DB round-trip per request.
- `GET /api/v1/geography/countries`, `/states?countryId=`,
  `/cities?stateProvinceId=|search=` (public) and admin-gated
  `POST`/`DELETE` — the full Country → State → City → Neighborhood
  hierarchy now has an API; see the Geography entry further down for
  what's current.
- `GET /api/v1/search?q=` — ILIKE-based search over listing title/description,
  with optional category/city/price filters. Not a real search engine (no
  ranking, no typo tolerance) — see the note in `search.routes.ts` for when
  to revisit that.
- `POST /api/v1/listings/:id/save`, `DELETE /api/v1/listings/:id/save`,
  `GET /api/v1/listings/saved/list?marketplaceId=` — favoriting. The
  `SavedListing` table existed since the first schema commit and was
  referenced in the very first static mockup's "Save listing" button; it
  had no API at all until this pass. Route is `/saved/list`, not `/saved`
  — a bare `/saved` would incorrectly match the earlier-registered `GET
  /:id` route with `id="saved"` (Express matches in registration order).
- `LoginHistory` rows are now written on every login attempt, success or
  failure, in `auth.routes.ts`. Known gap: a failed attempt against an
  email that doesn't exist writes nothing, since `LoginHistory.userId` is
  a required FK with no user to attach to — real for detecting email-
  enumeration attempts, not fixed here.
- `AuditLog` rows are now written for most admin mutations: listing
  approve/reject, role grant/revoke, category create/update/delete/
  reorder, geography create/delete (all five levels), promotion catalog
  updates, and transaction refunds. Not wired into listing edits
  (owner-initiated, not admin) or watermark/media config changes.
- `POST /api/v1/conversations`, `GET /api/v1/conversations`,
  `GET/POST /api/v1/conversations/:id/messages` — buyer/seller messaging.
  Starting a conversation twice for the same listing+buyer reuses the
  existing one. Every message write also creates a `Notification` row
  (best-effort, not transactional with the message itself). Messages now
  accept up to 5 image attachments — the client uploads via the existing
  `POST /media/upload` first, then passes the resulting `{ url, mimeType }`
  pairs when sending. A message needs text or at least one attachment, not
  necessarily both.
- Media upload now applies a configurable, tiled text watermark to the
  `medium` image variant (`src/lib/watermark.ts`), reading
  `Marketplace.configuration.watermark` (enabled/text/opacity). Falls back
  to sane defaults if unset. Watermarking failure degrades gracefully — the
  upload still succeeds with an unwatermarked image, logged via a
  `WatermarkJob` row with `status: 'failed'`.
- `GET /api/v1/notifications` (list + unread count), `POST /:id/read`,
  `POST /read-all`. Notification rows were already being created by the
  messaging endpoints — this is what actually surfaces them.
- `GET /api/v1/promotions/catalog?marketplaceId=`,
  `PATCH /api/v1/promotions/catalog` (admin-only),
  `POST /api/v1/promotions/purchase` — real ledger flow
  (Invoice -> charge -> Transaction -> ListingPromotion), behind a
  `MockPaymentProvider` that always succeeds (see `src/lib/payments/provider.ts`
  — no real payment processor is wired in, by necessity: no network access
  or credentials in this environment). Pricing is now marketplace-
  configurable (`Marketplace.configuration.promotions`), same pattern as
  watermark settings, defaulting to `featured`/`bump` if uncustomized. See
  docs/16.
- `GET /api/v1/admin/finance/summary`, `GET /api/v1/admin/finance/transactions`
  (both admin-only) — total revenue, transaction count, revenue by
  promotion type, daily revenue for the last 30 days, and a paginated raw
  transaction ledger. Aggregation happens in application code (fetch then
  reduce in JS), not a SQL groupBy/date-truncation query — see the comment
  in `finance.routes.ts` for why. Surfaced at `/admin/finance`.
- `GET /geography/regions?stateProvinceId=`, `/geography/neighborhoods?cityId=`,
  plus admin `POST`/`DELETE` for both — closes the geography hierarchy API
  (Country through Neighborhood). Admin UI now covers all five levels
  (`/admin/geography`, five-column drill-down: Country, State, Region,
  City, Neighborhood). `Listing.neighborhoodId` is validated (must belong
  to the listing's `cityId`) on `POST /listings`, filterable on
  `GET /listings` and `GET /search`, and now also filterable from the
  storefront itself — Home and Search both have a city+neighborhood filter
  bar, not just a backend query param nobody calls. `GET /geography/cities/:id`
  was added specifically to make that browse filter URL-persistent
  (`?city=`, `?neighborhood=`) — restoring a bare `cityId` from a
  shared/bookmarked/refreshed URL into a displayable city needed this and
  didn't have it before; only search-by-name and list-by-state existed.
- `POST /admin/finance/transactions/:id/refund` (admin-only) — full refund
  of a succeeded transaction via the payment provider's new `refund()`
  method, blocks double-refund, expires any promotion that transaction
  bought.
- `GET /admin/analytics/overview` (admin-only) — user count, listings by
  status, category count, 30-day signup trend. A slice of Site + User
  Metrics, not full analytics — see docs/19.
- `GET /admin/users?marketplaceId=`, `GET /admin/users/roles`,
  `POST /admin/users/:id/roles`, `DELETE /admin/users/:id/roles/:roleId`
  (all admin-only) — list users with their roles, grant/revoke roles.
  Blocks an admin from revoking their own admin role specifically (not a
  general "last admin in the marketplace" check) since there's still no
  other way back in besides direct DB access if that happens.
- `GET /admin/moderation/queue?marketplaceId=`,
  `POST /admin/moderation/listings/:id/approve`,
  `POST /admin/moderation/listings/:id/reject` (all admin-only) — this is
  the fix for a real bug, not just a nice-to-have: every listing is
  created with `status: PENDING_REVIEW`, and `GET /listings` /
  `GET /search` only return `status: ACTIVE`. Nothing anywhere transitioned
  a listing between those two states before this endpoint existed — every
  listing ever posted through the app was permanently invisible on the
  homepage and in search. Approve/reject both append a row to
  `ListingStatusHistory`.
- Search now ranks results instead of just ordering by recency (see
  `search.routes.ts` for the scoring approach and why it's not a
  tsvector/GIN-index migration).

## What's not implemented yet

AI operations beyond the moderation stub, most of `docs/05-api-specification.md`'s
remaining sections (webhooks, admin-panel-wide API beyond what's listed
below). Also still open within what exists:
- Search has no ranking beyond the application-level scoring described
  above — still not a real search engine, no typo tolerance.
- Payments: no real provider (mock only), no refund flow. Financial
  reporting now exists (`/admin/finance`) but is revenue-only — no expense/
  payout tracking, no export, no date-range filtering beyond the fixed
  last-30-days chart.
- Promotions: pricing/duration are now admin-configurable (`/admin/promotions`)
  — "bump" still only reorders within the current page (see docs/16);
  expired promotions aren't cleaned up, just filtered out of queries; no
  currency validation against what the payment provider actually supports.
- Messaging has no read-receipt UI signal beyond marking rows read on fetch,
  no typing indicators. Attachments now work (see below) — that gap is
  closed.
- Notification *delivery* now goes through a real abstraction
  (`lib/notifications/channel.ts`) instead of being purely in-app —
  `ConsoleChannel` logs what would be sent, in the shape a real
  email/SMS/push channel would need. No actual external delivery happens;
  there's no network access or provider credentials in this environment to
  build and verify one. Swapping in a real channel means implementing
  `NotificationChannel` and changing `getNotificationChannel()`'s return
  value. Only `type: 'message'` triggers delivery today; `listing_status`,
  `promotion`, and `system` notification types exist in the schema but
  nothing generates them.
- Watermarking is text-only (no per-marketplace logo image compositing),
  applied to the `medium` variant only (not `thumbnail`), and only tiled
  text — no configurable position/corner-only placement.
- Perceptual (near-duplicate) image hashing vs. today's exact content hash.
- AI moderation now goes through a real provider abstraction
  (`lib/moderation/provider.ts`) instead of an inline stub object literal
  — but `StubModerationProvider` still does no real content moderation
  (just an image-too-small check), for the same reason as payments and
  notification delivery: no network access to an actual moderation API in
  this environment.
- Users/Roles admin UI only covers the `admin` role — no listing of all
  `Role`/`Permission` rows, no way to create new roles or assign anything
  other than `admin` from the UI (though the API supports any `roleId`).
- Refunds: full-refund only, no partial refunds. No currency validation
  against what the payment provider actually supports (same gap noted for
  promotion pricing).
- Analytics: only two slices exist (Revenue; Site+User). Category and
  Geographic Metrics haven't been started — see docs/19.

## Schema

`prisma/schema.prisma` mirrors `docs/04-database-design.md` domain-by-domain.
Notable simplifications, called out in the schema's header comment:
promotion pricing/lifecycle, plugin data, and dedicated analytics tables
are deferred to their respective (currently stub) design docs.
