import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';

import { healthRouter } from './routes/health.routes';
import { authRouter } from './routes/auth.routes';
import { listingsRouter } from './routes/listings.routes';
import { mediaRouter } from './routes/media.routes';
import { categoriesRouter } from './routes/categories.routes';
import { geographyRouter } from './routes/geography.routes';
import { searchRouter } from './routes/search.routes';
import { conversationsRouter } from './routes/conversations.routes';
import { notificationsRouter } from './routes/notifications.routes';
import { promotionsRouter } from './routes/promotions.routes';
import { financeRouter } from './routes/finance.routes';
import { analyticsRouter } from './routes/analytics.routes';
import { usersRouter } from './routes/users.routes';
import { moderationRouter } from './routes/moderation.routes';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { authRateLimiter, generalRateLimiter, uploadRateLimiter } from './middleware/rateLimit';

const app = express();

// --- Security baseline (docs/07-security-architecture.md) ---
// Secure headers: helmet's defaults cover most of this (X-Content-Type-
// Options, X-Frame-Options, etc.). Explicit CSP added on top — helmet's
// default CSP is permissive about inline scripts in ways that don't suit
// an API server (it has no HTML views to worry about breaking), so this
// tightens it to reflect that this process serves JSON + static uploads,
// nothing else.
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'none'"],
        imgSrc: ["'self'"],
        connectSrc: ["'self'"],
      },
    },
  }),
);
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(generalRateLimiter);

// Dev-mode static serving for locally stored uploads.
// Swap for CDN/object-storage URLs in production — see src/lib/storage.ts.
app.use('/uploads', express.static('uploads'));

// CSRF: not implemented, and deliberately not — this API authenticates via
// a Bearer JWT in the Authorization header (see middleware/auth.ts), not a
// cookie the browser attaches automatically. CSRF is an attack on
// cookie-based auth specifically (a malicious site can make the browser
// send a request with the victim's cookies, but it can't read or attach an
// Authorization header it doesn't have). cookie-parser is still a
// dependency here but nothing currently uses it for authentication — if
// that changes (e.g. moving the JWT into an httpOnly cookie), CSRF
// protection becomes necessary and isn't optional at that point.
//
// SQL injection: Prisma parameterizes every query it generates; nothing in
// this codebase builds raw SQL from user input ($queryRaw is never called
// anywhere in this backend). Not a separate module to add — a property of
// using the ORM as intended throughout.

// --- Routes, versioned per docs/05-api-specification.md ---
const v1 = express.Router();
v1.use(healthRouter); // GET /api/v1/health
v1.use('/auth', authRateLimiter, authRouter); // POST /api/v1/auth/signup, /login
v1.use('/listings', listingsRouter); // /api/v1/listings
v1.use('/media', uploadRateLimiter, mediaRouter); // POST /api/v1/media/upload
v1.use('/categories', categoriesRouter); // /api/v1/categories, /api/v1/categories/admin
v1.use('/geography', geographyRouter); // /api/v1/geography/countries, /states, /cities
v1.use('/search', searchRouter); // GET /api/v1/search?q=
v1.use('/conversations', conversationsRouter); // /api/v1/conversations, /:id/messages
v1.use('/notifications', notificationsRouter); // /api/v1/notifications
v1.use('/promotions', promotionsRouter); // /api/v1/promotions/catalog, /purchase
v1.use('/admin/finance', financeRouter); // /api/v1/admin/finance/summary, /transactions
v1.use('/admin/analytics', analyticsRouter); // /api/v1/admin/analytics/overview
v1.use('/admin/users', usersRouter); // /api/v1/admin/users, /roles, /:id/roles
v1.use('/admin/moderation', moderationRouter); // /api/v1/admin/moderation/queue, /listings/:id/approve|reject

app.use('/api/v1', v1);

app.use(notFoundHandler);
app.use(errorHandler);

const port = process.env.PORT ? Number(process.env.PORT) : 4000;
app.listen(port, () => {
  console.log(`Maple API listening on http://localhost:${port}`);
});
