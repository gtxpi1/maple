import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { requireAdmin, requireAuth } from '../middleware/auth';

export const analyticsRouter = Router();

analyticsRouter.use(requireAuth, requireAdmin);

// GET /api/v1/admin/analytics/overview?marketplaceId=xxx
//
// Covers a slice of two of docs/19's five metric domains — Site Metrics
// (listing counts) and User Metrics (signup trend) — not all five. Category
// and Geographic Metrics still have nothing. Same aggregation approach as
// finance.routes.ts: fetch then reduce in application code, not a SQL
// groupBy/date-truncation query, for the same reason (no way to write and
// verify raw SQL against a live database in this sandbox).
analyticsRouter.get('/overview', async (req, res, next) => {
  try {
    const marketplaceId = z.string().uuid().parse(req.query.marketplaceId);

    const [userCount, listingsByStatus, categoryCount, users] = await Promise.all([
      prisma.user.count({ where: { marketplaceId, deletedAt: null } }),
      prisma.listing.groupBy({
        by: ['status'],
        where: { marketplaceId, deletedAt: null },
        _count: { _all: true },
      }),
      prisma.category.count({ where: { marketplaceId, deletedAt: null } }),
      prisma.user.findMany({
        where: { marketplaceId, deletedAt: null },
        select: { createdAt: true },
      }),
    ]);

    const listingCounts: Record<string, number> = {};
    for (const row of listingsByStatus) {
      listingCounts[row.status] = row._count._all;
    }
    const totalListings = Object.values(listingCounts).reduce((sum, n) => sum + n, 0);

    // Signups per day, last 30 days.
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const byDay: Record<string, number> = {};
    for (const u of users) {
      if (u.createdAt < cutoff) continue;
      const day = u.createdAt.toISOString().slice(0, 10);
      byDay[day] = (byDay[day] ?? 0) + 1;
    }
    const dailySignups = Object.entries(byDay)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => a.date.localeCompare(b.date));

    res.json({
      data: {
        userCount,
        totalListings,
        listingsByStatus: listingCounts,
        categoryCount,
        dailySignups,
      },
    });
  } catch (err) {
    next(err);
  }
});
