import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { logAudit } from '../lib/audit';
import { AuthedRequest, requireAdmin, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const moderationRouter = Router();

moderationRouter.use(requireAuth, requireAdmin);

// GET /api/v1/admin/moderation/queue?marketplaceId=xxx
//
// This is the fix for a real bug, not just a missing admin nicety: every
// listing is created with status PENDING_REVIEW (listings.routes.ts), and
// GET /listings / GET /search both only return status ACTIVE. Before this
// file, nothing anywhere transitioned a listing out of PENDING_REVIEW —
// every listing ever posted was permanently invisible on the homepage and
// in search. This queue plus the approve/reject endpoints below are what
// actually closes that loop.
const queueQuerySchema = z.object({
  marketplaceId: z.string().uuid(),
  cursor: z.string().uuid().optional(),
  limit: z.coerce.number().min(1).max(50).default(20),
});

moderationRouter.get('/queue', async (req, res, next) => {
  try {
    const query = queueQuerySchema.parse(req.query);

    const listings = await prisma.listing.findMany({
      where: { marketplaceId: query.marketplaceId, status: 'PENDING_REVIEW', deletedAt: null },
      take: query.limit,
      ...(query.cursor && { cursor: { id: query.cursor }, skip: 1 }),
      orderBy: { createdAt: 'asc' }, // oldest first — first in, first reviewed
      include: {
        images: {
          orderBy: { position: 'asc' },
          include: {
            uploadedFile: {
              include: {
                variants: true,
                moderationResults: { orderBy: { createdAt: 'desc' }, take: 1 },
              },
            },
          },
        },
        user: { select: { id: true, displayName: true, email: true, trustScore: true } },
        category: true,
        city: true,
      },
    });

    const nextCursor =
      listings.length === query.limit ? listings[listings.length - 1].id : null;
    res.json({ data: listings, nextCursor });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/admin/moderation/listings/:id/approve
moderationRouter.post('/listings/:id/approve', async (req: AuthedRequest, res, next) => {
  try {
    const listing = await prisma.listing.findUnique({ where: { id: req.params.id } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    if (listing.status !== 'PENDING_REVIEW') {
      throw new ApiError(400, 'not_pending', 'Only pending-review listings can be approved.');
    }

    const updated = await prisma.listing.update({
      where: { id: req.params.id },
      data: {
        status: 'ACTIVE',
        statusHistory: {
          create: { status: 'ACTIVE', note: `Approved by admin ${req.user!.id}` },
        },
      },
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'listing.approve',
      targetType: 'Listing',
      targetId: req.params.id,
    });

    res.json({ data: updated });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/admin/moderation/listings/:id/reject
//
// Works on any non-deleted listing, not just PENDING_REVIEW — an admin
// needs to be able to take down an already-live listing too (a complaint
// about an ACTIVE listing, not just a first-review rejection). This was
// originally PENDING_REVIEW-only, which combined with the fact that
// listings.routes.ts had no DELETE endpoint at all meant an approved
// listing could never be removed by anyone, admin included. Fixed
// alongside adding owner-facing PATCH/DELETE to listings.routes.ts.
const rejectSchema = z.object({ note: z.string().max(500).optional() });

moderationRouter.post('/listings/:id/reject', async (req: AuthedRequest, res, next) => {
  try {
    const body = rejectSchema.parse(req.body);

    const listing = await prisma.listing.findUnique({ where: { id: req.params.id } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    if (listing.status === 'REMOVED') {
      throw new ApiError(400, 'already_removed', 'This listing is already removed.');
    }

    const updated = await prisma.listing.update({
      where: { id: req.params.id },
      data: {
        status: 'REMOVED',
        statusHistory: {
          create: {
            status: 'REMOVED',
            note: body.note
              ? `Rejected by admin ${req.user!.id}: ${body.note}`
              : `Rejected by admin ${req.user!.id}`,
          },
        },
      },
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'listing.reject',
      targetType: 'Listing',
      targetId: req.params.id,
      metadata: { note: body.note ?? null },
    });

    res.json({ data: updated });
  } catch (err) {
    next(err);
  }
});
