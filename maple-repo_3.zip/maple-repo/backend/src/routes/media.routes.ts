import { Router } from 'express';
import multer from 'multer';
import sharp from 'sharp';
import crypto from 'crypto';
import { prisma } from '../lib/prisma';
import { publicUrl, saveBuffer } from '../lib/storage';
import { applyWatermark, resolveWatermarkConfig } from '../lib/watermark';
import { getModerationProvider } from '../lib/moderation/provider';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const mediaRouter = Router();

const ALLOWED_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_SIZE_BYTES },
});

// POST /api/v1/media/upload
// Implements: Upload -> Validate -> Optimize -> Strip metadata ->
//             Generate thumbnails -> Watermark (configurable, medium size
//             only) -> Store
// per docs/13-media-engine-design.md.
mediaRouter.post(
  '/upload',
  requireAuth,
  upload.single('file'),
  async (req: AuthedRequest, res, next) => {
    try {
      if (!req.file) {
        throw new ApiError(400, 'no_file', 'No file provided under the "file" field.');
      }

      // --- Validate ---
      if (!ALLOWED_MIME.has(req.file.mimetype)) {
        throw new ApiError(
          415,
          'unsupported_media_type',
          'Only JPEG, PNG, and WebP images are supported.',
        );
      }

      const original = sharp(req.file.buffer);
      const metadata = await original.metadata();
      if (!metadata.width || !metadata.height) {
        throw new ApiError(422, 'invalid_image', 'Could not read image dimensions.');
      }

      // --- Duplicate detection ---
      // NOTE: this is a content hash (exact-duplicate detection), not a
      // perceptual hash. docs/13 calls for "Image hashing" for near-duplicate
      // detection (e.g. re-compressed/re-sized re-uploads) — swap in a
      // perceptual hash library (e.g. phash) here when that's prioritized.
      const contentHash = crypto.createHash('sha256').update(req.file.buffer).digest('hex');
      const duplicate = await prisma.mediaHash.findFirst({ where: { hash: contentHash } });
      if (duplicate) {
        const existing = await prisma.uploadedFile.findUnique({
          where: { id: duplicate.uploadedFileId },
          include: { variants: true },
        });
        res.status(200).json({ data: existing, duplicate: true });
        return;
      }

      // --- Optimize + strip metadata ---
      // sharp drops EXIF/IPTC by default unless .withMetadata() is called,
      // so simply not calling it satisfies "Strip metadata".
      const optimizedBuffer = await original
        .rotate() // apply EXIF orientation before stripping it
        .jpeg({ quality: 85, mozjpeg: true })
        .toBuffer();

      const originalStored = await saveBuffer(optimizedBuffer, '.jpg');

      const uploadedFile = await prisma.uploadedFile.create({
        data: {
          userId: req.user!.id,
          originalUrl: originalStored.relativePath,
          mimeType: 'image/jpeg',
          sizeBytes: optimizedBuffer.byteLength,
        },
      });

      await prisma.mediaHash.create({
        data: { uploadedFileId: uploadedFile.id, hash: contentHash, algorithm: 'sha256' },
      });

      // --- Watermark config ---
      // Per-marketplace, read from Marketplace.configuration (see docs/18,
      // still a stub for the general config mechanism — this is one
      // concrete consumer of that JSON blob in the meantime).
      const marketplace = await prisma.marketplace.findUnique({
        where: { id: req.user!.marketplaceId },
        select: { configuration: true },
      });
      const watermarkConfig = resolveWatermarkConfig(marketplace?.configuration);

      // --- Generate variants (multiple sizes; watermark applied to the
      //     sizes actually shown publicly, not the small admin thumbnail) ---
      const sizes: Array<{ label: string; width: number; watermark: boolean }> = [
        { label: 'thumbnail', width: 200, watermark: false },
        { label: 'medium', width: 800, watermark: watermarkConfig.enabled },
      ];

      const variants = [];
      let watermarkFailed = false;

      for (const size of sizes) {
        let resized = await sharp(optimizedBuffer)
          .resize({ width: size.width, withoutEnlargement: true })
          .jpeg({ quality: 80 })
          .toBuffer();

        if (size.watermark) {
          try {
            resized = await applyWatermark(resized, watermarkConfig);
          } catch (watermarkErr) {
            // Degrade gracefully: ship the clean (unwatermarked) image
            // rather than failing the whole upload over a compositing error.
            console.error('Watermarking failed:', watermarkErr);
            watermarkFailed = true;
          }
        }

        const stored = await saveBuffer(resized, '.jpg');
        const resizedMeta = await sharp(resized).metadata();

        variants.push(
          await prisma.imageVariant.create({
            data: {
              uploadedFileId: uploadedFile.id,
              size: size.label,
              url: stored.relativePath,
              width: resizedMeta.width,
              height: resizedMeta.height,
            },
          }),
        );
      }

      await prisma.watermarkJob.create({
        data: {
          uploadedFileId: uploadedFile.id,
          status: !watermarkConfig.enabled ? 'skipped' : watermarkFailed ? 'failed' : 'completed',
          completedAt: new Date(),
        },
      });

      // --- AI moderation ---
      // Uses the provider abstraction in lib/moderation/provider.ts — see
      // that file for what StubModerationProvider actually does (very
      // little; no real content moderation happens without network access
      // to a real provider).
      const moderationResult = await getModerationProvider().moderate(optimizedBuffer, {
        width: metadata.width,
        height: metadata.height,
      });
      await prisma.aIModerationResult.create({
        data: {
          uploadedFileId: uploadedFile.id,
          flagged: moderationResult.flagged,
          categories: moderationResult.categories,
          rawResult: moderationResult.raw,
        },
      });

      res.status(201).json({
        data: {
          id: uploadedFile.id,
          url: publicUrl(originalStored.relativePath),
          variants: variants.map((v) => ({ size: v.size, url: publicUrl(v.url), width: v.width, height: v.height })),
        },
      });
    } catch (err) {
      next(err);
    }
  },
);
