import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { generateSecret, getOtpAuthUrl, getQrCodeDataUrl, verifyToken } from '../lib/mfa';
import { getCaptchaProvider } from '../lib/captcha/provider';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const authRouter = Router();

const signupSchema = z.object({
  marketplaceId: z.string().uuid(),
  email: z.string().email(),
  password: z.string().min(8),
  displayName: z.string().min(1).max(80),
  captchaToken: z.string().optional(),
});

// POST /api/v1/auth/signup
authRouter.post('/signup', async (req, res, next) => {
  try {
    const body = signupSchema.parse(req.body);

    const captchaResult = await getCaptchaProvider().verify(body.captchaToken);
    if (!captchaResult.success) {
      throw new ApiError(
        400,
        'captcha_failed',
        captchaResult.failureReason || 'CAPTCHA verification failed.',
      );
    }

    const existing = await prisma.user.findUnique({
      where: { marketplaceId_email: { marketplaceId: body.marketplaceId, email: body.email } },
    });
    if (existing) {
      throw new ApiError(409, 'email_taken', 'An account with this email already exists.');
    }

    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await prisma.user.create({
      data: {
        marketplaceId: body.marketplaceId,
        email: body.email,
        passwordHash,
        displayName: body.displayName,
      },
    });

    // New signups have no roles yet — there's no self-serve path to become
    // admin. Promote via prisma studio or the seed script for now (see
    // backend/README.md).
    const token = await signToken(user.id, user.marketplaceId, []);
    res.status(201).json({ token, user: toPublicUser(user, []) });
  } catch (err) {
    next(err);
  }
});

const loginSchema = z.object({
  marketplaceId: z.string().uuid(),
  email: z.string().email(),
  password: z.string(),
  mfaToken: z.string().length(6).optional(),
});

// POST /api/v1/auth/login
authRouter.post('/login', async (req, res, next) => {
  try {
    const body = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({
      where: { marketplaceId_email: { marketplaceId: body.marketplaceId, email: body.email } },
    });
    const passwordOk =
      user?.passwordHash && (await bcrypt.compare(body.password, user.passwordHash));

    // Written for both outcomes — a security-relevant login history is
    // only useful if failed attempts show up too, not just successes.
    // Failed attempts with no matching user (user === null) aren't
    // recorded here since LoginHistory.userId is a required FK; a
    // wrong-email failed attempt has no user row to attach to. That's a
    // real gap for detecting email-enumeration attempts, not an oversight
    // — logging those would need a schema change (nullable userId, or a
    // separate table) that wasn't made.
    if (user) {
      await prisma.loginHistory.create({
        data: {
          userId: user.id,
          ipAddress: req.ip,
          userAgent: req.get('user-agent'),
          success: Boolean(passwordOk),
        },
      });
    }

    if (!passwordOk) {
      throw new ApiError(401, 'invalid_credentials', 'Incorrect email or password.');
    }

    // MFA check happens after password verification, not before — this
    // avoids leaking "does this account have MFA enabled" to someone who
    // hasn't even proven they know the password yet.
    if (user!.mfaEnabled) {
      if (!body.mfaToken) {
        // Distinct response, not an error: the frontend uses this to know
        // to show a "enter your 6-digit code" screen instead of treating
        // it as a failed login. No token is issued at this point.
        res.status(200).json({ mfaRequired: true });
        return;
      }
      if (!verifyToken(body.mfaToken, user!.mfaSecret!)) {
        throw new ApiError(401, 'invalid_mfa_token', 'Incorrect authentication code.');
      }
    }

    const userRoles = await prisma.userRole.findMany({
      where: { userId: user!.id },
      include: { role: true },
    });
    const roles = userRoles.map((ur) => ur.role.name);

    const token = await signToken(user!.id, user!.marketplaceId, roles);
    res.json({ token, user: toPublicUser(user, roles) });
  } catch (err) {
    next(err);
  }
});

// ---------- MFA setup / verify / disable ----------
// All require an existing valid session (requireAuth) — enabling MFA is
// something an already-logged-in user does from a settings page, not part
// of the signup flow itself.

// POST /api/v1/auth/mfa/setup
// Generates a new secret and returns the otpauth:// URL + a QR code the
// frontend can render directly (data:image/png;base64,...). Does NOT
// enable MFA yet — the secret is returned to the client but not saved to
// the user's row until /mfa/verify confirms the user actually scanned it
// and can produce a valid code. Calling /setup again before /verify
// simply generates a new secret, discarding the unconfirmed one.
authRouter.post('/mfa/setup', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) throw new ApiError(404, 'user_not_found', 'User not found.');
    if (user.mfaEnabled) {
      throw new ApiError(400, 'mfa_already_enabled', 'MFA is already enabled on this account.');
    }

    const secret = generateSecret();
    const otpAuthUrl = getOtpAuthUrl(user.email, secret);
    const qrCodeDataUrl = await getQrCodeDataUrl(otpAuthUrl);

    // Stored now, but mfaEnabled stays false until /mfa/verify confirms
    // it — so a half-finished setup (user closes the tab before scanning)
    // doesn't lock them into a broken enabled-but-unconfirmed state.
    await prisma.user.update({ where: { id: user.id }, data: { mfaSecret: secret } });

    res.json({ data: { secret, otpAuthUrl, qrCodeDataUrl } });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/auth/mfa/verify
const mfaVerifySchema = z.object({ token: z.string().length(6) });

authRouter.post('/mfa/verify', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const body = mfaVerifySchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user?.mfaSecret) {
      throw new ApiError(400, 'mfa_not_set_up', 'Call /mfa/setup first.');
    }

    if (!verifyToken(body.token, user.mfaSecret)) {
      throw new ApiError(401, 'invalid_mfa_token', 'Incorrect authentication code.');
    }

    await prisma.user.update({ where: { id: user.id }, data: { mfaEnabled: true } });
    res.json({ data: { mfaEnabled: true } });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/auth/mfa/disable
// Requires the current password, not just an active session — disabling
// MFA is a security-downgrade action, so it gets the same bar as changing
// a password would, not just "logged in."
const mfaDisableSchema = z.object({ password: z.string() });

authRouter.post('/mfa/disable', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const body = mfaDisableSchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user?.passwordHash || !(await bcrypt.compare(body.password, user.passwordHash))) {
      throw new ApiError(401, 'invalid_credentials', 'Incorrect password.');
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { mfaEnabled: false, mfaSecret: null },
    });
    res.json({ data: { mfaEnabled: false } });
  } catch (err) {
    next(err);
  }
});

// Roles are baked into the token at sign-in — see the tradeoff note in
// middleware/auth.ts (a role granted after login won't apply until the
// next login).
async function signToken(userId: string, marketplaceId: string, roles: string[]): Promise<string> {
  return jwt.sign({ sub: userId, marketplaceId, roles }, process.env.JWT_SECRET as string, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function toPublicUser(user: any, roles: string[]) {
  return {
    id: user.id,
    email: user.email,
    displayName: user.displayName,
    roles,
    mfaEnabled: Boolean(user.mfaEnabled),
  };
}
