import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { getPaymentProvider } from '../lib/payments/provider';
import { logAudit } from '../lib/audit';
import { AuthedRequest, requireAdmin, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const financeRouter = Router();

financeRouter.use(requireAuth, requireAdmin);

// Transaction has no direct marketplaceId column — it hangs off
// Invoice -> User -> marketplaceId. Every query here joins through that
// path rather than denormalizing marketplaceId onto Transaction, since the
// ledger table is meant to stay minimal and insert-only (see docs/14).

// GET /api/v1/admin/finance/summary?marketplaceId=xxx
//
// Aggregation happens in application code, not a Prisma groupBy or raw SQL
// date-truncation query — Prisma's groupBy only groups on exact column
// values, not "by day", and writing a raw SQL date_trunc query isn't
// something that could be tested against a live database in this sandbox.
// Fine at demo/early-stage transaction volumes; revisit with a real SQL
// aggregation (or a scheduled rollup table) if this ever needs to scan
// more than a few thousand rows per request.
financeRouter.get('/summary', async (req: AuthedRequest, res, next) => {
  try {
    const marketplaceId = z.string().uuid().parse(req.query.marketplaceId);

    const transactions = await prisma.transaction.findMany({
      where: { status: 'succeeded', invoice: { user: { marketplaceId } } },
      select: { id: true, amount: true, currency: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
    });

    const promotionPurchases = await prisma.promotionPurchase.findMany({
      where: { transaction: { status: 'succeeded', invoice: { user: { marketplaceId } } } },
      select: { promotionType: true, transaction: { select: { amount: true } } },
    });

    const totalRevenue = transactions.reduce((sum, t) => sum + Number(t.amount), 0);

    const revenueByType: Record<string, { count: number; revenue: number }> = {};
    for (const p of promotionPurchases) {
      const entry = revenueByType[p.promotionType] ?? { count: 0, revenue: 0 };
      entry.count += 1;
      entry.revenue += Number(p.transaction.amount);
      revenueByType[p.promotionType] = entry;
    }

    // Last 30 days, bucketed by calendar day (UTC).
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const byDay: Record<string, number> = {};
    for (const t of transactions) {
      if (t.createdAt < cutoff) continue;
      const day = t.createdAt.toISOString().slice(0, 10);
      byDay[day] = (byDay[day] ?? 0) + Number(t.amount);
    }
    const dailyRevenue = Object.entries(byDay)
      .map(([date, revenue]) => ({ date, revenue }))
      .sort((a, b) => a.date.localeCompare(b.date));

    res.json({
      data: {
        totalRevenue,
        transactionCount: transactions.length,
        currency: transactions[0]?.currency ?? 'USD',
        revenueByPromotionType: revenueByType,
        dailyRevenue,
      },
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/admin/finance/transactions?marketplaceId=xxx&cursor=&limit=
// Raw ledger view for the admin UI's transaction table.
const transactionsQuerySchema = z.object({
  marketplaceId: z.string().uuid(),
  cursor: z.string().uuid().optional(),
  limit: z.coerce.number().min(1).max(100).default(50),
});

financeRouter.get('/transactions', async (req: AuthedRequest, res, next) => {
  try {
    const query = transactionsQuerySchema.parse(req.query);

    const transactions = await prisma.transaction.findMany({
      where: { invoice: { user: { marketplaceId: query.marketplaceId } } },
      take: query.limit,
      ...(query.cursor && { cursor: { id: query.cursor }, skip: 1 }),
      orderBy: { createdAt: 'desc' },
      include: {
        invoice: { include: { user: { select: { id: true, displayName: true, email: true } } } },
        promotionPurchases: { select: { promotionType: true, listingId: true } },
        refunds: { select: { id: true, status: true, amount: true, createdAt: true } },
      },
    });

    const nextCursor =
      transactions.length === query.limit ? transactions[transactions.length - 1].id : null;
    res.json({ data: transactions, nextCursor });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/admin/finance/transactions/:id/refund
//
// Refunds the full amount of a succeeded transaction. Also expires any
// ListingPromotion(s) purchased with this transaction immediately — a
// refunded promotion shouldn't keep showing a FEATURED ribbon or bumped
// ordering. Does NOT reverse the Invoice back to "paid" if already
// refunded once (blocked below); a transaction can only be refunded once
// in this implementation, matching the "full refund only" scope — partial
// refunds aren't supported.
const refundSchema = z.object({ reason: z.string().max(500).optional() });

financeRouter.post('/transactions/:id/refund', async (req: AuthedRequest, res, next) => {
  try {
    const body = refundSchema.parse(req.body);

    const transaction = await prisma.transaction.findUnique({
      where: { id: req.params.id },
      include: { refunds: true, promotionPurchases: true },
    });
    if (!transaction) {
      throw new ApiError(404, 'transaction_not_found', 'Transaction not found.');
    }
    if (transaction.status !== 'succeeded') {
      throw new ApiError(
        400,
        'not_refundable',
        'Only succeeded transactions can be refunded.',
      );
    }
    if (transaction.refunds.some((r) => r.status === 'completed')) {
      throw new ApiError(409, 'already_refunded', 'This transaction has already been refunded.');
    }

    const refundResult = await getPaymentProvider().refund({
      originalExternalRef: transaction.externalRef ?? transaction.id,
      amountCents: Math.round(Number(transaction.amount) * 100),
      reason: body.reason,
    });

    if (!refundResult.success) {
      throw new ApiError(502, 'refund_failed', refundResult.failureReason || 'Refund failed.');
    }

    const result = await prisma.$transaction(async (tx) => {
      const refund = await tx.refund.create({
        data: {
          transactionId: transaction.id,
          invoiceId: transaction.invoiceId,
          amount: transaction.amount,
          reason: body.reason,
          status: 'completed',
        },
      });

      await tx.invoice.update({
        where: { id: transaction.invoiceId },
        data: { status: 'refunded' },
      });

      // Void the effect: expire any promotion(s) bought with this
      // transaction right now, rather than waiting for their natural endAt.
      // NOTE: ListingPromotion has no direct FK back to the Transaction/
      // PromotionPurchase that created it, so this matches by
      // (listingId, promotionType, still-active) instead of by exact
      // purchase. If the same listing had two active promotions of the
      // same type from two different transactions (shouldn't normally
      // happen given the purchase flow, but isn't prevented by a DB
      // constraint either), refunding one would incorrectly void both.
      if (transaction.promotionPurchases.length > 0) {
        await tx.listingPromotion.updateMany({
          where: {
            listingId: { in: transaction.promotionPurchases.map((p) => p.listingId) },
            promotionType: { in: transaction.promotionPurchases.map((p) => p.promotionType) },
            endAt: { gt: new Date() },
          },
          data: { endAt: new Date() },
        });
      }

      return refund;
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'transaction.refund',
      targetType: 'Transaction',
      targetId: transaction.id,
      metadata: { amount: transaction.amount.toString(), reason: body.reason ?? null },
    });

    res.status(201).json({ data: result });
  } catch (err) {
    next(err);
  }
});
