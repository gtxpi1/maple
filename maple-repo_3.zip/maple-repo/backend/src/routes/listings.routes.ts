import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const listingsRouter = Router();

// GET /api/v1/listings — paginated, filterable
const listQuerySchema = z.object({
  marketplaceId: z.string().uuid(),
  categoryId: z.string().uuid().optional(),
  categorySlug: z.string().optional(),
  cityId: z.string().uuid().optional(),
  neighborhoodId: z.string().uuid().optional(),
  cursor: z.string().uuid().optional(),
  limit: z.coerce.number().min(1).max(50).default(20),
});

listingsRouter.get('/', async (req, res, next) => {
  try {
    const query = listQuerySchema.parse(req.query);

    const listings = await prisma.listing.findMany({
      where: {
        marketplaceId: query.marketplaceId,
        categoryId: query.categoryId,
        ...(query.categorySlug && { category: { slug: query.categorySlug } }),
        cityId: query.cityId,
        neighborhoodId: query.neighborhoodId,
        status: 'ACTIVE',
        deletedAt: null,
      },
      take: query.limit,
      ...(query.cursor && { cursor: { id: query.cursor }, skip: 1 }),
      orderBy: { createdAt: 'desc' },
      include: {
        images: {
          take: 1,
          orderBy: { position: 'asc' },
          include: { uploadedFile: { include: { variants: true } } },
        },
        city: true,
        neighborhood: true,
        // Active promotions only (endAt in the future) — this is what the
        // frontend uses to decide whether to show a FEATURED ribbon.
        promotions: { where: { endAt: { gt: new Date() } } },
      },
    });

    // Float promoted listings to the top of this page. NOTE: this only
    // reorders within the already-fetched page (query.limit rows) — a
    // "bump" purchased on a listing outside the current page won't pull it
    // onto page 1. True cross-page promoted-first ordering needs an
    // ORDER BY at the database level (e.g. a denormalized
    // `hasActivePromotion` column, updated when promotions are purchased/
    // expire), which is a real follow-up, not implemented here.
    const sorted = [...listings].sort((a, b) => {
      const aPromoted = a.promotions.length > 0 ? 1 : 0;
      const bPromoted = b.promotions.length > 0 ? 1 : 0;
      return bPromoted - aPromoted;
    });

    const nextCursor = listings.length === query.limit ? listings[listings.length - 1].id : null;
    res.json({ data: sorted, nextCursor });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/listings/:id
listingsRouter.get('/:id', async (req, res, next) => {
  try {
    const listing = await prisma.listing.findUnique({
      where: { id: req.params.id },
      include: {
        images: {
          orderBy: { position: 'asc' },
          include: { uploadedFile: { include: { variants: true } } },
        },
        user: { select: { id: true, displayName: true, trustScore: true } },
        category: true,
        city: true,
        neighborhood: true,
        promotions: { where: { endAt: { gt: new Date() } } },
      },
    });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    res.json({ data: listing });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/listings — requires auth
const createListingSchema = z.object({
  marketplaceId: z.string().uuid(),
  categoryId: z.string().uuid(),
  cityId: z.string().uuid(),
  neighborhoodId: z.string().uuid().optional(),
  title: z.string().min(3).max(140),
  description: z.string().min(1).max(5000),
  price: z.number().nonnegative().optional(),
  currency: z.string().length(3).default('USD'),
  imageIds: z.array(z.string().uuid()).max(20).default([]),
});

listingsRouter.post('/', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const { imageIds, ...body } = createListingSchema.parse(req.body);

    if (imageIds.length > 0) {
      const owned = await prisma.uploadedFile.count({
        where: { id: { in: imageIds }, userId: req.user!.id },
      });
      if (owned !== imageIds.length) {
        throw new ApiError(
          400,
          'invalid_image_ids',
          'One or more imageIds were not found or do not belong to you.',
        );
      }
    }

    if (body.neighborhoodId) {
      const neighborhood = await prisma.neighborhood.findUnique({
        where: { id: body.neighborhoodId },
      });
      if (!neighborhood || neighborhood.cityId !== body.cityId) {
        throw new ApiError(
          400,
          'invalid_neighborhood',
          'neighborhoodId must belong to the selected cityId.',
        );
      }
    }

    const listing = await prisma.listing.create({
      data: {
        ...body,
        userId: req.user!.id,
        status: 'PENDING_REVIEW',
        statusHistory: { create: { status: 'PENDING_REVIEW', note: 'Created' } },
        images: {
          create: imageIds.map((uploadedFileId, position) => ({ uploadedFileId, position })),
        },
      },
      include: { images: true, neighborhood: true },
    });

    res.status(201).json({ data: listing });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/v1/listings/:id — owner only.
//
// Fixes a real gap, not just adding a feature: before this endpoint, a
// seller had no way to edit their listing's text/price, or to mark it SOLD
// once it actually sold — the listing just stayed ACTIVE forever with no
// path to change that short of an admin manually rejecting it (and
// moderation.routes.ts's reject only worked on PENDING_REVIEW anyway, so
// even that wasn't available once approved).
//
// Owner can edit title/description/price and toggle status between ACTIVE
// and SOLD only — not into PENDING_REVIEW, REMOVED, DRAFT, or EXPIRED,
// which are system/admin-controlled transitions.
const OWNER_ALLOWED_STATUSES = new Set(['ACTIVE', 'SOLD']);

const updateListingSchema = z.object({
  title: z.string().min(3).max(140).optional(),
  description: z.string().min(1).max(5000).optional(),
  price: z.number().nonnegative().optional(),
  status: z.enum(['ACTIVE', 'SOLD']).optional(),
});

listingsRouter.patch('/:id', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const body = updateListingSchema.parse(req.body);

    const listing = await prisma.listing.findUnique({ where: { id: req.params.id } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    if (listing.userId !== req.user!.id) {
      throw new ApiError(403, 'forbidden', 'You can only edit your own listings.');
    }
    if (body.status && !OWNER_ALLOWED_STATUSES.has(listing.status)) {
      throw new ApiError(
        400,
        'not_editable_status',
        `Can't change status while the listing is ${listing.status}.`,
      );
    }

    const { status, ...fields } = body;

    const updated = await prisma.listing.update({
      where: { id: req.params.id },
      data: {
        ...fields,
        ...(status &&
          status !== listing.status && {
            status,
            statusHistory: { create: { status, note: `Changed by owner ${req.user!.id}` } },
          }),
      },
      include: {
        images: { include: { uploadedFile: { include: { variants: true } } } },
        neighborhood: true,
      },
    });

    res.json({ data: updated });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/listings/:id — owner or admin.
//
// Soft delete: sets deletedAt and status REMOVED. GET /listings, GET
// /listings/:id, and GET /search already all check deletedAt === null, so
// this immediately makes the listing disappear everywhere.
listingsRouter.delete('/:id', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const listing = await prisma.listing.findUnique({ where: { id: req.params.id } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    if (listing.userId !== req.user!.id && !req.user!.roles.includes('admin')) {
      throw new ApiError(403, 'forbidden', 'You can only delete your own listings.');
    }

    await prisma.listing.update({
      where: { id: req.params.id },
      data: {
        deletedAt: new Date(),
        status: 'REMOVED',
        statusHistory: { create: { status: 'REMOVED', note: `Deleted by ${req.user!.id}` } },
      },
    });

    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/listings/:id/save — favorite a listing.
// Was defined in the schema (SavedListing) since the very first schema
// commit, referenced in the original static mockup's "Save listing"
// button, and never had an API until now.
listingsRouter.post('/:id/save', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const listing = await prisma.listing.findUnique({ where: { id: req.params.id } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }

    await prisma.savedListing.upsert({
      where: { userId_listingId: { userId: req.user!.id, listingId: req.params.id } },
      update: {},
      create: { userId: req.user!.id, listingId: req.params.id },
    });

    res.status(201).json({ data: { listingId: req.params.id, saved: true } });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/listings/:id/save — unfavorite.
listingsRouter.delete('/:id/save', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    await prisma.savedListing.deleteMany({
      where: { userId: req.user!.id, listingId: req.params.id },
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/listings/saved/list?marketplaceId= — the current user's saved
// listings, same shape as GET /listings so ListingCard can render them
// directly. Path is /saved/list, not /saved — a bare /saved would be a
// single path segment, and since GET /:id is registered above (Express
// matches routes in registration order), a request to /listings/saved
// would incorrectly match /:id with id="saved" before ever reaching a
// route literally named /saved. Two segments sidesteps that without
// having to reorder every route in this file.
const savedQuerySchema = z.object({ marketplaceId: z.string().uuid() });

listingsRouter.get('/saved/list', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const query = savedQuerySchema.parse(req.query);

    const saved = await prisma.savedListing.findMany({
      where: { userId: req.user!.id, listing: { marketplaceId: query.marketplaceId, deletedAt: null } },
      orderBy: { createdAt: 'desc' },
      include: {
        listing: {
          include: {
            images: {
              take: 1,
              orderBy: { position: 'asc' },
              include: { uploadedFile: { include: { variants: true } } },
            },
            city: true,
            neighborhood: true,
            promotions: { where: { endAt: { gt: new Date() } } },
          },
        },
      },
    });

    res.json({ data: saved.map((s) => s.listing) });
  } catch (err) {
    next(err);
  }
});
