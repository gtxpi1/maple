import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { getNotificationChannel } from '../lib/notifications/channel';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const conversationsRouter = Router();

// All routes here require auth — messaging has no public surface.
conversationsRouter.use(requireAuth);

// POST /api/v1/conversations
// Starts (or reuses) a conversation between the current user and a listing's
// owner. Idempotent: calling this twice for the same listing+buyer returns
// the same conversation instead of creating duplicates, so "Message seller"
// can be safely clicked more than once.
const startSchema = z.object({ listingId: z.string().uuid() });

conversationsRouter.post('/', async (req: AuthedRequest, res, next) => {
  try {
    const { listingId } = startSchema.parse(req.body);

    const listing = await prisma.listing.findUnique({ where: { id: listingId } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    if (listing.userId === req.user!.id) {
      throw new ApiError(400, 'cannot_message_self', "You can't start a conversation with yourself.");
    }

    const existing = await prisma.conversation.findFirst({
      where: {
        listingId,
        participants: { some: { userId: req.user!.id } },
        AND: { participants: { some: { userId: listing.userId } } },
      },
    });
    if (existing) {
      res.json({ data: existing });
      return;
    }

    const conversation = await prisma.conversation.create({
      data: {
        listingId,
        participants: {
          create: [{ userId: req.user!.id }, { userId: listing.userId }],
        },
      },
    });

    res.status(201).json({ data: conversation });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/conversations
// Inbox: every conversation the current user is part of, with the other
// participant, the listing it's about, and a preview of the last message.
conversationsRouter.get('/', async (req: AuthedRequest, res, next) => {
  try {
    const conversations = await prisma.conversation.findMany({
      where: { participants: { some: { userId: req.user!.id } } },
      orderBy: { updatedAt: 'desc' },
      include: {
        listing: { select: { id: true, title: true } },
        participants: {
          include: { user: { select: { id: true, displayName: true } } },
        },
        messages: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });

    res.json({
      data: conversations.map((c) => ({
        id: c.id,
        listing: c.listing,
        otherParticipant: c.participants.find((p) => p.userId !== req.user!.id)?.user ?? null,
        lastMessage: c.messages[0] ?? null,
        updatedAt: c.updatedAt,
      })),
    });
  } catch (err) {
    next(err);
  }
});

async function assertParticipant(conversationId: string, userId: string): Promise<void> {
  const participant = await prisma.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId } },
  });
  if (!participant) {
    throw new ApiError(403, 'forbidden', "You're not part of this conversation.");
  }
}

// GET /api/v1/conversations/:id/messages
conversationsRouter.get('/:id/messages', async (req: AuthedRequest, res, next) => {
  try {
    await assertParticipant(req.params.id, req.user!.id);

    const messages = await prisma.message.findMany({
      where: { conversationId: req.params.id },
      orderBy: { createdAt: 'asc' },
      include: {
        sender: { select: { id: true, displayName: true } },
        attachments: true,
      },
    });

    // Mark messages from the other participant as read on fetch — simple
    // read-receipt model, no per-message read events.
    await prisma.message.updateMany({
      where: { conversationId: req.params.id, senderId: { not: req.user!.id }, readAt: null },
      data: { readAt: new Date() },
    });

    res.json({ data: messages });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/conversations/:id/messages
// Attachments: the client uploads images via POST /media/upload first (same
// endpoint listings use), then passes the resulting { url, mimeType } pairs
// here. Attachment has no FK to UploadedFile in the schema — it's a plain
// url/mimeType pair — so this is intentionally loose coupling, not an
// oversight; a message attachment doesn't need the full UploadedFile
// pipeline metadata (hash, moderation result, variants), just a URL to show.
const attachmentSchema = z.object({
  url: z.string().min(1).max(500),
  mimeType: z.string().min(1).max(100),
});

const sendSchema = z
  .object({
    body: z.string().max(2000).default(''),
    attachments: z.array(attachmentSchema).max(5).default([]),
  })
  .refine((v) => v.body.trim().length > 0 || v.attachments.length > 0, {
    message: 'Message must have text or at least one attachment.',
  });

conversationsRouter.post('/:id/messages', async (req: AuthedRequest, res, next) => {
  try {
    await assertParticipant(req.params.id, req.user!.id);
    const { body, attachments } = sendSchema.parse(req.body);

    const message = await prisma.message.create({
      data: {
        conversationId: req.params.id,
        senderId: req.user!.id,
        body,
        attachments: { create: attachments },
      },
      include: {
        sender: { select: { id: true, displayName: true } },
        attachments: true,
      },
    });

    // Bump the conversation for inbox ordering.
    await prisma.conversation.update({
      where: { id: req.params.id },
      data: { updatedAt: new Date() },
    });

    // Notify the other participant. Best-effort: a notification failing to
    // write shouldn't fail message send, so this isn't in the same
    // transaction — acceptable since Notification is informational, not
    // the message itself.
    const otherParticipant = await prisma.conversationParticipant.findFirst({
      where: { conversationId: req.params.id, userId: { not: req.user!.id } },
    });
    if (otherParticipant) {
      const preview = body ? body.slice(0, 100) : `📎 ${attachments.length} photo(s)`;

      await prisma.notification.create({
        data: {
          userId: otherParticipant.userId,
          type: 'message',
          payload: { conversationId: req.params.id, preview },
        },
      });

      // Delivery is separate from the in-app row above and best-effort in
      // the same way — see the honesty note in lib/notifications/channel.ts
      // about what this does and doesn't actually deliver.
      await getNotificationChannel().send({
        userId: otherParticipant.userId,
        subject: 'New message on Maple',
        body: preview,
      });
    }

    res.status(201).json({ data: message });
  } catch (err) {
    next(err);
  }
});
