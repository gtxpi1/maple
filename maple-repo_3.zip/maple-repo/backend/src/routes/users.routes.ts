import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { logAudit } from '../lib/audit';
import { AuthedRequest, requireAdmin, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const usersRouter = Router();

usersRouter.use(requireAuth, requireAdmin);

// GET /api/v1/admin/roles — list available roles (for the role picker).
// Seeded with just "admin" today (see prisma/seed.ts) — this endpoint
// exists so the frontend doesn't hardcode role names, in case more get
// added later without a matching API change.
usersRouter.get('/roles', async (_req, res, next) => {
  try {
    const roles = await prisma.role.findMany({ orderBy: { name: 'asc' } });
    res.json({ data: roles });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/admin/users?marketplaceId=xxx&cursor=&limit=
const listQuerySchema = z.object({
  marketplaceId: z.string().uuid(),
  cursor: z.string().uuid().optional(),
  limit: z.coerce.number().min(1).max(100).default(50),
});

usersRouter.get('/', async (req, res, next) => {
  try {
    const query = listQuerySchema.parse(req.query);

    const users = await prisma.user.findMany({
      where: { marketplaceId: query.marketplaceId, deletedAt: null },
      take: query.limit,
      ...(query.cursor && { cursor: { id: query.cursor }, skip: 1 }),
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        email: true,
        displayName: true,
        createdAt: true,
        trustScore: true,
        userRoles: { include: { role: true } },
      },
    });

    const nextCursor = users.length === query.limit ? users[users.length - 1].id : null;
    res.json({
      data: users.map((u) => ({
        id: u.id,
        email: u.email,
        displayName: u.displayName,
        createdAt: u.createdAt,
        trustScore: u.trustScore,
        roles: u.userRoles.map((ur) => ur.role.name),
      })),
      nextCursor,
    });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/admin/users/:id/roles — grant a role.
const grantSchema = z.object({ roleId: z.string().uuid() });

usersRouter.post('/:id/roles', async (req: AuthedRequest, res, next) => {
  try {
    const body = grantSchema.parse(req.body);

    const [user, role] = await Promise.all([
      prisma.user.findUnique({ where: { id: req.params.id } }),
      prisma.role.findUnique({ where: { id: body.roleId } }),
    ]);
    if (!user) throw new ApiError(404, 'user_not_found', 'User not found.');
    if (!role) throw new ApiError(404, 'role_not_found', 'Role not found.');

    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: user.id, roleId: role.id } },
      update: {},
      create: { userId: user.id, roleId: role.id },
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'role.grant',
      targetType: 'User',
      targetId: user.id,
      metadata: { role: role.name },
    });

    res.status(201).json({ data: { userId: user.id, roleId: role.id } });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/admin/users/:id/roles/:roleId — revoke a role.
//
// Blocks an admin from revoking their own admin role. There's no other way
// to grant admin back (see prisma/seed.ts's comment on this) — a self-
// revocation is very likely a mistake, not an intentional lockout, and the
// only recovery path would be direct database access. This is a narrow,
// specific guard (self + admin role only), not a general "can't revoke the
// last admin" check across the whole marketplace, which would need a
// count query this endpoint doesn't do.
usersRouter.delete('/:id/roles/:roleId', async (req: AuthedRequest, res, next) => {
  try {
    const role = await prisma.role.findUnique({ where: { id: req.params.roleId } });
    if (!role) throw new ApiError(404, 'role_not_found', 'Role not found.');

    if (req.params.id === req.user!.id && role.name === 'admin') {
      throw new ApiError(
        400,
        'cannot_self_revoke_admin',
        "You can't remove your own admin role. Have another admin do it.",
      );
    }

    await prisma.userRole.deleteMany({ where: { userId: req.params.id, roleId: req.params.roleId } });

    await logAudit({
      actorId: req.user!.id,
      action: 'role.revoke',
      targetType: 'User',
      targetId: req.params.id,
      metadata: { role: role.name },
    });

    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
