import { Router } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import {
  DEFAULT_PROMOTION_CATALOG,
  getPromotionType,
  resolvePromotionCatalog,
} from '../lib/payments/promotionCatalog';
import { getPaymentProvider } from '../lib/payments/provider';
import { logAudit } from '../lib/audit';
import { AuthedRequest, requireAdmin, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const promotionsRouter = Router();

// GET /api/v1/promotions/catalog?marketplaceId=xxx — public, powers the
// "Promote this listing" panel. Falls back to the hardcoded defaults if no
// marketplaceId is given or the marketplace has no custom catalog set —
// this keeps the endpoint usable even from contexts that don't have a
// marketplaceId handy yet.
promotionsRouter.get('/catalog', async (req, res, next) => {
  try {
    const marketplaceId = z.string().uuid().optional().parse(req.query.marketplaceId);
    if (!marketplaceId) {
      res.json({ data: DEFAULT_PROMOTION_CATALOG });
      return;
    }

    const marketplace = await prisma.marketplace.findUnique({
      where: { id: marketplaceId },
      select: { configuration: true },
    });
    res.json({ data: resolvePromotionCatalog(marketplace?.configuration) });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/v1/promotions/catalog — admin only. Replaces the marketplace's
// entire custom catalog (see resolvePromotionCatalog's replace-not-merge
// note). Passing an empty array reverts to defaults rather than being
// rejected — an admin might legitimately want to go back to the reference
// pricing.
const catalogItemSchema = z.object({
  id: z.string().min(1).max(40),
  label: z.string().min(1).max(60),
  priceCents: z.number().int().nonnegative(),
  currency: z.string().length(3),
  durationDays: z.number().int().positive(),
  description: z.string().max(200),
});

const updateCatalogSchema = z.object({
  marketplaceId: z.string().uuid(),
  promotions: z.array(catalogItemSchema).max(20),
});

promotionsRouter.patch('/catalog', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = updateCatalogSchema.parse(req.body);

    const marketplace = await prisma.marketplace.findUnique({
      where: { id: body.marketplaceId },
      select: { configuration: true },
    });
    if (!marketplace) {
      throw new ApiError(404, 'marketplace_not_found', 'Marketplace not found.');
    }

    const existingConfig =
      marketplace.configuration && typeof marketplace.configuration === 'object'
        ? (marketplace.configuration as Record<string, unknown>)
        : {};

    const updated = await prisma.marketplace.update({
      where: { id: body.marketplaceId },
      data: {
        configuration: {
          ...existingConfig,
          promotions: body.promotions.length > 0 ? body.promotions : undefined,
        },
      },
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'promotion_catalog.update',
      targetType: 'Marketplace',
      targetId: body.marketplaceId,
      metadata: { promotionTypeIds: body.promotions.map((p) => p.id) },
    });

    res.json({ data: resolvePromotionCatalog(updated.configuration) });
  } catch (err) {
    next(err);
  }
});

const purchaseSchema = z.object({
  listingId: z.string().uuid(),
  promotionType: z.string(),
});

// POST /api/v1/promotions/purchase — requires auth, must own the listing.
//
// Flow: Invoice (open) -> charge via payment provider -> Transaction
// (immutable ledger row, application code only ever INSERTs here) ->
// Invoice marked paid -> ListingPromotion (the actual effect: makes the
// ribbon show up) -> PromotionPurchase (links transaction to listing).
// All in one DB transaction so a failure partway through can't leave a
// paid invoice with no promotion applied, or vice versa.
promotionsRouter.post('/purchase', requireAuth, async (req: AuthedRequest, res, next) => {
  try {
    const body = purchaseSchema.parse(req.body);

    const listing = await prisma.listing.findUnique({ where: { id: body.listingId } });
    if (!listing || listing.deletedAt) {
      throw new ApiError(404, 'listing_not_found', 'Listing not found.');
    }
    if (listing.userId !== req.user!.id) {
      throw new ApiError(403, 'forbidden', 'You can only promote your own listings.');
    }

    // Resolve pricing from the listing's own marketplace, not the global
    // defaults — an admin's custom catalog must be what's actually charged,
    // not just what's displayed.
    const marketplace = await prisma.marketplace.findUnique({
      where: { id: listing.marketplaceId },
      select: { configuration: true },
    });
    const catalog = resolvePromotionCatalog(marketplace?.configuration);
    const promoType = getPromotionType(catalog, body.promotionType);
    if (!promoType) {
      throw new ApiError(400, 'unknown_promotion_type', `No promotion type "${body.promotionType}".`);
    }

    // One PaymentProvider row per provider name — created lazily so the
    // seed script doesn't need to know about every provider that might
    // ever exist.
    const provider = await prisma.paymentProvider.upsert({
      where: { name: getPaymentProvider().name },
      update: {},
      create: { name: getPaymentProvider().name, config: {} },
    });

    const invoice = await prisma.invoice.create({
      data: {
        userId: req.user!.id,
        amount: promoType.priceCents / 100,
        currency: promoType.currency,
        status: 'open',
      },
    });

    const idempotencyKey = crypto.randomUUID();
    const chargeResult = await getPaymentProvider().charge({
      amountCents: promoType.priceCents,
      currency: promoType.currency,
      description: `${promoType.label} — listing ${listing.id}`,
      idempotencyKey,
    });

    if (!chargeResult.success) {
      await prisma.invoice.update({ where: { id: invoice.id }, data: { status: 'void' } });
      throw new ApiError(402, 'payment_failed', chargeResult.failureReason || 'Payment failed.');
    }

    const now = new Date();
    const endAt = new Date(now.getTime() + promoType.durationDays * 24 * 60 * 60 * 1000);

    const result = await prisma.$transaction(async (tx) => {
      const transaction = await tx.transaction.create({
        data: {
          invoiceId: invoice.id,
          paymentProviderId: provider.id,
          amount: promoType.priceCents / 100,
          currency: promoType.currency,
          status: 'succeeded',
          idempotencyKey,
          externalRef: chargeResult.externalRef,
        },
      });

      await tx.invoice.update({ where: { id: invoice.id }, data: { status: 'paid' } });

      const listingPromotion = await tx.listingPromotion.create({
        data: {
          listingId: listing.id,
          promotionType: promoType.id,
          startAt: now,
          endAt,
        },
      });

      await tx.promotionPurchase.create({
        data: {
          userId: req.user!.id,
          listingId: listing.id,
          transactionId: transaction.id,
          promotionType: promoType.id,
        },
      });

      return { transaction, listingPromotion };
    });

    res.status(201).json({
      data: {
        promotion: result.listingPromotion,
        transactionId: result.transaction.id,
        receipt: {
          amount: promoType.priceCents / 100,
          currency: promoType.currency,
          description: promoType.description,
        },
      },
    });
  } catch (err) {
    next(err);
  }
});
