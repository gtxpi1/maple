import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { logAudit } from '../lib/audit';
import { AuthedRequest, requireAdmin, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const categoriesRouter = Router();

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

// GET /api/v1/categories?marketplaceId=xxx
// Public — powers the frontend category strip. Returns only visible,
// non-deleted top-level categories with their subcategories nested,
// ordered by displayOrder. This is what makes the strip "editable in the
// backend": nothing here is hardcoded.
categoriesRouter.get('/', async (req, res, next) => {
  try {
    const marketplaceId = z.string().uuid().parse(req.query.marketplaceId);

    const categories = await prisma.category.findMany({
      where: { marketplaceId, parentId: null, showInNav: true, deletedAt: null },
      orderBy: { displayOrder: 'asc' },
      include: {
        subcategories: {
          where: { showInNav: true, deletedAt: null },
          orderBy: { displayOrder: 'asc' },
        },
      },
    });

    res.json({ data: categories });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/categories/admin?marketplaceId=xxx
// Admin-only — returns everything, including hidden and soft-deleted
// categories, flat (not nested), for the management UI.
categoriesRouter.get('/admin', requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const marketplaceId = z.string().uuid().parse(req.query.marketplaceId);

    const categories = await prisma.category.findMany({
      where: { marketplaceId },
      orderBy: [{ parentId: 'asc' }, { displayOrder: 'asc' }],
    });

    res.json({ data: categories });
  } catch (err) {
    next(err);
  }
});

const createSchema = z.object({
  marketplaceId: z.string().uuid(),
  name: z.string().min(1).max(60),
  slug: z.string().min(1).max(60).optional(),
  parentId: z.string().uuid().optional(),
  icon: z.string().max(8).optional(),
  displayOrder: z.number().int().optional(),
  showInNav: z.boolean().optional(),
});

// POST /api/v1/categories — admin only
categoriesRouter.post('/', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = createSchema.parse(req.body);
    const slug = body.slug ? slugify(body.slug) : slugify(body.name);

    const existing = await prisma.category.findUnique({
      where: { marketplaceId_slug: { marketplaceId: body.marketplaceId, slug } },
    });
    if (existing) {
      throw new ApiError(409, 'slug_taken', `A category with slug "${slug}" already exists.`);
    }

    // Default new categories to the end of the list.
    const maxOrder = await prisma.category.aggregate({
      where: { marketplaceId: body.marketplaceId, parentId: body.parentId ?? null },
      _max: { displayOrder: true },
    });

    const category = await prisma.category.create({
      data: {
        marketplaceId: body.marketplaceId,
        parentId: body.parentId,
        name: body.name,
        slug,
        icon: body.icon,
        displayOrder: body.displayOrder ?? (maxOrder._max.displayOrder ?? -1) + 1,
        showInNav: body.showInNav ?? true,
      },
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'category.create',
      targetType: 'Category',
      targetId: category.id,
      metadata: { name: category.name, slug: category.slug, marketplaceId: body.marketplaceId },
    });

    res.status(201).json({ data: category });
  } catch (err) {
    next(err);
  }
});

const updateSchema = z.object({
  name: z.string().min(1).max(60).optional(),
  slug: z.string().min(1).max(60).optional(),
  icon: z.string().max(8).nullable().optional(),
  displayOrder: z.number().int().optional(),
  showInNav: z.boolean().optional(),
  parentId: z.string().uuid().nullable().optional(),
});

// PATCH /api/v1/categories/:id — admin only
categoriesRouter.patch('/:id', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = updateSchema.parse(req.body);
    const data = { ...body, ...(body.slug && { slug: slugify(body.slug) }) };

    const category = await prisma.category.update({
      where: { id: req.params.id },
      data,
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'category.update',
      targetType: 'Category',
      targetId: category.id,
      metadata: { fields: Object.keys(body) },
    });

    res.json({ data: category });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/categories/reorder — admin only
// Body: { items: [{ id, displayOrder }, ...] }. Bulk update so drag-and-drop
// reordering in the admin UI is one request instead of N.
const reorderSchema = z.object({
  items: z.array(z.object({ id: z.string().uuid(), displayOrder: z.number().int() })).min(1),
});

categoriesRouter.post('/reorder', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = reorderSchema.parse(req.body);

    await prisma.$transaction(
      body.items.map((item) =>
        prisma.category.update({
          where: { id: item.id },
          data: { displayOrder: item.displayOrder },
        }),
      ),
    );

    await logAudit({
      actorId: req.user!.id,
      action: 'category.reorder',
      targetType: 'Category',
      metadata: { itemIds: body.items.map((i) => i.id) },
    });

    res.json({ data: { updated: body.items.length } });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/categories/:id — admin only, soft delete
// NOTE: does not cascade to subcategories — a deleted parent's children
// would become orphaned in the nav tree. Acceptable for now since the
// admin UI blocks deleting a category that still has subcategories;
// revisit if that constraint is lifted.
categoriesRouter.delete('/:id', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const children = await prisma.category.count({
      where: { parentId: req.params.id, deletedAt: null },
    });
    if (children > 0) {
      throw new ApiError(
        409,
        'has_subcategories',
        'Remove or reassign this category\'s subcategories before deleting it.',
      );
    }

    await prisma.category.update({
      where: { id: req.params.id },
      data: { deletedAt: new Date(), showInNav: false },
    });

    await logAudit({
      actorId: req.user!.id,
      action: 'category.delete',
      targetType: 'Category',
      targetId: req.params.id,
    });

    res.status(204).send();
  } catch (err) {
    next(err);
  }
});
