import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { AuthedRequest, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const notificationsRouter = Router();

notificationsRouter.use(requireAuth);

// GET /api/v1/notifications — most recent first, capped at 50.
// No pagination yet: fine for a personal notification feed at this scale,
// revisit with cursor pagination if that stops being true.
notificationsRouter.get('/', async (req: AuthedRequest, res, next) => {
  try {
    const notifications = await prisma.notification.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    const unreadCount = await prisma.notification.count({
      where: { userId: req.user!.id, readAt: null },
    });

    res.json({ data: notifications, unreadCount });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/notifications/:id/read
notificationsRouter.post('/:id/read', async (req: AuthedRequest, res, next) => {
  try {
    const notification = await prisma.notification.findUnique({ where: { id: req.params.id } });
    if (!notification || notification.userId !== req.user!.id) {
      throw new ApiError(404, 'notification_not_found', 'Notification not found.');
    }

    const updated = await prisma.notification.update({
      where: { id: req.params.id },
      data: { readAt: notification.readAt ?? new Date() },
    });

    res.json({ data: updated });
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/notifications/read-all
notificationsRouter.post('/read-all', async (req: AuthedRequest, res, next) => {
  try {
    const result = await prisma.notification.updateMany({
      where: { userId: req.user!.id, readAt: null },
      data: { readAt: new Date() },
    });
    res.json({ data: { updated: result.count } });
  } catch (err) {
    next(err);
  }
});
