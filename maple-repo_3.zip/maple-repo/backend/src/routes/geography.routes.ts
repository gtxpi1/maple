import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';
import { logAudit } from '../lib/audit';
import { AuthedRequest, requireAdmin, requireAuth } from '../middleware/auth';
import { ApiError } from '../middleware/errorHandler';

export const geographyRouter = Router();

// Geography is global reference data, not marketplace-scoped — one set of
// countries/states/cities shared across every marketplace on the platform
// (see docs/03-system-architecture.md: geographic *coverage* is per-tenant
// config, but the geography tree itself isn't duplicated per tenant).
//
// Full Country -> StateProvince -> Region -> City -> Neighborhood
// hierarchy is exposed here — see docs/17-geographic-manager-design.md.

// ---------- Public reads ----------

// GET /api/v1/geography/countries
geographyRouter.get('/countries', async (_req, res, next) => {
  try {
    const countries = await prisma.country.findMany({ orderBy: { name: 'asc' } });
    res.json({ data: countries });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/geography/states?countryId=xxx
geographyRouter.get('/states', async (req, res, next) => {
  try {
    const countryId = z.string().uuid().parse(req.query.countryId);
    const states = await prisma.stateProvince.findMany({
      where: { countryId },
      orderBy: { name: 'asc' },
    });
    res.json({ data: states });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/geography/cities?stateProvinceId=xxx OR ?search=toro
// Powers the post-ad city picker: either browse by state, or type-ahead
// search by name across all cities (search is capped to 20 results).
const citiesQuerySchema = z
  .object({
    stateProvinceId: z.string().uuid().optional(),
    search: z.string().min(1).max(80).optional(),
  })
  .refine((v) => v.stateProvinceId || v.search, {
    message: 'Provide either stateProvinceId or search.',
  });

geographyRouter.get('/cities', async (req, res, next) => {
  try {
    const query = citiesQuerySchema.parse(req.query);

    const cities = await prisma.city.findMany({
      where: {
        ...(query.stateProvinceId && { stateProvinceId: query.stateProvinceId }),
        ...(query.search && { name: { contains: query.search, mode: 'insensitive' } }),
      },
      include: { stateProvince: { include: { country: true } } },
      orderBy: { name: 'asc' },
      take: 20,
    });

    res.json({ data: cities });
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/geography/cities/:id
//
// Added specifically to unblock URL-persisted location filtering on the
// frontend (Home.tsx, SearchResults.tsx) — restoring a displayable City
// object (name, state, country) from a bare cityId in a shared/bookmarked
// URL needed this and didn't have it; only search-by-name and
// list-by-state existed. See docs/17 for the history of this gap.
geographyRouter.get('/cities/:id', async (req, res, next) => {
  try {
    const city = await prisma.city.findUnique({
      where: { id: req.params.id },
      include: { stateProvince: { include: { country: true } } },
    });
    if (!city) {
      throw new ApiError(404, 'city_not_found', 'City not found.');
    }
    res.json({ data: city });
  } catch (err) {
    next(err);
  }
});

// ---------- Region / Neighborhood ----------
// Added after Country/State/City shipped — same pattern, one level deeper.
// Region sits between State and City (optional on City); Neighborhood sits
// under City (optional on Listing). Both now have admin UI
// (frontend/src/pages/AdminGeography.tsx, five-column drill-down).

// GET /api/v1/geography/regions?stateProvinceId=xxx
geographyRouter.get('/regions', async (req, res, next) => {
  try {
    const stateProvinceId = z.string().uuid().parse(req.query.stateProvinceId);
    const regions = await prisma.region.findMany({
      where: { stateProvinceId },
      orderBy: { name: 'asc' },
    });
    res.json({ data: regions });
  } catch (err) {
    next(err);
  }
});

const regionSchema = z.object({
  stateProvinceId: z.string().uuid(),
  name: z.string().min(1).max(80),
});

geographyRouter.post('/regions', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = regionSchema.parse(req.body);
    const region = await prisma.region.create({ data: body });
    await logAudit({
      actorId: req.user!.id,
      action: 'region.create',
      targetType: 'Region',
      targetId: region.id,
      metadata: { name: region.name },
    });
    res.status(201).json({ data: region });
  } catch (err) {
    next(err);
  }
});

geographyRouter.delete(
  '/regions/:id',
  requireAuth,
  requireAdmin,
  async (req: AuthedRequest, res, next) => {
    try {
      const cityCount = await prisma.city.count({ where: { regionId: req.params.id } });
      if (cityCount > 0) {
        throw new ApiError(409, 'has_cities', 'Reassign this region\'s cities before deleting it.');
      }
      await prisma.region.delete({ where: { id: req.params.id } });
      await logAudit({
        actorId: req.user!.id,
        action: 'region.delete',
        targetType: 'Region',
        targetId: req.params.id,
      });
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
);

// GET /api/v1/geography/neighborhoods?cityId=xxx
geographyRouter.get('/neighborhoods', async (req, res, next) => {
  try {
    const cityId = z.string().uuid().parse(req.query.cityId);
    const neighborhoods = await prisma.neighborhood.findMany({
      where: { cityId },
      orderBy: { name: 'asc' },
    });
    res.json({ data: neighborhoods });
  } catch (err) {
    next(err);
  }
});

const neighborhoodSchema = z.object({ cityId: z.string().uuid(), name: z.string().min(1).max(80) });

geographyRouter.post(
  '/neighborhoods',
  requireAuth,
  requireAdmin,
  async (req: AuthedRequest, res, next) => {
    try {
      const body = neighborhoodSchema.parse(req.body);
      const neighborhood = await prisma.neighborhood.create({ data: body });
      await logAudit({
        actorId: req.user!.id,
        action: 'neighborhood.create',
        targetType: 'Neighborhood',
        targetId: neighborhood.id,
        metadata: { name: neighborhood.name },
      });
      res.status(201).json({ data: neighborhood });
    } catch (err) {
      next(err);
    }
  },
);

geographyRouter.delete(
  '/neighborhoods/:id',
  requireAuth,
  requireAdmin,
  async (req: AuthedRequest, res, next) => {
    try {
      const listingCount = await prisma.listing.count({ where: { neighborhoodId: req.params.id } });
      if (listingCount > 0) {
        throw new ApiError(
          409,
          'has_listings',
          'This neighborhood has listings pointing to it and cannot be deleted.',
        );
      }
      await prisma.neighborhood.delete({ where: { id: req.params.id } });
      await logAudit({
        actorId: req.user!.id,
        action: 'neighborhood.delete',
        targetType: 'Neighborhood',
        targetId: req.params.id,
      });
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
);

const countrySchema = z.object({ name: z.string().min(1).max(80), code: z.string().length(2) });

geographyRouter.post('/countries', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = countrySchema.parse(req.body);
    const country = await prisma.country.create({ data: { ...body, code: body.code.toUpperCase() } });
    await logAudit({
      actorId: req.user!.id,
      action: 'country.create',
      targetType: 'Country',
      targetId: country.id,
      metadata: { name: country.name, code: country.code },
    });
    res.status(201).json({ data: country });
  } catch (err) {
    next(err);
  }
});

geographyRouter.delete(
  '/countries/:id',
  requireAuth,
  requireAdmin,
  async (req: AuthedRequest, res, next) => {
    try {
      const stateCount = await prisma.stateProvince.count({ where: { countryId: req.params.id } });
      if (stateCount > 0) {
        throw new ApiError(409, 'has_states', 'Remove this country\'s states before deleting it.');
      }
      await prisma.country.delete({ where: { id: req.params.id } });
      await logAudit({
        actorId: req.user!.id,
        action: 'country.delete',
        targetType: 'Country',
        targetId: req.params.id,
      });
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
);

const stateSchema = z.object({
  countryId: z.string().uuid(),
  name: z.string().min(1).max(80),
  code: z.string().max(10).optional(),
});

geographyRouter.post('/states', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = stateSchema.parse(req.body);
    const state = await prisma.stateProvince.create({ data: body });
    await logAudit({
      actorId: req.user!.id,
      action: 'state.create',
      targetType: 'StateProvince',
      targetId: state.id,
      metadata: { name: state.name },
    });
    res.status(201).json({ data: state });
  } catch (err) {
    next(err);
  }
});

geographyRouter.delete(
  '/states/:id',
  requireAuth,
  requireAdmin,
  async (req: AuthedRequest, res, next) => {
    try {
      const cityCount = await prisma.city.count({ where: { stateProvinceId: req.params.id } });
      if (cityCount > 0) {
        throw new ApiError(409, 'has_cities', 'Remove this state\'s cities before deleting it.');
      }
      await prisma.stateProvince.delete({ where: { id: req.params.id } });
      await logAudit({
        actorId: req.user!.id,
        action: 'state.delete',
        targetType: 'StateProvince',
        targetId: req.params.id,
      });
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
);

const citySchema = z.object({
  stateProvinceId: z.string().uuid(),
  regionId: z.string().uuid().optional(),
  name: z.string().min(1).max(80),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
});

geographyRouter.post('/cities', requireAuth, requireAdmin, async (req: AuthedRequest, res, next) => {
  try {
    const body = citySchema.parse(req.body);
    const city = await prisma.city.create({ data: body });
    await logAudit({
      actorId: req.user!.id,
      action: 'city.create',
      targetType: 'City',
      targetId: city.id,
      metadata: { name: city.name },
    });
    res.status(201).json({ data: city });
  } catch (err) {
    next(err);
  }
});

geographyRouter.delete(
  '/cities/:id',
  requireAuth,
  requireAdmin,
  async (req: AuthedRequest, res, next) => {
    try {
      const listingCount = await prisma.listing.count({ where: { cityId: req.params.id } });
      if (listingCount > 0) {
        throw new ApiError(
          409,
          'has_listings',
          'This city has listings pointing to it and cannot be deleted.',
        );
      }
      await prisma.city.delete({ where: { id: req.params.id } });
      await logAudit({
        actorId: req.user!.id,
        action: 'city.delete',
        targetType: 'City',
        targetId: req.params.id,
      });
      res.status(204).send();
    } catch (err) {
      next(err);
    }
  },
);
