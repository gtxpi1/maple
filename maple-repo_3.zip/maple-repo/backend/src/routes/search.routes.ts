import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma';

export const searchRouter = Router();

// GET /api/v1/search?marketplaceId=xxx&q=bike&categoryId=&cityId=&minPrice=&maxPrice=&cursor=&limit=
//
// Relevance approach: fetch a wider candidate pool via ILIKE (up to 100),
// then score and sort in application code — title matches outrank
// description matches, exact-word matches outrank substring matches. This
// gives real relevance ordering without a raw-SQL tsvector/GIN-index
// migration, which isn't safe to write blind in an environment with no way
// to run `prisma migrate` against a live database and verify it. If listing
// volume grows past what a 100-row candidate scan handles comfortably,
// that's the point to move to Postgres full-text search (tsvector + GIN
// index + ts_rank) or an external engine — this is a deliberately
// lightweight middle step, not the final architecture.
const searchQuerySchema = z.object({
  marketplaceId: z.string().uuid(),
  q: z.string().min(1).max(120),
  categoryId: z.string().uuid().optional(),
  cityId: z.string().uuid().optional(),
  neighborhoodId: z.string().uuid().optional(),
  minPrice: z.coerce.number().nonnegative().optional(),
  maxPrice: z.coerce.number().nonnegative().optional(),
  limit: z.coerce.number().min(1).max(50).default(20),
});

const CANDIDATE_POOL_SIZE = 100;

function scoreListing(title: string, description: string, query: string): number {
  const q = query.toLowerCase().trim();
  const t = title.toLowerCase();
  const d = description.toLowerCase();
  const words = q.split(/\s+/).filter(Boolean);

  let score = 0;
  if (t === q) score += 100;
  if (t.includes(q)) score += 40;
  if (d.includes(q)) score += 10;
  for (const w of words) {
    if (new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(t)) score += 15;
    if (new RegExp(`\\b${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`).test(d)) score += 3;
  }
  return score;
}

searchRouter.get('/', async (req, res, next) => {
  try {
    const query = searchQuerySchema.parse(req.query);

    const candidates = await prisma.listing.findMany({
      where: {
        marketplaceId: query.marketplaceId,
        status: 'ACTIVE',
        deletedAt: null,
        categoryId: query.categoryId,
        cityId: query.cityId,
        neighborhoodId: query.neighborhoodId,
        OR: [
          { title: { contains: query.q, mode: 'insensitive' } },
          { description: { contains: query.q, mode: 'insensitive' } },
        ],
        ...((query.minPrice !== undefined || query.maxPrice !== undefined) && {
          price: {
            ...(query.minPrice !== undefined && { gte: query.minPrice }),
            ...(query.maxPrice !== undefined && { lte: query.maxPrice }),
          },
        }),
      },
      take: CANDIDATE_POOL_SIZE,
      orderBy: { createdAt: 'desc' },
      include: {
        images: {
          take: 1,
          orderBy: { position: 'asc' },
          include: { uploadedFile: { include: { variants: true } } },
        },
        city: true,
        neighborhood: true,
        promotions: { where: { endAt: { gt: new Date() } } },
      },
    });

    const ranked = candidates
      .map((listing) => ({ listing, score: scoreListing(listing.title, listing.description, query.q) }))
      .sort((a, b) => b.score - a.score || b.listing.createdAt.getTime() - a.listing.createdAt.getTime())
      .slice(0, query.limit)
      .map((r) => r.listing);

    res.json({ data: ranked, query: query.q });
  } catch (err) {
    next(err);
  }
});
