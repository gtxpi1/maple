import rateLimit from 'express-rate-limit';
import { Request } from 'express';
import { prisma } from './prisma';

// Rate limiting per docs/07-security-architecture.md. In-memory store
// (express-rate-limit's default) — fine for a single process, but resets
// on restart and doesn't share state across multiple app instances. A
// real multi-instance deployment needs a shared store (Redis, which is
// already a dependency here via ioredis but not wired into this yet — see
// the note in backend/README.md).
//
// Every time a limit actually triggers, this also writes a SecurityEvent
// row (type: 'rate_limit_exceeded') — that table existed in the schema
// since the first commit with nothing ever writing to it; this is what
// finally closes that gap (see docs/00-INDEX.md's audit-round notes).

async function logRateLimitEvent(req: Request): Promise<void> {
  try {
    await prisma.securityEvent.create({
      data: {
        type: 'rate_limit_exceeded',
        severity: 'medium',
        metadata: {
          path: req.path,
          method: req.method,
          ip: req.ip,
        },
      },
    });
  } catch {
    // Logging the rate-limit event should never be why a request fails —
    // swallow and let the 429 response still go out below.
  }
}

// Strict: auth endpoints. Brute-force/credential-stuffing is the specific
// threat here, so this is tighter than general API traffic.
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: async (req, res) => {
    await logRateLimitEvent(req);
    res.status(429).json({
      error: { code: 'rate_limited', message: 'Too many attempts. Try again later.' },
    });
  },
});

// Moderate: media upload. Sized (and CPU-bound via sharp) requests are
// more expensive per-request than a typical API call, so this sits
// between the strict auth limiter and the loose general one.
export const uploadRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  handler: async (req, res) => {
    await logRateLimitEvent(req);
    res.status(429).json({
      error: { code: 'rate_limited', message: 'Too many uploads. Try again later.' },
    });
  },
});

// Loose: everything else. A generous ceiling meant to catch runaway
// clients/scripts, not to throttle normal browsing.
export const generalRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false,
  handler: async (req, res) => {
    await logRateLimitEvent(req);
    res.status(429).json({
      error: { code: 'rate_limited', message: 'Too many requests. Slow down.' },
    });
  },
});
