import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { ApiError } from './errorHandler';

export interface AuthedRequest extends Request {
  user?: { id: string; marketplaceId: string; roles: string[] };
}

// Verifies a JWT from the Authorization header and attaches the user to the request.
// Roles are baked into the token at login time (see auth.routes.ts signToken) —
// a role change won't take effect until the user's next login. That's an
// accepted tradeoff for now to avoid a DB round-trip on every request; revisit
// if role changes need to apply immediately (e.g. via a DB-backed session check).
export function requireAuth(req: AuthedRequest, _res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    throw new ApiError(401, 'unauthorized', 'Missing or invalid Authorization header.');
  }

  const token = header.slice('Bearer '.length);

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET as string) as {
      sub: string;
      marketplaceId: string;
      roles?: string[];
    };
    req.user = {
      id: payload.sub,
      marketplaceId: payload.marketplaceId,
      roles: payload.roles ?? [],
    };
    next();
  } catch {
    throw new ApiError(401, 'unauthorized', 'Invalid or expired token.');
  }
}

// Chain after requireAuth. Coarse-grained for now (role name check only) —
// see docs/04's Roles/Permissions tables for the finer-grained model this
// should grow into once the admin panel needs more than one gate.
export function requireAdmin(req: AuthedRequest, _res: Response, next: NextFunction): void {
  if (!req.user?.roles.includes('admin')) {
    throw new ApiError(403, 'forbidden', 'Admin role required for this action.');
  }
  next();
}
