import { PrismaClient } from '@prisma/client';

// Single shared Prisma client instance.
// In dev, ts-node-dev hot-reloads and can spawn multiple clients against the
// same connection pool — guard with a global to avoid exhausting Postgres
// connections locally.

declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma =
  global.__prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV === 'development') {
  global.__prisma = prisma;
}
