// Notification *delivery* abstraction — distinct from the in-app
// Notification table (backend/src/routes/notifications.routes.ts), which
// already works: rows are created and read back by the frontend bell.
// This layer is about pushing a notification somewhere the user doesn't
// have the app open — email, SMS, web push.
//
// HONEST LIMITATION: no channel here actually delivers anything external.
// This environment has no network access and no SMTP/SES/Twilio/web-push
// credentials, so there's nothing real to wire up and no way to verify it
// worked even if there were. ConsoleChannel logs what *would* have been
// sent, in the shape a real channel would need, so the call sites
// (conversations.routes.ts today) are already written against the
// interface a real implementation would fulfill — swapping one in later
// doesn't touch calling code.

export interface DeliveryPayload {
  userId: string;
  subject: string;
  body: string;
}

export interface NotificationChannel {
  name: string;
  send(payload: DeliveryPayload): Promise<void>;
}

export class ConsoleChannel implements NotificationChannel {
  name = 'console';

  async send(payload: DeliveryPayload): Promise<void> {
    // Deliberately just a log line, not a queue write or retry logic — a
    // real channel (email/SMS/push) would need at minimum retry-on-failure
    // and a way to look up the user's actual address/device token, neither
    // of which exists yet (User has no verified-email-for-notifications
    // flag, no push-token storage).
    console.log(`[notification:${this.name}] to user ${payload.userId}: ${payload.subject}`);
  }
}

export function getNotificationChannel(): NotificationChannel {
  return new ConsoleChannel();
}
