import sharp from 'sharp';

export interface WatermarkConfig {
  enabled: boolean;
  text: string;
  opacity: number; // 0-1
}

const DEFAULT_CONFIG: WatermarkConfig = { enabled: true, text: 'MAPLE', opacity: 0.35 };

// Reads watermark settings from Marketplace.configuration (a free-form JSON
// column — see docs/18, still a stub doc for the general config-versioning
// mechanism). Shape: { watermark?: { enabled?: boolean, text?: string, opacity?: number } }
// Falls back to sane defaults so marketplaces that haven't configured
// anything still get a watermark rather than silently skipping it.
export function resolveWatermarkConfig(marketplaceConfiguration: unknown): WatermarkConfig {
  const raw =
    marketplaceConfiguration &&
    typeof marketplaceConfiguration === 'object' &&
    'watermark' in marketplaceConfiguration
      ? (marketplaceConfiguration as { watermark?: Partial<WatermarkConfig> }).watermark
      : undefined;

  return {
    enabled: raw?.enabled ?? DEFAULT_CONFIG.enabled,
    text: raw?.text || DEFAULT_CONFIG.text,
    opacity: raw?.opacity ?? DEFAULT_CONFIG.opacity,
  };
}

// Overlays a diagonal, repeated text watermark across the image.
// Text-based (not a logo image) so it works out of the box with zero
// per-marketplace asset upload — swap in an image-composite path per
// marketplace if/when branded logo watermarks are prioritized.
export async function applyWatermark(buffer: Buffer, config: WatermarkConfig): Promise<Buffer> {
  const image = sharp(buffer);
  const metadata = await image.metadata();
  const width = metadata.width ?? 800;
  const height = metadata.height ?? 600;

  const fontSize = Math.max(18, Math.round(width / 22));
  const tileW = fontSize * config.text.length * 0.7;
  const tileH = fontSize * 4;

  // Tiled SVG overlay so the watermark survives cropping and can't be
  // trivially cloned/inpainted out of one corner.
  const cols = Math.ceil(width / tileW) + 1;
  const rows = Math.ceil(height / tileH) + 1;

  let textElements = '';
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = c * tileW;
      const y = r * tileH + fontSize;
      textElements += `<text x="${x}" y="${y}" font-family="sans-serif" font-size="${fontSize}" fill="white" fill-opacity="${config.opacity}" transform="rotate(-30 ${x} ${y})">${escapeXml(config.text)}</text>`;
    }
  }

  const svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">${textElements}</svg>`;

  return image.composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).jpeg({ quality: 82 }).toBuffer();
}

function escapeXml(text: string): string {
  return text.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<':
        return '&lt;';
      case '>':
        return '&gt;';
      case '&':
        return '&amp;';
      case "'":
        return '&apos;';
      case '"':
        return '&quot;';
      default:
        return c;
    }
  });
}
