import { authenticator } from 'otplib';
import QRCode from 'qrcode';

// TOTP-based MFA (RFC 6238) — the one security control in docs/07 that's
// fully implementable without any external service or network call. Unlike
// OAuth (needs a real provider's client ID/secret), CAPTCHA (needs a real
// site key), or the payment/notification/moderation providers elsewhere in
// this codebase, TOTP generation and verification are pure local
// cryptography — an authenticator app (Google Authenticator, 1Password,
// etc.) computes the same codes offline, so there's nothing to stub here.

const ISSUER = 'Maple';

export function generateSecret(): string {
  return authenticator.generateSecret();
}

export function getOtpAuthUrl(email: string, secret: string): string {
  return authenticator.keyuri(email, ISSUER, secret);
}

export async function getQrCodeDataUrl(otpAuthUrl: string): Promise<string> {
  return QRCode.toDataURL(otpAuthUrl);
}

export function verifyToken(token: string, secret: string): boolean {
  try {
    return authenticator.verify({ token, secret });
  } catch {
    // otplib throws on a malformed token (wrong length, non-numeric)
    // rather than returning false — treat that the same as "invalid code"
    // instead of letting it bubble up as a 500.
    return false;
  }
}
