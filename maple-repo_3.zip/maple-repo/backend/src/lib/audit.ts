import { prisma } from './prisma';

// Thin wrapper around AuditLog.create. Kept deliberately dumb (no batching,
// no async queue) — this is a data-collection layer, not an observability
// pipeline. Originally wired into only listing approve/reject and role
// grant/revoke; now covers most admin mutations — categories (create/
// update/delete/reorder), geography (create/delete at all five levels),
// promotion catalog updates, and transaction refunds. Still not wired into
// listing edits (owner-initiated, not admin) or media/watermark config
// changes.
export async function logAudit(params: {
  actorId: string;
  action: string;
  targetType: string;
  targetId?: string;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await prisma.auditLog.create({
    data: {
      actorId: params.actorId,
      action: params.action,
      targetType: params.targetType,
      targetId: params.targetId,
      metadata: params.metadata ?? {},
    },
  });
}
