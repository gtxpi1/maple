// Promotion catalog, now marketplace-configurable — follows the exact
// pattern established by resolveWatermarkConfig in lib/watermark.ts:
// defaults baked in here, optionally overridden per marketplace via
// Marketplace.configuration.promotions (same JSON blob docs/18 still owes
// a real config-versioning mechanism for; this is one more concrete
// consumer of it in the meantime, same as watermark settings).

export interface PromotionTypeConfig {
  id: string;
  label: string;
  priceCents: number;
  currency: string;
  durationDays: number;
  description: string;
}

export const DEFAULT_PROMOTION_CATALOG: PromotionTypeConfig[] = [
  {
    id: 'featured',
    label: 'Featured',
    priceCents: 500,
    currency: 'USD',
    durationDays: 7,
    description: 'Highlighted with a FEATURED ribbon for 7 days.',
  },
  {
    id: 'bump',
    label: 'Bump to top',
    priceCents: 100,
    currency: 'USD',
    durationDays: 1,
    description: 'Moves your listing to the top of category results for 24 hours.',
  },
];

// A marketplace's configuration.promotions, if present, *replaces* the
// defaults entirely rather than merging field-by-field — an admin editing
// their catalog is expected to see and save the whole list, not patch
// individual fields blind. If configuration.promotions is absent or
// malformed, defaults are used untouched.
export function resolvePromotionCatalog(marketplaceConfiguration: unknown): PromotionTypeConfig[] {
  const raw =
    marketplaceConfiguration &&
    typeof marketplaceConfiguration === 'object' &&
    'promotions' in marketplaceConfiguration
      ? (marketplaceConfiguration as { promotions?: unknown }).promotions
      : undefined;

  if (Array.isArray(raw) && raw.length > 0 && raw.every(isValidPromotionType)) {
    return raw as PromotionTypeConfig[];
  }
  return DEFAULT_PROMOTION_CATALOG;
}

function isValidPromotionType(v: unknown): v is PromotionTypeConfig {
  if (!v || typeof v !== 'object') return false;
  const p = v as Record<string, unknown>;
  return (
    typeof p.id === 'string' &&
    typeof p.label === 'string' &&
    typeof p.priceCents === 'number' &&
    typeof p.currency === 'string' &&
    typeof p.durationDays === 'number' &&
    typeof p.description === 'string'
  );
}

export function getPromotionType(
  catalog: PromotionTypeConfig[],
  id: string,
): PromotionTypeConfig | undefined {
  return catalog.find((p) => p.id === id);
}
