// Payment provider abstraction — see docs/14-payment-engine-design.md.
// Providers plug in behind this interface; nothing above it (routes) should
// know which one is active.
//
// HONEST LIMITATION: this environment has no network access and no real
// Stripe/payment-processor credentials, so there is no real card-charging
// provider implemented here — only MockPaymentProvider, which always
// succeeds. Wiring a real provider means implementing this interface
// against Stripe's SDK (or another processor) and swapping it in at
// `getPaymentProvider()` below; the routes that call it don't need to change.

export interface ChargeRequest {
  amountCents: number;
  currency: string;
  description: string;
  idempotencyKey: string;
}

export interface ChargeResult {
  success: boolean;
  externalRef: string;
  failureReason?: string;
}

export interface RefundRequest {
  originalExternalRef: string;
  amountCents: number;
  reason?: string;
}

export interface RefundResult {
  success: boolean;
  externalRef: string;
  failureReason?: string;
}

export interface PaymentProviderClient {
  name: string;
  charge(req: ChargeRequest): Promise<ChargeResult>;
  refund(req: RefundRequest): Promise<RefundResult>;
}

export class MockPaymentProvider implements PaymentProviderClient {
  name = 'mock';

  async charge(req: ChargeRequest): Promise<ChargeResult> {
    // Always succeeds, synchronously, no network call. This is a stand-in
    // so the rest of the payment flow (invoice -> transaction -> ledger)
    // can be built and exercised end-to-end without real payment
    // infrastructure. It is NOT a payment gateway — do not point this at
    // real money.
    return {
      success: true,
      externalRef: `mock_${req.idempotencyKey}`,
    };
  }

  async refund(req: RefundRequest): Promise<RefundResult> {
    // Same honesty as charge() above — always succeeds, no real money moves.
    return {
      success: true,
      externalRef: `mock_refund_${req.originalExternalRef}`,
    };
  }
}

export function getPaymentProvider(): PaymentProviderClient {
  return new MockPaymentProvider();
}
