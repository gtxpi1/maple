import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

// Local-disk storage for development. Swap this module for an S3/object-storage
// implementation in production — nothing outside this file should know where
// bytes physically live (see docs/03-system-architecture.md — Storage).

const UPLOAD_ROOT = path.join(__dirname, '../../uploads');

export interface StoredFile {
  relativePath: string; // stored on UploadedFile.originalUrl
  absolutePath: string; // used internally for further processing (thumbnails, etc.)
}

export async function saveBuffer(buffer: Buffer, extension: string): Promise<StoredFile> {
  const filename = `${crypto.randomUUID()}${extension}`;
  const absolutePath = path.join(UPLOAD_ROOT, filename);
  await fs.writeFile(absolutePath, buffer);
  return { relativePath: `/uploads/${filename}`, absolutePath };
}

export function publicUrl(relativePath: string): string {
  const base = process.env.PUBLIC_ASSET_BASE_URL || 'http://localhost:4000';
  return `${base}${relativePath}`;
}
