// CAPTCHA provider abstraction — same honest-stub pattern as
// lib/payments/provider.ts, lib/notifications/channel.ts, and
// lib/moderation/provider.ts. A real CAPTCHA (reCAPTCHA, hCaptcha, Turnstile)
// needs a site key/secret from that provider and a network call to verify
// the token server-side — neither exists in this sandbox. StubCaptchaProvider
// always passes, so the endpoints that call it (signup) are already wired
// against the interface a real provider would need to satisfy; swapping one
// in is a new class plus a one-line change to getCaptchaProvider(), not a
// rewrite of the routes.

export interface CaptchaVerifyResult {
  success: boolean;
  failureReason?: string;
}

export interface CaptchaProvider {
  name: string;
  verify(token: string | undefined): Promise<CaptchaVerifyResult>;
}

export class StubCaptchaProvider implements CaptchaProvider {
  name = 'stub';

  async verify(_token: string | undefined): Promise<CaptchaVerifyResult> {
    // Always succeeds — this provides zero actual bot protection. It
    // exists so the signup flow demonstrates where a real check would go,
    // not to imply signup is protected against automated abuse today.
    return { success: true };
  }
}

export function getCaptchaProvider(): CaptchaProvider {
  return new StubCaptchaProvider();
}
