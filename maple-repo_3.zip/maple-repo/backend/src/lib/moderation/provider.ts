// AI moderation provider abstraction — see docs/15-ai-operations-design.md
// ("Provider abstraction API"). Previously this was an inline stub object
// literal written directly in media.routes.ts; pulling it out here doesn't
// change behavior, but means a real provider (calling Anthropic, OpenAI's
// moderation endpoint, AWS Rekognition, etc.) is a new class implementing
// this interface plus a one-line change to getModerationProvider(), not a
// rewrite of the upload route.
//
// HONEST LIMITATION: no real provider is implemented. This environment has
// no network access, so calling any external moderation API — which is the
// entire point of AI moderation — isn't something that could be built and
// verified here. StubModerationProvider does a few cheap local checks
// (image dimensions) that need no network call, then always reports
// not-flagged. It is not a substitute for real content moderation.

export interface ModerationResult {
  flagged: boolean;
  categories: string[];
  raw: Record<string, unknown>;
}

export interface ModerationProvider {
  name: string;
  moderate(imageBuffer: Buffer, metadata: { width: number; height: number }): Promise<ModerationResult>;
}

export class StubModerationProvider implements ModerationProvider {
  name = 'stub';

  async moderate(
    _imageBuffer: Buffer,
    metadata: { width: number; height: number },
  ): Promise<ModerationResult> {
    // The one real (if minor) check this can do without a network call:
    // reject images too small to plausibly show anything useful, which is
    // a spam/low-effort-listing signal more than a safety one. Not a
    // stand-in for actual content moderation.
    const tooSmall = metadata.width < 50 || metadata.height < 50;

    return {
      flagged: tooSmall,
      categories: tooSmall ? ['low_quality'] : [],
      raw: {
        note: 'stub provider — no real moderation performed, see lib/moderation/provider.ts',
        provider: this.name,
      },
    };
  }
}

export function getModerationProvider(): ModerationProvider {
  return new StubModerationProvider();
}
