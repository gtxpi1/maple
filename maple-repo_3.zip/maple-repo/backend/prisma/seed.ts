import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

// Minimal seed to get a local dev environment usable end-to-end.
async function main() {
  const marketplace = await prisma.marketplace.upsert({
    where: { slug: 'maple-demo' },
    update: {},
    create: {
      name: 'Maple Demo',
      slug: 'maple-demo',
      branding: { primaryColor: '#E8402C' },
      configuration: { watermark: { enabled: true, text: 'MAPLE DEMO', opacity: 0.3 } },
    },
  });

  const country = await prisma.country.upsert({
    where: { code: 'CA' },
    update: {},
    create: { name: 'Canada', code: 'CA' },
  });

  let ontario = await prisma.stateProvince.findFirst({
    where: { countryId: country.id, name: 'Ontario' },
  });
  if (!ontario) {
    ontario = await prisma.stateProvince.create({
      data: { countryId: country.id, name: 'Ontario', code: 'ON' },
    });
  }

  async function findOrCreateCity(data: {
    stateProvinceId: string;
    name: string;
    latitude: number;
    longitude: number;
  }) {
    const existing = await prisma.city.findFirst({
      where: { name: data.name, stateProvinceId: data.stateProvinceId },
    });
    return existing ?? prisma.city.create({ data });
  }

  const toronto = await findOrCreateCity({
    stateProvinceId: ontario.id,
    name: 'Toronto',
    latitude: 43.6532,
    longitude: -79.3832,
  });

  const ottawa = await findOrCreateCity({
    stateProvinceId: ontario.id,
    name: 'Ottawa',
    latitude: 45.4215,
    longitude: -75.6972,
  });

  // --- Admin role + user ---
  // There's no fully self-serve "sign up and become admin" flow (by design
  // — see docs/07-security-architecture.md). This seeded account is the
  // required first admin; from here, use /admin/users to grant the admin
  // role to other accounts.
  const adminRole = await prisma.role.upsert({
    where: { name: 'admin' },
    update: {},
    create: { name: 'admin', description: 'Full marketplace administration access' },
  });

  const adminPasswordHash = await bcrypt.hash('AdminPass123!', 12);
  const admin = await prisma.user.upsert({
    where: { marketplaceId_email: { marketplaceId: marketplace.id, email: 'admin@maple.demo' } },
    update: {},
    create: {
      marketplaceId: marketplace.id,
      email: 'admin@maple.demo',
      passwordHash: adminPasswordHash,
      displayName: 'Maple Admin',
    },
  });

  await prisma.userRole.upsert({
    where: { userId_roleId: { userId: admin.id, roleId: adminRole.id } },
    update: {},
    create: { userId: admin.id, roleId: adminRole.id },
  });

  // --- Category tree ---
  // Matches mockups/homepage.html's category strip, but now this is the
  // actual source of truth — edit these rows (via the admin UI once it
  // exists, or directly) and the frontend strip changes with no code change.
  const topLevel = [
    { name: 'For Sale', icon: '🛍️' },
    { name: 'Housing', icon: '🏠' },
    { name: 'Jobs', icon: '💼' },
    { name: 'Services', icon: '🔧' },
    { name: 'Vehicles', icon: '🚗' },
    { name: 'Electronics', icon: '📱' },
    { name: 'Free Stuff', icon: '🎁' },
    { name: 'Community', icon: '👥' },
  ];

  const createdCategories: Record<string, { id: string; slug: string }> = {};
  for (let i = 0; i < topLevel.length; i++) {
    const cat = topLevel[i];
    const slug = cat.name.toLowerCase().replace(/\s+/g, '-');
    const created = await prisma.category.upsert({
      where: { marketplaceId_slug: { marketplaceId: marketplace.id, slug } },
      update: {},
      create: {
        marketplaceId: marketplace.id,
        name: cat.name,
        slug,
        icon: cat.icon,
        displayOrder: i,
      },
    });
    createdCategories[cat.name] = { id: created.id, slug: created.slug };
  }

  // A couple of subcategories to prove the tree actually nests.
  await prisma.category.upsert({
    where: { marketplaceId_slug: { marketplaceId: marketplace.id, slug: 'bikes-scooters' } },
    update: {},
    create: {
      marketplaceId: marketplace.id,
      parentId: createdCategories['For Sale'].id,
      name: 'Bikes & Scooters',
      slug: 'bikes-scooters',
      displayOrder: 0,
    },
  });

  await prisma.category.upsert({
    where: { marketplaceId_slug: { marketplaceId: marketplace.id, slug: 'apartments' } },
    update: {},
    create: {
      marketplaceId: marketplace.id,
      parentId: createdCategories['Housing'].id,
      name: 'Apartments',
      slug: 'apartments',
      displayOrder: 0,
    },
  });

  console.log('Seeded:');
  console.log('  marketplaceId:', marketplace.id, '(put this in frontend/.env as VITE_MARKETPLACE_ID)');
  console.log('  cities: Toronto, Ottawa — pick from the dropdown on the post-ad form now, no need to paste an id');
  console.log('  categoryId (Bikes & Scooters):', createdCategories['For Sale'].id, '/bikes-scooters');
  console.log('  admin login: admin@maple.demo / AdminPass123!');
  console.log('  promotions: purchase via POST /promotions/purchase (mock payment provider, no real charge)');
  console.log('  promotion pricing: admin-editable at /admin/promotions (defaults until customized)');
  void toronto;
  void ottawa; // referenced for seeding side-effects; logging is a summary, not per-id
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
