# 17 — Geographic Manager Design (v0.7 — location filter now URL-persisted)

## Status

Full Country → State/Province → Region → City → Neighborhood hierarchy has
both an API and an admin UI (`/admin/geography`, five columns: Country,
State, Region, City, Neighborhood). Region is assignable when creating a
city. Neighborhood is wired into listings (post-ad field, server-side
validation, filterable) and has a browse-time filter — `Home.tsx` and
`SearchResults.tsx` both show a city picker + neighborhood dropdown above
the listing grid, and that filter is now URL-persisted (`?city=`,
`?neighborhood=`), same as the category filter.

## What exists

- Public reads/admin writes at every level, including Region.
- Admin UI: five-column drill-down.
- Neighborhood on listings: post-ad field, server-validated, filterable via
  `GET /listings` and `GET /search`, and filterable from the storefront
  itself (Home, Search) via a `CityPicker` + neighborhood `<select>`.
- `GET /geography/cities/:id` — added specifically to unblock URL
  persistence: restoring a bare `cityId` from a shared/bookmarked/refreshed
  URL into a displayable `City` (name, state, country) needed this and
  didn't have it before.
- Geography is global reference data, shared across all marketplaces.

## Still not defined

- **Region has no consumer beyond city assignment.** Nothing reads a
  city's `regionId` for filtering or display — it's purely organizational
  at this point.
- **Bulk import** — still one row at a time through the API/UI.
- **Per-marketplace geographic scoping** — Architecture (03) describes
  "geographic coverage" as configurable per marketplace; nothing enforces
  or exposes that yet. Every marketplace sees the same full city list.
- **Radius/"near me" search** — still undefined; only exact-match
  filtering exists (`cityId`, `neighborhoodId`).
