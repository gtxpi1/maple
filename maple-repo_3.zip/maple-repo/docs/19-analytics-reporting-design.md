# 19 — Analytics & Reporting Design (v0.3 — two slices implemented, three domains untouched)

## Status

Two of the five metric domains named below now have real implementations:
Revenue Metrics (`GET /admin/finance/summary`, see docs/14) and a slice of
Site Metrics + User Metrics (`GET /admin/analytics/overview` — listing
counts by status, category count, 30-day signup trend, at `/admin/analytics`).
Category Metrics and Geographic Metrics have no implementation at all.

## Why this doc still partly needs writing

Referenced by:
- Blueprint (02): Revenue, countries, cities, user growth, category
  popularity, ad performance, marketing effectiveness, system health,
  security alerts
- Database Design (04): `Site Metrics`, `Revenue Metrics`, `Category
  Metrics`, `Geographic Metrics`, `User Metrics`
- Admin Panel (06): "Analytics" module
- API Spec (05): "Analytics API" section

## Needs to define

- Metrics pipeline (real-time vs. batch/aggregated) — both implemented
  slices compute on-demand from live tables (fetch, reduce in JS), which
  won't scale indefinitely without a real decision here — see the comment
  in `analytics.routes.ts`/`finance.routes.ts` for the specific tradeoff.
- Data retention policy
- Dashboard structure in Admin Panel beyond two separate pages
  (`/admin/finance`, `/admin/analytics`) — no unified admin dashboard home.
- Relationship to AI Operations (15) "business analytics" responsibility
- Category Metrics, Geographic Metrics — neither started. (Category
  popularity and geographic breakdowns are both listed in the Blueprint but
  have no query, no endpoint, no UI.)
