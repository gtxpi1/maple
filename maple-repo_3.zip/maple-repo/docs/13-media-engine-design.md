# 13 — Media Engine Design (v0.2 — mostly implemented)

## Pipeline

Upload → Validate → Optimize → Strip metadata → Generate thumbnails →
Watermark (medium size only, configurable per marketplace) → Store

Implemented in `backend/src/routes/media.routes.ts` and
`backend/src/lib/watermark.ts`.

## Features

- Multiple sizes — done (`thumbnail` 200px, `medium` 800px)
- Duplicate detection — done, but exact-hash only (SHA-256), not perceptual
  — a re-compressed re-upload of the same photo won't be caught
- Image hashing — see above; perceptual hashing (e.g. phash) not implemented
- AI moderation — the provider is still a stub (`StubModerationProvider`,
  see `lib/moderation/provider.ts`), but as of the moderation-queue commit
  its results are now actually surfaced to an admin at `/admin/moderation`
  (a flagged photo shows a warning on the pending listing) instead of
  being written to the database and never read anywhere.
- Configurable watermarking — done. Per-marketplace via
  `Marketplace.configuration.watermark: { enabled, text, opacity }`.
  Text-tiled only — no per-marketplace logo image compositing, no
  position/placement options beyond the tiled default.

