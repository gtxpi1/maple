# 11 — Testing Strategy (v0.2 — CI exists, actual tests don't yet)

## Test Types

Unit · Integration · End-to-end · Load · Security · Regression

## CI

`.github/workflows/ci.yml` runs on every push/PR to `main`: installs both
`backend/` and `frontend/`, lints, generates the Prisma client, pushes the
schema to a real Postgres service container, builds both, and smoke-tests
the backend by booting it and hitting `/api/v1/health`.

**What this catches:** compile errors, lint violations, a schema that
doesn't actually apply to Postgres, a server that crashes on startup.
**What this doesn't catch:** almost everything else — there are no unit or
integration tests in this repo yet. The CI pipeline is real infrastructure
with nothing running through it beyond the smoke test.

**Known gap:** no `package-lock.json` is committed for either `backend/` or
`frontend/` — this repo was built in a sandbox with no network access to
run `npm install`. Run it once locally, commit the resulting lockfiles, and
CI can switch from `npm install` to `npm ci` (faster, reproducible) and
enable dependency caching in `actions/setup-node`.

Coverage targets not yet defined. No test files exist for any of the routes
built so far (auth, listings, media, categories, geography, search,
conversations, notifications) — that's the actual next step for this doc,
not CI plumbing.
