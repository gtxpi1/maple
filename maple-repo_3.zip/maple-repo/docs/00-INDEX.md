# Project Maple — Design Library (Reorganized v0.2)

Master index for all design, architecture, and development documentation.
Reorganized from source docs on 2026-08-07 so the set can drive implementation.

| # | Document | Status | Source |
|---|----------|--------|--------|
| 01 | Vision & Mission | Drafted (from Blueprint) | blueprint.txt |
| 02 | Master Blueprint | Complete | blueprint.txt |
| 03 | System Architecture | Complete | architecture.txt |
| 04 | Database Design | Complete | maple_database_design.txt |
| 05 | API Specification | Complete | maple_api_specification.txt |
| 06 | Admin Panel Design | 7 of 17 modules implemented | AdminModeration.tsx |
| 07 | Security Architecture | Most application-layer controls implemented | rateLimit.ts, mfa.ts |
| 08 | UI/UX Design Guide | Complete | maple_ui_ux_design.txt |
| 09 | Development Standards | Complete | maple_development_standards.txt |
| 10 | Deployment Guide | Complete | maple_deployment_guide.txt |
| 11 | Testing Strategy | CI exists, no actual tests yet | .github/workflows/ci.yml |
| 12 | Plugin Architecture | **Not yet written** | — |
| 13 | Media Engine Design | Complete | maple_media_engine_design.txt |
| 14 | Payment Engine Design | Ledger, refunds, admin financial reporting implemented, mock provider only | payments/provider.ts, finance.routes.ts |
| 15 | AI Operations Design | Complete | maple_ai_operations_design.txt |
| 16 | Promotion Engine Design | Admin-configurable pricing | promotions.routes.ts, AdminPromotions.tsx |
| 17 | Geographic Manager Design | Full API + admin UI; browse filter is URL-persisted | geography.routes.ts, Home.tsx |
| 18 | Configuration Manager Design | **Not yet written** | — |
| 19 | Analytics & Reporting Design | Revenue + Site/User slices done; Category, Geographic not started | finance.routes.ts, analytics.routes.ts |
| 20 | Product Roadmap | **Not yet written** | — |

## What Changed in This Pass

- Merged duplicate content between `blueprint.txt` and `architecture.txt` — Blueprint now owns vision/stack/features, Architecture now owns components/data flow/scaling.
- Every "Planned" status from the old library that had a corresponding source file is now marked **Complete** and expanded into full sections (Purpose, Scope, Detail, Open Questions).
- Five documents referenced in the original index (12, 16–20) still have no source content. These are the actual gaps before a full build can start — see each stub file for what's needed.
- Added a **Build Readiness** section at the bottom of this index.

## Reading Order for Implementation

1. Vision & Blueprint (01–02) — what we're building and why
2. System Architecture (03) — component map
3. Database Design (04) — schema foundation everything else depends on
4. API Specification (05) — contract between frontend/backend
5. Security Architecture (07) + Development Standards (09) — non-negotiables baked in from commit #1
6. Domain engines (13–15, and the missing 12/16–18) — feature-by-feature build order
7. Admin Panel (06) + UI/UX (08) — surfaces
8. Testing (11) + Deployment (10) — how it ships

## Build Readiness

**Done:** `backend/` (Prisma schema, auth with role claims, listings, media
upload with configurable watermarking per docs/13, Categories CRUD/reorder,
full Geography hierarchy CRUD [Country through Neighborhood], ranked
search, buyer/seller messaging, in-app notifications, promotions with a
real ledger flow behind a mock payment provider) and `frontend/` (React/Vite
app: signup, login, browse with live category filtering, listing detail
with real "Message seller" and "Promote this listing", post-ad with photo
upload + category + city pickers, working header search, `/messages` inbox
+ thread, notification bell, `/admin/categories`, `/admin/geography`) — the
full v1.0 loop plus real admin/user/monetization workflows run end-to-end
locally, and the post-ad form has zero raw UUID inputs. CI now runs on
every push (`.github/workflows/ci.yml`). See `backend/README.md` and
`frontend/README.md`.

**Bugs/gaps fixed this pass (third audit round):** three more schema
tables (`SavedListing`, `LoginHistory`, `AuditLog`) had existed since
early commits with zero code ever reading or writing them — same pattern
as the two `Listing`-status bugs above, found the same way (checking
whether every table/enum value the schema defines is ever actually
reached). `SavedListing` now has a full favorite/unfavorite feature
(`/saved` page). `LoginHistory` and `AuditLog` are now written to on the
highest-value events (every login attempt; listing approve/reject and
role grant/revoke respectively) but don't have dedicated admin viewer
pages yet — data collection without a UI, an intentional scope cut for
this pass. `SecurityEvent` remains the one fully-dormant table left,
documented as such rather than silently ignored — it has no obvious call
site since the features it would record (rate limiting, CAPTCHA) don't
exist yet either.

**Bugs fixed in earlier passes:** every listing was created
`PENDING_REVIEW` with no way to ever become `ACTIVE` (fixed via
`/admin/moderation`); there was no way to edit, mark sold, or delete a
listing at all, by anyone (fixed via owner-facing `PATCH`/`DELETE` on
`/listings/:id`).

**Security modules added this pass (docs/07):** rate limiting, TOTP-based
MFA (fully offline, unlike every other provider abstraction here — no
external service needed), a CAPTCHA provider abstraction (stub only, same
honest pattern as payments/notifications/moderation), and a tightened CSP.
This also closed the last dormant schema table found across three earlier
audit rounds — `SecurityEvent` now gets a row every time a rate limit
triggers. OAuth, DDoS monitoring, threat feeds, and backups/disaster
recovery remain unimplemented — genuinely blocked (OAuth needs real
provider credentials) or infrastructure-level rather than backend code
(the rest). CSRF protection is explicitly not applicable given this API's
Bearer-token auth, not a gap — see docs/07 for the full control-by-control
table.

**Ready to scaffold next:** real payment provider (Stripe et al.), real
notification delivery channel (email/SMS/push), real AI moderation
provider — all three now have a clean abstraction to implement against
(`lib/payments/provider.ts`, `lib/notifications/channel.ts`,
`lib/moderation/provider.ts`) but need external credentials/network access
this build environment doesn't have. Also: admin viewer UIs for
LoginHistory/AuditLog (both collect real data now, neither has a page to
view it), Category and Geographic analytics domains, partial refunds,
`DRAFT`/`EXPIRED` listing states (defined in the schema, never produced by
anything), and a shared (Redis-backed) rate-limit store for multi-instance
deployment.

**Blocking gaps before feature-complete build:**
- No Plugin Architecture (12) — Admin Panel and Blueprint both assume a Plugin Manager exists.
- No Promotion Engine Design (16) — Database and Blueprint reference `Listing Promotions` / `Promotion Purchases` with no defined rules, pricing, or lifecycle.
- Geographic Manager (17) is partially done — Country/State/City have an API and admin UI, but Region/Neighborhood don't, and there's no per-marketplace geographic scoping (every marketplace sees every city).
- No Configuration Manager Design (18) — Architecture repeatedly says "everything configurable, importable/exportable/versioned" but the mechanism is undefined.
- No Analytics & Reporting Design (19) — Blueprint and Database both list analytics fields; no defined pipeline, storage, or dashboard spec.
- No Product Roadmap (20) — no phasing/milestones beyond "Version 1.0 Goals" in the Blueprint.

Recommendation: scaffold the core (auth, listings, categories, geo, media, search) in parallel with writing 12/16–20, since those five feed directly into Admin Panel and Payment Engine work that's already spec'd.
