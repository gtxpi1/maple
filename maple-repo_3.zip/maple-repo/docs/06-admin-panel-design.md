# 06 — Admin Panel Design (v0.2 — five modules implemented)

## Goal

Everything configurable where practical.

## Modules

Dashboard · Marketplace Manager · Geographic Manager · Categories · Themes
· Users/Roles · Moderation · Payments · Promotions · Media · Watermarks ·
Security · AI Assistant · Analytics · Configuration Manager · Plugin
Manager · System Health

## Status

Implemented, real pages behind the `admin` role:

| Module (as named above) | Page | Notes |
|---|---|---|
| Dashboard | `/admin` | Landing page with quick stats + links to the rest — not a unified dashboard with shared filters |
| Categories | `/admin/categories` | Full CRUD, reorder, show/hide |
| Geographic Manager | `/admin/geography` | Country → State → Region → City → Neighborhood |
| Promotions | `/admin/promotions` | Pricing/duration, admin-configurable per marketplace |
| Payments | `/admin/finance` | Revenue summary, transaction ledger, refunds |
| Analytics | `/admin/analytics` | User/listing counts, signup trend — a slice, not full analytics (see docs/19) |
| Users/Roles | `/admin/users` | Grant/revoke the `admin` role only — no listing of all `Role`/`Permission` rows or non-admin role management |
| Moderation | `/admin/moderation` | Approve/reject PENDING_REVIEW listings — also fixes a real bug: nothing transitioned a listing to ACTIVE before this existed, so no listing was ever visible on the homepage or in search |

Not implemented at all: Marketplace Manager, Themes, Users/Roles admin UI
beyond granting/revoking the `admin` role (`/admin/users` — full user
listing with role details, permission-level management, or non-admin
roles like moderator would need more), Media, Watermarks (no UI to change
per-marketplace watermark settings — it's a JSON blob editable only by
direct DB access or a future endpoint), Security, AI Assistant,
Configuration Manager, Plugin Manager, System Health.

## Dependency Note

Geographic Manager (17) now has a full design doc and implementation.
Configuration Manager (18) and Plugin Manager (12) are still genuinely
unwritten stubs — admin UI work on those two specific modules remains
blocked until those specs exist, same as before.
