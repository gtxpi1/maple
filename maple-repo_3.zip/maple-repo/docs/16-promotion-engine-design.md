# 16 — Promotion Engine Design (v0.3 — admin-configurable pricing)

## Status

Promotion pricing is now marketplace-configurable, following the same
pattern as watermark settings: defaults baked into
`lib/payments/promotionCatalog.ts`, optionally overridden per marketplace
via `Marketplace.configuration.promotions`, editable at `/admin/promotions`
(`PATCH /promotions/catalog`, admin-only). This closes the "hardcoded, not
admin-configurable" gap named in the previous version of this doc.

## What exists

- Default catalog: `featured` ($5/7 days), `bump` ($1/24h).
- Admin UI (`AdminPromotions.tsx`): edit label/price/duration/description
  per type, add new types, remove types, reset to defaults. Saves replace
  the marketplace's entire custom catalog (not a field-by-field merge) —
  an admin is expected to see and save the whole list.
- Purchase flow resolves pricing from the *listing's own marketplace* at
  purchase time, not the global defaults — a custom catalog is what
  actually gets charged, not just what's displayed.
- Editing a price only affects future purchases. Past `ListingPromotion`/
  `Transaction` rows are untouched (the ledger is immutable by design —
  see docs/14) — changing today's price doesn't retroactively change what
  someone already paid.
- Removing a promotion type from the catalog doesn't affect or refund
  already-active promotions of that type; it just stops it from being
  purchasable again.
- `featured` shows a real FEATURED ribbon. `bump` sorts promoted listings
  first — but only *within the currently fetched page* of results (see the
  code comment in `listings.routes.ts` for why cross-page reordering needs
  a denormalized column this doesn't have yet).

## Still not defined

- **Cross-page promoted ordering** — see the bump limitation above.
- **Promotion expiry cleanup** — nothing removes/archives expired
  `ListingPromotion` rows; the `endAt: { gt: now }` filter hides them from
  view but they accumulate in the table indefinitely.
- **Refunds** — the `Refund` model exists, nothing creates rows in it for a
  promotion purchase gone wrong.
- **Currency validation against the marketplace's actual supported
  currencies** — an admin can type any 3-letter currency code; nothing
  checks it against what the marketplace's payment provider actually
  supports.
