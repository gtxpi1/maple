# 14 — Payment Engine Design (v0.2 — provider abstraction implemented, no real provider)

## Providers

Card provider(s) · Litecoin · Marketplace Credits

**Implemented:** `backend/src/lib/payments/provider.ts` defines a
`PaymentProviderClient` interface and one implementation,
`MockPaymentProvider`, which always succeeds and makes no network call.
There is no real Stripe/Litecoin/card provider implemented — this sandbox
has no network access and no payment-processor credentials, so a real
provider was never something that could be built and tested here. Wiring
one in means implementing the interface and swapping the return value of
`getPaymentProvider()`; nothing else in the codebase needs to change.

## Principles

- Immutable ledger — implemented. `Transaction` rows are only ever
  inserted, never updated, by `promotions.routes.ts`.
- Invoice per transaction — implemented, same file.
- Refund workflow — implemented. `POST /admin/finance/transactions/:id/refund`
  (admin-only): full refund of a succeeded transaction, blocks double-refund,
  also expires any `ListingPromotion` that transaction purchased so a
  refunded promotion doesn't keep showing its ribbon or bumped ordering.
  `PaymentProviderClient` gained a `refund()` method alongside `charge()`;
  `MockPaymentProvider` implements both, same honesty caveat as charging —
  no real money moves. One known imprecision: voiding matches by
  `(listingId, promotionType, still-active)` rather than by exact purchase,
  since `ListingPromotion` has no direct FK back to the transaction that
  created it — documented in the code, not silently shipped.
- Promotion purchases — implemented, and pricing is admin-configurable.
  See docs/16.
- Financial reporting — implemented. `GET /admin/finance/summary` (total
  revenue, transaction count, revenue by promotion type, daily revenue for
  the last 30 days) and `GET /admin/finance/transactions` (paginated raw
  ledger), both admin-only, surfaced at `/admin/finance`. Aggregation
  happens in application code, not a SQL groupBy/date-truncation query —
  see the comment in `finance.routes.ts` for why, and what the real
  upgrade path is if transaction volume grows past what that approach
  handles comfortably.

## Dependency Note

"Promotion purchases" now has a working reference implementation — see the
updated docs/16.
