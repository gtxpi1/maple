# 07 — Security Architecture (v0.2 — most application-layer controls implemented)

## Layers

Cloudflare edge → Ubuntu firewall → Reverse proxy → Application security

The first three layers are infrastructure/deployment concerns (see
docs/10), not backend application code — nothing to implement here.
Application security is what this doc now tracks control-by-control.

## Controls — status

| Control | Status |
|---|---|
| MFA support | **Implemented.** TOTP (RFC 6238) via `lib/mfa.ts`. `/auth/mfa/setup`, `/verify`, `/disable`; login requires a 6-digit code when enabled. Fully offline — no external service, unlike every other provider abstraction in this codebase. |
| OAuth | **Not implemented — blocked.** `OAuthAccount` table exists in the schema, nothing reads/writes it. A real OAuth flow needs a registered app with Google/Apple/Microsoft (client ID, client secret, redirect URI) and a network call to their token endpoint — none of that exists or can exist in this build environment. Unlike payments/notifications/moderation, there's no honest "provider abstraction + stub" version of OAuth worth building — an OAuth stub that always succeeds would just be a second, worse login form. |
| CSRF protection | **Not applicable, not a gap.** Auth is a Bearer JWT in the `Authorization` header (see `middleware/auth.ts`), not a cookie the browser attaches automatically — CSRF specifically exploits automatic cookie attachment. See the comment in `src/index.ts` for the full reasoning. Revisit if auth ever moves to httpOnly cookies. |
| XSS protection | **Implemented via framework defaults, not custom code.** React escapes rendered content by default (no `dangerouslySetInnerHTML` anywhere in this frontend); Express's JSON body parser doesn't execute anything. `helmet`'s CSP (see below) is the backstop. |
| SQL injection protection | **Implemented — a property of the ORM, not a separate module.** Every query goes through Prisma, which parameterizes automatically. `$queryRaw` is never called anywhere in this backend. |
| Parameterized queries | Same as above. |
| Secure headers | **Implemented.** `helmet()` with an explicit CSP (`src/index.ts`) tightened for an API-only process (no HTML views, so `default-src: 'none'`). |
| CAPTCHA | **Provider abstraction implemented, stub only.** `lib/captcha/provider.ts`, wired into `/auth/signup`. Same honest pattern as payments/notifications/moderation — `StubCaptchaProvider` always passes, providing zero actual bot protection. A real CAPTCHA needs a site key from reCAPTCHA/hCaptcha/Turnstile and a network call to verify, neither available here. |
| Rate limits | **Implemented.** `middleware/rateLimit.ts` — strict on `/auth` (10 req/15min), moderate on `/media` (30 req/15min), loose globally (120 req/min). In-memory store: works for one process, resets on restart, doesn't share state across multiple instances. A real multi-instance deployment needs a shared store (Redis — already a dependency via `ioredis`, not wired into this yet). |
| DDoS monitoring | **Not implemented — infrastructure-level, not backend code.** This is what the Cloudflare edge layer above is for; nothing an Express process does provides DDoS protection at the network layer. |
| Audit logs | **Implemented for most admin mutations.** `lib/audit.ts`, wired into listing approve/reject, role grant/revoke, category create/update/delete/reorder, geography create/delete (all five levels), promotion catalog updates, and transaction refunds. Not wired into listing edits (owner-initiated, not an admin action) or watermark/media config changes. |
| Threat feeds | **Not implemented — needs a real external subscription.** No code path for this; would mean integrating a real threat-intel provider, which requires credentials and network access this environment doesn't have. |
| Backups, disaster recovery | **Not implemented — infrastructure/ops concern, not backend application code.** See docs/10-deployment-guide.md, which is where this belongs (`pg_dump` scheduling, backup retention, restore runbooks) — not something the Express process itself does. |

## Also implemented alongside these controls

- `LoginHistory` rows written on every login attempt (success and
  failure) — see docs/00-INDEX.md's audit-round notes.
- `SecurityEvent` rows written when a rate limit triggers — this closes
  what was, until this pass, the one schema table left fully dormant
  after three rounds of auditing for unused tables.

## Build Note

The original note here said this should be shared middleware from the
first commit rather than retrofitted — it wasn't; rate limiting, MFA, and
the CAPTCHA stub were all added well after the routes they protect. Worth
stating plainly rather than pretending otherwise.
